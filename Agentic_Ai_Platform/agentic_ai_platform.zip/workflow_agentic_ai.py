#!/usr/bin/env python3

from sanic import Sanic, response
from sanic.request import Request
import json
import os
import asyncio
import uuid
from datetime import datetime
import traceback

# Import your existing workflow components
try:
    from enhanced_agent_runner import run_universal_workflow
    from tool_manager import tool_manager
except ImportError:
    print("Warning: Enhanced agent runner not found. Using basic workflow execution.")
    run_universal_workflow = None
    tool_manager = None

app = Sanic("WorkflowExecutor")

# Configuration
UPLOAD_DIR = "./uploads"
WORKFLOWS_DIR = "./workflows"
RESULTS_DIR = "./results"

# Ensure directories exist
for dir_path in [UPLOAD_DIR, WORKFLOWS_DIR, RESULTS_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# In-memory execution tracking
executions = {}

@app.route("/health", methods=["GET"])
async def health_check(request: Request):
    """Health check endpoint"""
    return response.json({
        "status": "healthy",
        "service": "Workflow Executor",
        "timestamp": datetime.now().isoformat()
    })

@app.route("/upload-workflow", methods=["POST"])
async def upload_workflow(request: Request):
    """Upload a JSON workflow file"""
    try:
        # Debug: Print all files received
        print(f"Files received: {list(request.files.keys())}")
        
        # Handle file upload
        if not request.files or 'workflow' not in request.files:
            return response.json({"error": "No workflow file provided"}, status=400)
        
        workflow_file = request.files['workflow'][0]
        workflow_id = str(uuid.uuid4())
        
        print(f"Uploading workflow: {workflow_file.name}, Size: {len(workflow_file.body)} bytes")
        
        # Save workflow file
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        with open(workflow_path, 'wb') as f:
            f.write(workflow_file.body)
        
        print(f"Workflow saved to: {workflow_path}")
        
        # Validate JSON
        try:
            with open(workflow_path, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)
        except json.JSONDecodeError as e:
            os.remove(workflow_path)
            return response.json({"error": f"Invalid JSON: {str(e)}"}, status=400)
        
        # Get step count
        if isinstance(workflow_data, list):
            step_count = len(workflow_data)
        elif isinstance(workflow_data, dict):
            step_count = len(workflow_data.get("steps", workflow_data.get("workflow", [])))
        else:
            step_count = 0
        
        return response.json({
            "workflow_id": workflow_id,
            "workflow_path": workflow_path,
            "status": "uploaded",
            "steps": step_count,
            "filename": workflow_file.name,
            "message": "Workflow uploaded successfully"
        })
        
    except Exception as e:
        print(f"Upload error: {str(e)}")
        traceback.print_exc()
        return response.json({"error": str(e)}, status=500)

@app.route("/upload-data", methods=["POST"])
async def upload_data(request: Request):
    """Upload data files for workflow execution"""
    try:
        print(f"Data files received: {list(request.files.keys())}")
        
        if not request.files:
            return response.json({"error": "No files provided"}, status=400)
        
        uploaded_files = []
        
        for field_name, file_list in request.files.items():
            for file_obj in file_list:
                file_id = str(uuid.uuid4())
                # Keep original filename for easier reference
                safe_filename = f"{file_id}_{file_obj.name}"
                file_path = os.path.join(UPLOAD_DIR, safe_filename)
                
                print(f"Uploading data file: {file_obj.name}, Size: {len(file_obj.body)} bytes")
                
                with open(file_path, 'wb') as f:
                    f.write(file_obj.body)
                
                uploaded_files.append({
                    "field_name": field_name,
                    "original_name": file_obj.name,
                    "file_id": file_id,
                    "file_path": file_path,
                    "size": len(file_obj.body)
                })
                
                print(f"Data file saved to: {file_path}")
        
        return response.json({
            "uploaded_files": uploaded_files,
            "message": f"Uploaded {len(uploaded_files)} files successfully"
        })
        
    except Exception as e:
        print(f"Data upload error: {str(e)}")
        traceback.print_exc()
        return response.json({"error": str(e)}, status=500)

@app.route("/execute-workflow", methods=["POST"])
async def execute_workflow(request: Request):
    """Execute a workflow with optional data file"""
    try:
        data = request.json
        workflow_id = data.get('workflow_id')
        data_file_path = data.get('data_file_path')
        
        print(f"Execute request: workflow_id={workflow_id}, data_file_path={data_file_path}")
        
        if not workflow_id:
            return response.json({"error": "workflow_id required"}, status=400)
        
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        print(f"Looking for workflow at: {workflow_path}")
        
        if not os.path.exists(workflow_path):
            print(f"Workflow file not found: {workflow_path}")
            print(f"Available workflows: {os.listdir(WORKFLOWS_DIR)}")
            return response.json({"error": f"Workflow not found: {workflow_id}"}, status=404)
        
        # Validate data file if provided
        if data_file_path and not os.path.exists(data_file_path):
            print(f"Data file not found: {data_file_path}")
            print(f"Available data files: {os.listdir(UPLOAD_DIR)}")
            return response.json({"error": f"Data file not found: {data_file_path}"}, status=404)
        
        # Create execution record
        execution_id = str(uuid.uuid4())
        executions[execution_id] = {
            "status": "started",
            "workflow_id": workflow_id,
            "workflow_path": workflow_path,
            "start_time": datetime.now().isoformat(),
            "data_file": data_file_path
        }
        
        print(f"Starting execution {execution_id}")
        
        # Start execution in background
        asyncio.create_task(run_workflow_async(execution_id, workflow_path, data_file_path))
        
        return response.json({
            "execution_id": execution_id,
            "status": "started",
            "workflow_path": workflow_path,
            "data_file": data_file_path,
            "message": "Workflow execution started"
        })
        
    except Exception as e:
        print(f"Execute error: {str(e)}")
        traceback.print_exc()
        return response.json({"error": str(e)}, status=500)

@app.route("/execution-status/<execution_id>", methods=["GET"])
async def get_execution_status(request: Request, execution_id: str):
    """Get execution status and results"""
    if execution_id not in executions:
        return response.json({"error": "Execution not found"}, status=404)
    
    execution_info = executions[execution_id]
    
    # Check if results file exists
    results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
    if os.path.exists(results_file):
        try:
            with open(results_file, 'r') as f:
                results = json.load(f)
            execution_info["results"] = results
        except Exception as e:
            execution_info["results_error"] = str(e)
    
    return response.json(execution_info)

@app.route("/list-workflows", methods=["GET"])
async def list_workflows(request: Request):
    """List all uploaded workflows"""
    try:
        workflows = []
        for filename in os.listdir(WORKFLOWS_DIR):
            if filename.endswith('.json'):
                workflow_id = filename[:-5]  # Remove .json
                workflow_path = os.path.join(WORKFLOWS_DIR, filename)
                
                try:
                    with open(workflow_path, 'r') as f:
                        workflow_data = json.load(f)
                    
                    workflows.append({
                        "workflow_id": workflow_id,
                        "steps": len(workflow_data) if isinstance(workflow_data, list) else len(workflow_data.get("steps", [])),
                        "created": datetime.fromtimestamp(os.path.getctime(workflow_path)).isoformat()
                    })
                except Exception as e:
                    workflows.append({
                        "workflow_id": workflow_id,
                        "error": str(e)
                    })
        
        return response.json({"workflows": workflows})
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/list-executions", methods=["GET"])
async def list_executions(request: Request):
    """List all workflow executions"""
    return response.json({"executions": executions})

async def run_workflow_async(execution_id: str, workflow_path: str, data_file_path: str = None):
    """Execute workflow asynchronously"""
    try:
        print(f"[{execution_id}] Starting workflow execution")
        executions[execution_id]["status"] = "running"
        
        # Auto-discover tools
        if tool_manager:
            print(f"[{execution_id}] Discovering tools...")
            num_tools = tool_manager.discover_tools()
            executions[execution_id]["tools_discovered"] = num_tools
            print(f"[{execution_id}] Discovered {num_tools} tools")
        
        # Execute workflow
        print(f"[{execution_id}] Executing workflow: {workflow_path}")
        print(f"[{execution_id}] Data file: {data_file_path}")
        
        if run_universal_workflow:
            results = run_universal_workflow(workflow_path, data_file_path)
        else:
            # Fallback: basic workflow execution
            print(f"[{execution_id}] Using fallback execution")
            with open(workflow_path, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)
            results = {
                "message": "Basic execution - enhanced runner not available", 
                "workflow": workflow_data,
                "execution_id": execution_id,
                "timestamp": datetime.now().isoformat()
            }
        
        # Save results
        results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
        print(f"[{execution_id}] Saving results to: {results_file}")
        
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str)
        
        executions[execution_id].update({
            "status": "completed",
            "end_time": datetime.now().isoformat(),
            "results_file": results_file,
            "results_summary": f"Execution completed with {len(results)} result items" if isinstance(results, dict) else "Execution completed"
        })
        
        print(f"[{execution_id}] Workflow execution completed successfully")
        
    except Exception as e:
        error_msg = str(e)
        error_trace = traceback.format_exc()
        
        print(f"[{execution_id}] Workflow execution failed: {error_msg}")
        print(f"[{execution_id}] Error trace: {error_trace}")
        
        executions[execution_id].update({
            "status": "failed",
            "end_time": datetime.now().isoformat(),
            "error": error_msg,
            "traceback": error_trace
        })

# Enhanced HTML interface with tabs
@app.route("/", methods=["GET"])
async def web_ui(request: Request):
    """Enhanced web interface with tabs"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Workflow Executor Dashboard</title>
        <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                background: #f5f7fa; 
                color: #333;
            }
            .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
            .header { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; 
                padding: 30px 0; 
                text-align: center; 
                margin-bottom: 30px;
                border-radius: 10px;
            }
            .header h1 { font-size: 2.5em; margin-bottom: 10px; }
            .header p { font-size: 1.1em; opacity: 0.9; }
            
            /* Tab Navigation */
            .tab-nav { 
                display: flex; 
                background: white; 
                border-radius: 10px; 
                margin-bottom: 20px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            .tab-button { 
                flex: 1; 
                padding: 15px 20px; 
                background: white; 
                border: none; 
                cursor: pointer; 
                font-size: 16px;
                transition: all 0.3s ease;
                border-bottom: 3px solid transparent;
            }
            .tab-button:hover { background: #f8f9fa; }
            .tab-button.active { 
                background: #667eea; 
                color: white; 
                border-bottom-color: #4c63d2;
            }
            
            /* Tab Content */
            .tab-content { 
                display: none; 
                background: white; 
                padding: 30px; 
                border-radius: 10px; 
                box-shadow: 0 2px 15px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            .tab-content.active { display: block; }
            .tab-content h3 { 
                color: #667eea; 
                margin-bottom: 20px; 
                font-size: 1.5em;
                border-bottom: 2px solid #eee;
                padding-bottom: 10px;
            }
            
            /* Form Styling */
            .form-group { margin-bottom: 20px; }
            .form-group label { 
                display: block; 
                margin-bottom: 8px; 
                font-weight: 600; 
                color: #555;
            }
            input[type="file"], input[type="text"] { 
                width: 100%; 
                padding: 12px 15px; 
                border: 2px solid #e1e5e9; 
                border-radius: 8px; 
                font-size: 16px;
                transition: border-color 0.3s ease;
            }
            input[type="file"]:focus, input[type="text"]:focus { 
                outline: none; 
                border-color: #667eea; 
            }
            
            .btn { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; 
                padding: 12px 25px; 
                border: none; 
                border-radius: 8px; 
                cursor: pointer; 
                font-size: 16px;
                transition: transform 0.2s ease, box-shadow 0.2s ease;
            }
            .btn:hover { 
                transform: translateY(-2px); 
                box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            }
            .btn-secondary { 
                background: #6c757d; 
                margin-left: 10px;
            }
            .btn-success { background: #28a745; }
            .btn-info { background: #17a2b8; }
            
            /* Results Area */
            .results { 
                background: #f8f9fa; 
                border: 2px solid #e9ecef; 
                padding: 20px; 
                border-radius: 8px; 
                white-space: pre-wrap; 
                font-family: 'Courier New', monospace; 
                max-height: 400px; 
                overflow-y: auto;
                margin-top: 20px;
            }
            .results.success { border-color: #28a745; background: #d4edda; }
            .results.error { border-color: #dc3545; background: #f8d7da; }
            
            /* Status Indicators */
            .status { 
                display: inline-block; 
                padding: 4px 12px; 
                border-radius: 20px; 
                font-size: 12px; 
                font-weight: bold; 
                text-transform: uppercase;
            }
            .status.running { background: #ffc107; color: #000; }
            .status.completed { background: #28a745; color: white; }
            .status.failed { background: #dc3545; color: white; }
            
            /* Responsive */
            @media (max-width: 768px) {
                .tab-nav { flex-direction: column; }
                .tab-button { border-bottom: 1px solid #eee; }
                .container { padding: 10px; }
            }
            
            /* Loading Animation */
            .loading { 
                display: none; 
                text-align: center; 
                padding: 20px;
            }
            .spinner { 
                border: 4px solid #f3f3f3; 
                border-top: 4px solid #667eea; 
                border-radius: 50%; 
                width: 40px; 
                height: 40px; 
                animation: spin 1s linear infinite; 
                margin: 0 auto 10px;
            }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 Workflow Executor</h1>
                <p>Upload, Execute, and Monitor JSON-based Agentic Workflows</p>
            </div>
            
            <!-- Tab Navigation -->
            <div class="tab-nav">
                <button class="tab-button active" onclick="showTab('upload-workflow')">📤 Upload Workflow</button>
                <button class="tab-button" onclick="showTab('upload-data')">📁 Upload Data</button>
                <button class="tab-button" onclick="showTab('execute')">▶️ Execute</button>
                <button class="tab-button" onclick="showTab('monitor')">📊 Monitor</button>
                <button class="tab-button" onclick="showTab('manage')">🗂️ Manage</button>
            </div>
            
            <!-- Upload Workflow Tab -->
            <div id="upload-workflow" class="tab-content active">
                <h3>Upload JSON Workflow</h3>
                <form id="workflow-form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="workflow-file">Select Workflow JSON File:</label>
                        <input type="file" id="workflow-file" name="workflow" accept=".json" required>
                    </div>
                    <button type="submit" class="btn">📤 Upload Workflow</button>
                </form>
                <div class="loading" id="workflow-loading">
                    <div class="spinner"></div>
                    <p>Uploading workflow...</p>
                </div>
            </div>
            
            <!-- Upload Data Tab -->
            <div id="upload-data" class="tab-content">
                <h3>Upload Data Files</h3>
                <form id="data-form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="data-files">Select Data Files (CSV, DOCX, etc.):</label>
                        <input type="file" id="data-files" name="data" multiple>
                    </div>
                    <button type="submit" class="btn">📁 Upload Data Files</button>
                </form>
                <div class="loading" id="data-loading">
                    <div class="spinner"></div>
                    <p>Uploading data files...</p>
                </div>
            </div>
            
            <!-- Execute Tab -->
            <div id="execute" class="tab-content">
                <h3>Execute Workflow</h3>
                <div class="form-group">
                    <label for="workflow-id">Workflow ID:</label>
                    <input type="text" id="workflow-id" placeholder="Enter workflow ID from upload step">
                </div>
                <div class="form-group">
                    <label for="data-path">Data File Path (optional):</label>
                    <input type="text" id="data-path" placeholder="e.g., ./uploads/your-file.csv">
                </div>
                <button onclick="executeWorkflow()" class="btn">▶️ Execute Workflow</button>
                <button onclick="listWorkflows()" class="btn btn-secondary">📋 List Available Workflows</button>
                <div class="loading" id="execute-loading">
                    <div class="spinner"></div>
                    <p>Starting workflow execution...</p>
                </div>
            </div>
            
            <!-- Monitor Tab -->
            <div id="monitor" class="tab-content">
                <h3>Monitor Execution</h3>
                <div class="form-group">
                    <label for="execution-id">Execution ID:</label>
                    <input type="text" id="execution-id" placeholder="Enter execution ID">
                </div>
                <button onclick="checkStatus()" class="btn btn-info">📊 Check Status</button>
                <button onclick="listExecutions()" class="btn btn-secondary">📋 List All Executions</button>
                <button onclick="autoRefresh()" class="btn btn-success" id="auto-refresh-btn">🔄 Start Auto-Refresh</button>
                <div class="loading" id="monitor-loading">
                    <div class="spinner"></div>
                    <p>Checking execution status...</p>
                </div>
            </div>
            
            <!-- Manage Tab -->
            <div id="manage" class="tab-content">
                <h3>Manage Workflows & Executions</h3>
                <button onclick="listWorkflows()" class="btn">📋 List All Workflows</button>
                <button onclick="listExecutions()" class="btn btn-secondary">📊 List All Executions</button>
                <button onclick="healthCheck()" class="btn btn-info">❤️ Health Check</button>
                <button onclick="clearResults()" class="btn" style="background: #ffc107; color: #000;">🗑️ Clear Results</button>
            </div>
            
            <!-- Results Display -->
            <div id="results" class="results"></div>
        </div>
        
        <script>
            let autoRefreshInterval = null;
            const results = document.getElementById('results');
            
            // Tab switching
            function showTab(tabName) {
                // Hide all tabs
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Show selected tab
                document.getElementById(tabName).classList.add('active');
                event.target.classList.add('active');
                
                // Clear results when switching tabs
                clearResults();
            }
            
            // Utility functions
            function showLoading(elementId) {
                document.getElementById(elementId).style.display = 'block';
            }
            
            function hideLoading(elementId) {
                document.getElementById(elementId).style.display = 'none';
            }
            
            function showResults(data, type = 'info') {
                results.className = `results ${type}`;
                results.textContent = JSON.stringify(data, null, 2);
                results.scrollTop = 0;
            }
            
            function clearResults() {
                results.textContent = '';
                results.className = 'results';
            }
            
            // Upload workflow
            document.getElementById('workflow-form').onsubmit = async (e) => {
                e.preventDefault();
                showLoading('workflow-loading');
                
                try {
                    const formData = new FormData(e.target);
                    const response = await fetch('/upload-workflow', { method: 'POST', body: formData });
                    const data = await response.json();
                    
                    if (response.ok) {
                        showResults(data, 'success');
                        // Auto-fill workflow ID in execute tab
                        document.getElementById('workflow-id').value = data.workflow_id;
                    } else {
                        showResults(data, 'error');
                    }
                } catch (error) {
                    showResults({error: error.message}, 'error');
                } finally {
                    hideLoading('workflow-loading');
                }
            };
            
            // Upload data
            document.getElementById('data-form').onsubmit = async (e) => {
                e.preventDefault();
                showLoading('data-loading');
                
                try {
                    const formData = new FormData(e.target);
                    const response = await fetch('/upload-data', { method: 'POST', body: formData });
                    const data = await response.json();
                    
                    if (response.ok) {
                        showResults(data, 'success');
                        // Auto-fill data path if available
                        if (data.uploaded_files && data.uploaded_files.length > 0) {
                            document.getElementById('data-path').value = data.uploaded_files[0].file_path;
                        }
                    } else {
                        showResults(data, 'error');
                    }
                } catch (error) {
                    showResults({error: error.message}, 'error');
                } finally {
                    hideLoading('data-loading');
                }
            };
            
            // Execute workflow
            async function executeWorkflow() {
                const workflowId = document.getElementById('workflow-id').value;
                const dataPath = document.getElementById('data-path').value;
                
                if (!workflowId) {
                    showResults({error: 'Please enter a workflow ID'}, 'error');
                    return;
                }
                
                showLoading('execute-loading');
                
                try {
                    const response = await fetch('/execute-workflow', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({workflow_id: workflowId, data_file_path: dataPath})
                    });
                    const data = await response.json();
                    
                    if (response.ok) {
                        showResults(data, 'success');
                        // Auto-fill execution ID in monitor tab
                        document.getElementById('execution-id').value = data.execution_id;
                        // Switch to monitor tab
                        showTab('monitor');
                        document.querySelector('[onclick="showTab(\'monitor\')"]').classList.add('active');
                    } else {
                        showResults(data, 'error');
                    }
                } catch (error) {
                    showResults({error: error.message}, 'error');
                } finally {
                    hideLoading('execute-loading');
                }
            }
            
            // Check status
            async function checkStatus() {
                const executionId = document.getElementById('execution-id').value;
                
                if (!executionId) {
                    showResults({error: 'Please enter an execution ID'}, 'error');
                    return;
                }
                
                showLoading('monitor-loading');
                
                try {
                    const response = await fetch(`/execution-status/${executionId}`);
                    const data = await response.json();
                    
                    if (response.ok) {
                        showResults(data, data.status === 'failed' ? 'error' : 'success');
                    } else {
                        showResults(data, 'error');
                    }
                } catch (error) {
                    showResults({error: error.message}, 'error');
                } finally {
                    hideLoading('monitor-loading');
                }
            }
            
            // List workflows
            async function listWorkflows() {
                try {
                    const response = await fetch('/list-workflows');
                    const data = await response.json();
                    showResults(data, 'success');
                } catch (error) {
                    showResults({error: error.message}, 'error');
                }
            }
            
            // List executions
            async function listExecutions() {
                try {
                    const response = await fetch('/list-executions');
                    const data = await response.json();
                    showResults(data, 'success');
                } catch (error) {
                    showResults({error: error.message}, 'error');
                }
            }
            
            // Health check
            async function healthCheck() {
                try {
                    const response = await fetch('/health');
                    const data = await response.json();
                    showResults(data, 'success');
                } catch (error) {
                    showResults({error: error.message}, 'error');
                }
            }
            
            // Auto-refresh
            function autoRefresh() {
                const btn = document.getElementById('auto-refresh-btn');
                
                if (autoRefreshInterval) {
                    clearInterval(autoRefreshInterval);
                    autoRefreshInterval = null;
                    btn.textContent = '🔄 Start Auto-Refresh';
                    btn.style.background = '#28a745';
                } else {
                    autoRefreshInterval = setInterval(() => {
                        const executionId = document.getElementById('execution-id').value;
                        if (executionId) {
                            checkStatus();
                        }
                    }, 3000);
                    btn.textContent = '⏸️ Stop Auto-Refresh';
                    btn.style.background = '#dc3545';
                }
            }
            
            // Initialize
            document.addEventListener('DOMContentLoaded', () => {
                showResults({message: 'Welcome to Workflow Executor! Start by uploading a workflow.'}, 'info');
            });
        </script>
    </body>
    </html>
    """
    return response.html(html)

if __name__ == "__main__":
    print("🚀 Starting Workflow Executor API")
    print("📋 Available endpoints:")
    print("  GET  /health     - Health check")
    print("  GET  /           - Web dashboard")
    print("  POST /upload-workflow - Upload JSON workflow")
    print("  POST /upload-data     - Upload data files")
    print("  POST /execute-workflow - Execute workflow")
    print("  GET  /execution-status/<id> - Check execution status")
    print("  GET  /list-workflows  - List all workflows")
    print("  GET  /list-executions - List all executions")
    print("🌐 Access web dashboard at: http://localhost:8000")
    print("📋 API health check: http://localhost:8000/health")
    
    # Create directories if they don't exist
    for dir_path in [UPLOAD_DIR, WORKFLOWS_DIR, RESULTS_DIR]:
        os.makedirs(dir_path, exist_ok=True)
        print(f"📁 Directory ready: {dir_path}")
    
    app.run(host="0.0.0.0", port=8000, debug=True)