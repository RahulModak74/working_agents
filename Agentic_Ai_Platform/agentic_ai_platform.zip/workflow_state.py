#!/usr/bin/env python3

import json
import re
import copy
import operator
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import logging

logger = logging.getLogger("workflow_state")

class WorkflowState:
    """Manages workflow execution state, variables, and context"""
    
    def __init__(self):
        self.variables = {}  # Global workflow variables
        self.scopes = []     # Stack of execution scopes
        self.execution_history = []  # History of executed steps
        self.checkpoints = {}  # Saved state checkpoints
        self.current_scope = "global"
        self.iteration_counters = {}  # Track loop iterations
        
    def push_scope(self, scope_name: str, variables: Dict[str, Any] = None):
        """Create new execution scope"""
        scope = {
            "name": scope_name,
            "variables": variables or {},
            "parent": self.current_scope,
            "created_at": datetime.now().isoformat()
        }
        self.scopes.append(scope)
        self.current_scope = scope_name
        logger.debug(f"Pushed scope: {scope_name}")
    
    def pop_scope(self):
        """Return to parent scope"""
        if not self.scopes:
            logger.warning("Attempted to pop scope but no scopes exist")
            return
        
        scope = self.scopes.pop()
        self.current_scope = scope.get("parent", "global")
        logger.debug(f"Popped scope: {scope['name']}")
        return scope
    
    def set_variable(self, name: str, value: Any, scope: str = None):
        """Set variable in specified scope (current scope if None)"""
        if scope is None:
            scope = self.current_scope
            
        if scope == "global":
            self.variables[name] = value
        else:
            # Find the scope and set variable
            for s in reversed(self.scopes):
                if s["name"] == scope:
                    s["variables"][name] = value
                    break
            else:
                # Scope not found, create in current scope
                if self.scopes:
                    self.scopes[-1]["variables"][name] = value
                else:
                    self.variables[name] = value
        
        logger.debug(f"Set variable {name} = {value} in scope {scope}")
    
    def get_variable(self, name: str, scope: str = None) -> Any:
        """Get variable from specified scope or search up the scope chain"""
        if scope == "global":
            return self.variables.get(name)
        
        # Search current scope first, then parent scopes
        for s in reversed(self.scopes):
            if name in s["variables"]:
                return s["variables"][name]
            if scope and s["name"] == scope:
                break
        
        # Check global scope
        return self.variables.get(name)
    
    def resolve_template_with_type(self, template: str):
        """Resolve template and preserve data types - NEW IMPROVED METHOD"""
        if not isinstance(template, str):
            return template
        
        # Check if this is a pure variable reference (like {{variable_name}})
        pattern = r'^\{\{([^}]+)\}\}$'
        match = re.match(pattern, template.strip())
        
        if match:
            # Pure variable reference - return actual value with original type
            var_name = match.group(1).strip()
            
            if '.' in var_name:
                # Handle dot notation (e.g., results.agent.score)
                parts = var_name.split('.')
                value = self.get_variable(parts[0])
                
                # Navigate through nested attributes/keys
                for part in parts[1:]:
                    if value is None:
                        break
                    if isinstance(value, dict):
                        value = value.get(part)
                    elif hasattr(value, part):
                        value = getattr(value, part)
                    else:
                        value = None
                        break
                
                return value
            else:
                # Simple variable lookup
                return self.get_variable(var_name)
        else:
            # String interpolation - convert to string but try to be smart about it
            return self.resolve_template(template)
    
    def resolve_template(self, template: str) -> str:
        """Resolve template variables like {{variable_name}} - ORIGINAL METHOD"""
        if not isinstance(template, str):
            return template
            
        # Find all template variables
        pattern = r'\{\{([^}]+)\}\}'
        matches = re.findall(pattern, template)
        
        result = template
        for match in matches:
            var_name = match.strip()
            
            # Handle dot notation (e.g., result.accuracy)
            if '.' in var_name:
                parts = var_name.split('.')
                value = self.get_variable(parts[0])
                
                # Navigate through nested attributes/keys
                for part in parts[1:]:
                    if value is None:
                        break
                    if isinstance(value, dict):
                        value = value.get(part)
                    elif hasattr(value, part):
                        value = getattr(value, part)
                    else:
                        value = None
                        break
            else:
                value = self.get_variable(var_name)
            
            # Replace template with actual value
            if value is not None:
                result = result.replace(f"{{{{{match}}}}}", str(value))
        
        return result
    
    def increment_counter(self, counter_name: str) -> int:
        """Increment and return iteration counter"""
        if counter_name not in self.iteration_counters:
            self.iteration_counters[counter_name] = 0
        self.iteration_counters[counter_name] += 1
        return self.iteration_counters[counter_name]
    
    def get_counter(self, counter_name: str) -> int:
        """Get current counter value"""
        return self.iteration_counters.get(counter_name, 0)
    
    def reset_counter(self, counter_name: str):
        """Reset counter to 0"""
        self.iteration_counters[counter_name] = 0
    
    def add_execution_record(self, step_info: Dict[str, Any]):
        """Add step execution to history"""
        record = {
            "timestamp": datetime.now().isoformat(),
            "scope": self.current_scope,
            "step_info": copy.deepcopy(step_info)
        }
        self.execution_history.append(record)
    
    def save_checkpoint(self, checkpoint_name: str):
        """Save current state as checkpoint"""
        checkpoint = {
            "variables": copy.deepcopy(self.variables),
            "scopes": copy.deepcopy(self.scopes),
            "current_scope": self.current_scope,
            "iteration_counters": copy.deepcopy(self.iteration_counters),
            "timestamp": datetime.now().isoformat()
        }
        self.checkpoints[checkpoint_name] = checkpoint
        logger.info(f"Saved checkpoint: {checkpoint_name}")
    
    def restore_checkpoint(self, checkpoint_name: str):
        """Restore state from checkpoint"""
        if checkpoint_name not in self.checkpoints:
            raise ValueError(f"Checkpoint not found: {checkpoint_name}")
        
        checkpoint = self.checkpoints[checkpoint_name]
        self.variables = copy.deepcopy(checkpoint["variables"])
        self.scopes = copy.deepcopy(checkpoint["scopes"])
        self.current_scope = checkpoint["current_scope"]
        self.iteration_counters = copy.deepcopy(checkpoint["iteration_counters"])
        logger.info(f"Restored checkpoint: {checkpoint_name}")
    
    def get_state_summary(self) -> Dict[str, Any]:
        """Get summary of current state"""
        return {
            "variables": self.variables,
            "current_scope": self.current_scope,
            "scope_count": len(self.scopes),
            "execution_steps": len(self.execution_history),
            "checkpoints": list(self.checkpoints.keys()),
            "counters": self.iteration_counters
        }


class ConditionEvaluator:
    """Safely evaluate conditions from workflow JSON"""
    
    # Safe operators for condition evaluation
    OPERATORS = {
        '==': operator.eq,
        '!=': operator.ne,
        '<': operator.lt,
        '<=': operator.le,
        '>': operator.gt,
        '>=': operator.ge,
        'and': operator.and_,
        'or': operator.or_,
        'not': operator.not_,
        'in': lambda a, b: a in b,
        'not_in': lambda a, b: a not in b,
    }
    
    def __init__(self, workflow_state: WorkflowState):
        self.state = workflow_state
    
    def evaluate(self, condition: str) -> bool:
        """Safely evaluate a condition string"""
        if not condition or condition.strip() == "":
            return True
        
        try:
            # Use the new type-preserving template resolution
            resolved_condition = self.state.resolve_template_with_type(condition)
            
            # If it resolved to a boolean, return it directly
            if isinstance(resolved_condition, bool):
                return resolved_condition
            
            # If it resolved to a number and condition was pure variable, treat as truthy
            if isinstance(resolved_condition, (int, float)) and condition.strip().startswith('{{') and condition.strip().endswith('}}'):
                return bool(resolved_condition)
            
            # Handle simple boolean values
            if isinstance(resolved_condition, str) and resolved_condition.lower() in ['true', 'false']:
                return resolved_condition.lower() == 'true'
            
            # Parse and evaluate the condition
            return self._parse_condition(str(resolved_condition))
        
        except Exception as e:
            logger.error(f"Error evaluating condition '{condition}': {e}")
            return False
    
    def _parse_condition(self, condition: str) -> bool:
        """Parse and evaluate a condition expression"""
        condition = condition.strip()
        
        # Handle logical operators (and, or)
        if ' and ' in condition:
            parts = condition.split(' and ', 1)
            return self._parse_condition(parts[0]) and self._parse_condition(parts[1])
        
        if ' or ' in condition:
            parts = condition.split(' or ', 1)
            return self._parse_condition(parts[0]) or self._parse_condition(parts[1])
        
        # Handle negation
        if condition.startswith('not '):
            return not self._parse_condition(condition[4:])
        
        # Handle comparison operators
        for op_str, op_func in self.OPERATORS.items():
            if op_str in ['and', 'or', 'not']:
                continue
                
            if f' {op_str} ' in condition:
                parts = condition.split(f' {op_str} ', 1)
                if len(parts) == 2:
                    left = self._parse_value(parts[0].strip())
                    right = self._parse_value(parts[1].strip())
                    return op_func(left, right)
        
        # If no operators found, treat as variable lookup
        return self._parse_value(condition)
    
    def _parse_value(self, value_str: str):
        """Parse a value string to appropriate Python type"""
        value_str = value_str.strip()
        
        # Handle template variables with type preservation
        if value_str.startswith('{{') and value_str.endswith('}}'):
            return self.state.resolve_template_with_type(value_str)
        
        # Handle string literals
        if (value_str.startswith('"') and value_str.endswith('"')) or \
           (value_str.startswith("'") and value_str.endswith("'")):
            return value_str[1:-1]
        
        # Handle numbers
        try:
            if '.' in value_str:
                return float(value_str)
            else:
                return int(value_str)
        except ValueError:
            pass
        
        # Handle boolean literals
        if value_str.lower() == 'true':
            return True
        if value_str.lower() == 'false':
            return False
        
        # Handle null/none
        if value_str.lower() in ['null', 'none']:
            return None
        
        # Try to get as variable
        var_value = self.state.get_variable(value_str)
        if var_value is not None:
            return var_value
        
        # Return as string if nothing else matches
        return value_str


class WorkflowContext:
    """Complete workflow execution context"""
    
    def __init__(self):
        self.state = WorkflowState()
        self.condition_evaluator = ConditionEvaluator(self.state)
        self.results = {}  # Store agent results by agent name
        self.current_step = None
        self.error_policy = "stop"  # Default error handling
    
    def set_result(self, agent_name: str, result: Any):
        """Store agent result"""
        self.results[agent_name] = result
        # Also store in state variables for easy access
        self.state.set_variable(f"results.{agent_name}", result)
    
    def get_result(self, agent_name: str) -> Any:
        """Get agent result"""
        return self.results.get(agent_name)
    
    def evaluate_condition(self, condition: str) -> bool:
        """Evaluate a condition"""
        return self.condition_evaluator.evaluate(condition)
    
    def resolve_step_variables(self, step: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve all template variables in a step"""
        if not isinstance(step, dict):
            return step
        
        resolved_step = {}
        for key, value in step.items():
            if isinstance(value, str):
                # Use type-preserving resolution for conditions and numeric values
                if key in ['condition', 'count', 'max_iterations'] or value.strip().startswith('{{') and value.strip().endswith('}}'):
                    resolved_step[key] = self.state.resolve_template_with_type(value)
                else:
                    resolved_step[key] = self.state.resolve_template(value)
            elif isinstance(value, dict):
                resolved_step[key] = self.resolve_step_variables(value)
            elif isinstance(value, list):
                resolved_step[key] = [
                    self.resolve_step_variables(item) if isinstance(item, dict) else
                    self.state.resolve_template_with_type(item) if isinstance(item, str) and item.strip().startswith('{{') and item.strip().endswith('}}') else
                    self.state.resolve_template(item) if isinstance(item, str) else item
                    for item in value
                ]
            else:
                resolved_step[key] = value
        
        return resolved_step