#!/usr/bin/env python3

import os
import sys
import json
import copy
import asyncio
import concurrent.futures
from typing import Dict, Any, List, Optional, Union
import logging
from datetime import datetime

# Import our new components
from workflow_state import WorkflowContext, WorkflowState, ConditionEvaluator

logger = logging.getLogger("workflow_executor")

class WorkflowExecutor:
    """Enhanced workflow executor with flow control and state management"""
    
    def __init__(self, tool_manager, agent_runner_func):
        self.tool_manager = tool_manager
        self.run_agent = agent_runner_func  # The original run_agent function
        self.context = WorkflowContext()
        
    def execute_workflow(self, workflow: List[Dict[str, Any]], 
                        data_file: str = None) -> Dict[str, Any]:
        """Execute workflow with enhanced flow control"""
        
        try:
            logger.info("Starting enhanced workflow execution")
            
            # Initialize workflow variables if present
            if isinstance(workflow, dict) and "variables" in workflow:
                for var_name, var_value in workflow["variables"].items():
                    self.context.state.set_variable(var_name, var_value)
                workflow = workflow.get("steps", [])
            
            # Execute all steps
            for step_index, step in enumerate(workflow):
                logger.info(f"Executing step {step_index + 1}/{len(workflow)}")
                
                try:
                    result = self._execute_step(step, data_file)
                    
                    # Store result if agent name is present
                    if "agent" in step:
                        agent_name = step["agent"]
                        self.context.set_result(agent_name, result)
                        logger.info(f"✅ Step {step_index + 1} ({agent_name}) completed")
                    
                except Exception as e:
                    error_msg = f"❌ Step {step_index + 1} failed: {str(e)}"
                    logger.error(error_msg)
                    
                    # Handle error based on policy
                    error_policy = step.get("on_error", "stop")
                    if error_policy == "stop":
                        raise Exception(error_msg)
                    elif error_policy == "continue":
                        logger.warning("Continuing execution despite error")
                        continue
                    elif error_policy == "retry":
                        # TODO: Implement retry logic
                        logger.warning("Retry not implemented, continuing")
                        continue
            
            # Return final results
            final_results = dict(self.context.results)
            final_results["workflow_state"] = self.context.state.get_state_summary()
            
            logger.info("✅ Workflow execution completed successfully")
            return final_results
            
        except Exception as e:
            logger.error(f"❌ Workflow execution failed: {str(e)}")
            return {"error": str(e), "partial_results": dict(self.context.results)}
    
    def _execute_step(self, step: Dict[str, Any], data_file: str = None) -> Any:
        """Execute a single workflow step with flow control"""
        
        # Resolve template variables in step
        resolved_step = self.context.resolve_step_variables(step)
        self.context.current_step = resolved_step
        
        # Record step execution
        self.context.state.add_execution_record(resolved_step)
        
        # Get step type
        step_type = resolved_step.get("type", "agent")
        
        # Route to appropriate handler
        if step_type == "agent":
            return self._execute_agent_step(resolved_step, data_file)
        elif step_type == "loop":
            return self._execute_loop_step(resolved_step, data_file)
        elif step_type == "conditional":
            return self._execute_conditional_step(resolved_step, data_file)
        elif step_type == "parallel":
            return self._execute_parallel_step(resolved_step, data_file)
        elif step_type == "state":
            return self._execute_state_step(resolved_step)
        elif step_type == "dynamic":
            return self._execute_dynamic_step(resolved_step, data_file)
        else:
            raise ValueError(f"Unknown step type: {step_type}")
    
    def _execute_agent_step(self, step: Dict[str, Any], data_file: str = None) -> Any:
        """Execute a standard agent step"""
        
        agent_name = step.get("agent")
        if not agent_name:
            raise ValueError("Agent step must have 'agent' field")
        
        content = step.get("content", "")
        output_format = step.get("output_format", {})
        required_tools = step.get("tools", [])
        
        # Collect references
        references = self._collect_references(step.get("readFrom", []))
        
        # Handle file parameter
        file_path = None
        if step.get("file"):
            file_path = data_file
        
        # Execute the agent
        result = self.run_agent(
            agent_name=agent_name,
            prompt=content,
            file_path=file_path,
            output_format=output_format,
            references=references,
            required_tools=required_tools
        )
        
        return result
    
    def _execute_loop_step(self, step: Dict[str, Any], data_file: str = None) -> List[Any]:
        """Execute loop step with various loop types"""
        
        loop_type = step.get("loop_type", "while")
        max_iterations = step.get("max_iterations", 100)
        steps = step.get("steps", [])
        
        if not steps:
            logger.warning("Loop step has no substeps")
            return []
        
        results = []
        iteration = 0
        
        # Create loop scope
        loop_scope_name = f"loop_{datetime.now().timestamp()}"
        self.context.state.push_scope(loop_scope_name, step.get("variables", {}))
        
        try:
            if loop_type == "while":
                condition = step.get("condition", "true")
                
                while iteration < max_iterations:
                    # Update iteration counter
                    self.context.state.set_variable("iteration", iteration)
                    
                    # Check condition
                    if not self.context.evaluate_condition(condition):
                        logger.info(f"Loop condition failed at iteration {iteration}")
                        break
                    
                    # Execute substeps
                    iteration_results = []
                    for substep in steps:
                        result = self._execute_step(substep, data_file)
                        iteration_results.append(result)
                    
                    results.append(iteration_results)
                    iteration += 1
                    
                    logger.debug(f"Completed while loop iteration {iteration}")
            
            elif loop_type == "for_count":
                count = step.get("count", 1)
                
                for i in range(min(count, max_iterations)):
                    self.context.state.set_variable("iteration", i)
                    self.context.state.set_variable("index", i)
                    
                    iteration_results = []
                    for substep in steps:
                        result = self._execute_step(substep, data_file)
                        iteration_results.append(result)
                    
                    results.append(iteration_results)
                    logger.debug(f"Completed for_count iteration {i}")
            
            elif loop_type == "for_each":
                collection = step.get("collection", [])
                item_variable = step.get("item_variable", "current_item")
                
                # Resolve collection if it's a variable reference
                if isinstance(collection, str):
                    collection = self.context.state.get_variable(collection) or []
                
                for i, item in enumerate(collection[:max_iterations]):
                    self.context.state.set_variable("iteration", i)
                    self.context.state.set_variable("index", i)
                    self.context.state.set_variable(item_variable, item)
                    
                    iteration_results = []
                    for substep in steps:
                        result = self._execute_step(substep, data_file)
                        iteration_results.append(result)
                    
                    results.append(iteration_results)
                    logger.debug(f"Completed for_each iteration {i} with item: {item}")
            
            else:
                raise ValueError(f"Unknown loop type: {loop_type}")
        
        finally:
            # Pop loop scope
            self.context.state.pop_scope()
        
        logger.info(f"Loop completed with {len(results)} iterations")
        return results
    
    def _execute_conditional_step(self, step: Dict[str, Any], data_file: str = None) -> Any:
        """Execute conditional step (if/then/else)"""
        
        condition = step.get("condition", "true")
        true_steps = step.get("true_steps", step.get("then_steps", []))
        false_steps = step.get("false_steps", step.get("else_steps", []))
        else_if_blocks = step.get("else_if", [])
        
        # Create conditional scope
        cond_scope_name = f"conditional_{datetime.now().timestamp()}"
        self.context.state.push_scope(cond_scope_name, step.get("variables", {}))
        
        try:
            # Evaluate main condition
            if self.context.evaluate_condition(condition):
                logger.info(f"Condition '{condition}' evaluated to True")
                results = []
                for substep in true_steps:
                    result = self._execute_step(substep, data_file)
                    results.append(result)
                return results
            
            # Check else_if conditions
            for else_if_block in else_if_blocks:
                elif_condition = else_if_block.get("condition", "false")
                elif_steps = else_if_block.get("steps", [])
                
                if self.context.evaluate_condition(elif_condition):
                    logger.info(f"Else-if condition '{elif_condition}' evaluated to True")
                    results = []
                    for substep in elif_steps:
                        result = self._execute_step(substep, data_file)
                        results.append(result)
                    return results
            
            # Execute else steps if no conditions matched
            logger.info(f"Condition '{condition}' evaluated to False, executing else steps")
            results = []
            for substep in false_steps:
                result = self._execute_step(substep, data_file)
                results.append(result)
            return results
        
        finally:
            # Pop conditional scope
            self.context.state.pop_scope()
    
    def _execute_parallel_step(self, step: Dict[str, Any], data_file: str = None) -> List[Any]:
        """Execute parallel step"""
        
        parallel_steps = step.get("steps", step.get("agents", []))
        max_parallel = step.get("max_parallel", 5)
        merge_strategy = step.get("merge_strategy", "collect_all")
        
        if not parallel_steps:
            logger.warning("Parallel step has no substeps")
            return []
        
        # Create parallel scope
        parallel_scope_name = f"parallel_{datetime.now().timestamp()}"
        self.context.state.push_scope(parallel_scope_name, step.get("variables", {}))
        
        try:
            results = []
            
            # Use ThreadPoolExecutor for parallel execution
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel) as executor:
                # Submit all tasks
                future_to_step = {}
                for i, substep in enumerate(parallel_steps):
                    future = executor.submit(self._execute_step_safe, substep, data_file)
                    future_to_step[future] = (i, substep)
                
                # Collect results as they complete
                step_results = [None] * len(parallel_steps)
                for future in concurrent.futures.as_completed(future_to_step):
                    step_index, substep = future_to_step[future]
                    try:
                        result = future.result()
                        step_results[step_index] = result
                        logger.debug(f"Parallel substep {step_index} completed")
                    except Exception as e:
                        logger.error(f"Parallel substep {step_index} failed: {e}")
                        step_results[step_index] = {"error": str(e)}
            
            # Apply merge strategy
            if merge_strategy == "collect_all":
                results = step_results
            elif merge_strategy == "first_success":
                results = next((r for r in step_results if r and "error" not in r), None)
            elif merge_strategy == "all_success":
                if all(r and "error" not in r for r in step_results):
                    results = step_results
                else:
                    results = {"error": "Not all parallel steps succeeded"}
            else:
                results = step_results
            
            logger.info(f"Parallel execution completed with {len(parallel_steps)} substeps")
            return results
        
        finally:
            # Pop parallel scope
            self.context.state.pop_scope()
    
    def _execute_step_safe(self, step: Dict[str, Any], data_file: str = None) -> Any:
        """Thread-safe version of _execute_step for parallel execution"""
        try:
            return self._execute_step(step, data_file)
        except Exception as e:
            logger.error(f"Safe step execution failed: {e}")
            return {"error": str(e)}
    
    def _execute_state_step(self, step: Dict[str, Any]) -> Any:
        """Execute state management step"""
        
        operation = step.get("operation")
        if not operation:
            raise ValueError("State step must have 'operation' field")
        
        if operation == "save_checkpoint":
            checkpoint_name = step.get("checkpoint_name", f"checkpoint_{datetime.now().timestamp()}")
            self.context.state.save_checkpoint(checkpoint_name)
            return {"success": True, "checkpoint": checkpoint_name}
        
        elif operation == "restore_checkpoint":
            checkpoint_name = step.get("checkpoint_name")
            if not checkpoint_name:
                raise ValueError("restore_checkpoint requires checkpoint_name")
            self.context.state.restore_checkpoint(checkpoint_name)
            return {"success": True, "restored": checkpoint_name}
        
        elif operation == "set_variable":
            var_name = step.get("variable_name")
            var_value = step.get("value")
            scope = step.get("scope")
            if not var_name:
                raise ValueError("set_variable requires variable_name")
            self.context.state.set_variable(var_name, var_value, scope)
            return {"success": True, "variable": var_name, "value": var_value}
        
        elif operation == "get_variable":
            var_name = step.get("variable_name")
            scope = step.get("scope")
            if not var_name:
                raise ValueError("get_variable requires variable_name")
            value = self.context.state.get_variable(var_name, scope)
            return {"variable": var_name, "value": value}
        
        elif operation == "increment_counter":
            counter_name = step.get("counter_name", "default")
            new_value = self.context.state.increment_counter(counter_name)
            return {"counter": counter_name, "value": new_value}
        
        elif operation == "reset_counter":
            counter_name = step.get("counter_name", "default")
            self.context.state.reset_counter(counter_name)
            return {"success": True, "counter": counter_name, "value": 0}
        
        elif operation == "push_scope":
            scope_name = step.get("scope_name")
            variables = step.get("variables", {})
            if not scope_name:
                raise ValueError("push_scope requires scope_name")
            self.context.state.push_scope(scope_name, variables)
            return {"success": True, "scope": scope_name}
        
        elif operation == "pop_scope":
            scope = self.context.state.pop_scope()
            return {"success": True, "popped_scope": scope}
        
        elif operation == "get_status":
            return self.context.state.get_state_summary()
        
        else:
            raise ValueError(f"Unknown state operation: {operation}")
    
    def _collect_references(self, read_from: List[Union[str, Dict]]) -> Dict[str, Any]:
        """Collect references from previous agent results"""
        references = {}
        
        for ref in read_from:
            if ref == "*":
                # Include all previous results
                references.update(self.context.results)
            elif isinstance(ref, str):
                # Single agent reference
                if ref in self.context.results:
                    references[ref] = self.context.results[ref]
            elif isinstance(ref, dict):
                # Complex reference (not implemented yet)
                logger.warning(f"Complex reference not yet implemented: {ref}")
        
        return references
    
    def handle_tool_execution(self, tool_id: str, **kwargs) -> Any:
        """Handle special tool execution for flow control and state tools"""
        
        # Check if this is a flow control tool
        if tool_id.startswith("flow:"):
            tool_name = tool_id.split(":", 1)[1]
            
            # These tools return configuration, actual execution is handled by workflow steps
            if tool_name in ["repeat_until", "repeat_count", "while_condition", "for_each", 
                           "if_then_else", "switch_case", "parallel_execution", "sequential_batch"]:
                return {"tool_type": "flow_control", "configuration": kwargs}
        
        # Check if this is a state management tool
        elif tool_id.startswith("state:"):
            tool_name = tool_id.split(":", 1)[1]
            
            if tool_name == "save_checkpoint":
                checkpoint_name = kwargs.get("checkpoint_name", f"checkpoint_{datetime.now().timestamp()}")
                self.context.state.save_checkpoint(checkpoint_name)
                return {"success": True, "checkpoint": checkpoint_name}
            
            elif tool_name == "restore_checkpoint":
                checkpoint_name = kwargs.get("checkpoint_name")
                if checkpoint_name:
                    self.context.state.restore_checkpoint(checkpoint_name)
                    return {"success": True, "restored": checkpoint_name}
                else:
                    return {"error": "checkpoint_name required"}
            
            elif tool_name == "set_variable":
                var_name = kwargs.get("variable_name")
                var_value = kwargs.get("value")
                scope = kwargs.get("scope")
                if var_name is not None:
                    self.context.state.set_variable(var_name, var_value, scope)
                    return {"success": True, "variable": var_name, "value": var_value}
                else:
                    return {"error": "variable_name required"}
            
            elif tool_name == "get_variable":
                var_name = kwargs.get("variable_name")
                scope = kwargs.get("scope")
                if var_name:
                    value = self.context.state.get_variable(var_name, scope)
                    return {"variable": var_name, "value": value}
                else:
                    return {"error": "variable_name required"}
            
            elif tool_name == "get_workflow_status":
                return self.context.state.get_state_summary()
        
        # For other tools, delegate to the tool manager
        return self.tool_manager.execute_tool(tool_id, **kwargs)