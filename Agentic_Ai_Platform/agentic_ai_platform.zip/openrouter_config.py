#!/usr/bin/env python3

import os

# Configuration settings for the agent system
CONFIG = {
    "output_dir": "./agent_outputs",
    "memory_dir": "./agent_memory",
    "default_model": "deepseek/deepseek-chat:free",
#     "default_model": "openrouter/quasar-alpha",
    "api_key": "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",
    "endpoint": "https://openrouter.ai/api/v1/chat/completions",
    "memory_db": "agent_memory.db",
    "sqlite_db": "test_sqlite.db" 
}

# Ensure output directories exist
os.makedirs(CONFIG["output_dir"], exist_ok=True)
os.makedirs(CONFIG["memory_dir"], exist_ok=True)
