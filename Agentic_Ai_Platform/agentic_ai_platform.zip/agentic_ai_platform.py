#!/usr/bin/env python3

from sanic import Sanic, response
from sanic.request import Request
import json
import os
import asyncio
import uuid
from datetime import datetime
import traceback

# Import your existing workflow components
try:
    from enhanced_agent_runner import run_universal_workflow
    from tool_manager import tool_manager
except ImportError:
    print("Warning: Enhanced agent runner not found. Using basic workflow execution.")
    run_universal_workflow = None
    tool_manager = None

app = Sanic("WorkflowExecutor")

# Configuration
UPLOAD_DIR = "./uploads"
WORKFLOWS_DIR = "./workflows"
RESULTS_DIR = "./results"

# Ensure directories exist
for dir_path in [UPLOAD_DIR, WORKFLOWS_DIR, RESULTS_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# In-memory execution tracking
executions = {}

@app.route("/", methods=["GET"])
async def health_check(request: Request):
    """Health check endpoint"""
    return response.json({
        "status": "healthy",
        "service": "Workflow Executor",
        "timestamp": datetime.now().isoformat()
    })

@app.route("/upload-workflow", methods=["POST"])
async def upload_workflow(request: Request):
    """Upload a JSON workflow file"""
    try:
        # Handle file upload
        if 'workflow' not in request.files:
            return response.json({"error": "No workflow file provided"}, status=400)
        
        workflow_file = request.files['workflow'][0]
        workflow_id = str(uuid.uuid4())
        
        # Save workflow file
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        with open(workflow_path, 'wb') as f:
            f.write(workflow_file.body)
        
        # Validate JSON
        try:
            with open(workflow_path, 'r', encoding='utf-8') as f:
                workflow_data = json.load(f)
        except json.JSONDecodeError as e:
            os.remove(workflow_path)
            return response.json({"error": f"Invalid JSON: {str(e)}"}, status=400)
        
        return response.json({
            "workflow_id": workflow_id,
            "filename": workflow_file.name,
            "status": "uploaded",
            "steps": len(workflow_data) if isinstance(workflow_data, list) else len(workflow_data.get("steps", [])),
            "message": "Workflow uploaded successfully"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/upload-data", methods=["POST"])
async def upload_data(request: Request):
    """Upload data files for workflow execution"""
    try:
        uploaded_files = []
        
        for field_name, file_list in request.files.items():
            for file_obj in file_list:
                file_id = str(uuid.uuid4())
                file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file_obj.name}")
                
                with open(file_path, 'wb') as f:
                    f.write(file_obj.body)
                
                uploaded_files.append({
                    "field_name": field_name,
                    "original_name": file_obj.name,
                    "file_id": file_id,
                    "file_path": file_path
                })
        
        return response.json({
            "uploaded_files": uploaded_files,
            "message": f"Uploaded {len(uploaded_files)} files successfully"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/execute-workflow", methods=["POST"])
async def execute_workflow(request: Request):
    """Execute a workflow with optional data file"""
    try:
        data = request.json
        workflow_id = data.get('workflow_id')
        data_file_path = data.get('data_file_path')
        
        if not workflow_id:
            return response.json({"error": "workflow_id required"}, status=400)
        
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        if not os.path.exists(workflow_path):
            return response.json({"error": "Workflow not found"}, status=404)
        
        # Create execution record
        execution_id = str(uuid.uuid4())
        executions[execution_id] = {
            "status": "started",
            "workflow_id": workflow_id,
            "start_time": datetime.now().isoformat(),
            "data_file": data_file_path
        }
        
        # Start execution in background
        asyncio.create_task(run_workflow_async(execution_id, workflow_path, data_file_path))
        
        return response.json({
            "execution_id": execution_id,
            "status": "started",
            "message": "Workflow execution started"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/execution-status/<execution_id>", methods=["GET"])
async def get_execution_status(request: Request, execution_id: str):
    """Get execution status and results"""
    if execution_id not in executions:
        return response.json({"error": "Execution not found"}, status=404)
    
    execution_info = executions[execution_id]
    
    # Check if results file exists
    results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
    if os.path.exists(results_file):
        try:
            with open(results_file, 'r') as f:
                results = json.load(f)
            execution_info["results"] = results
        except Exception as e:
            execution_info["results_error"] = str(e)
    
    return response.json(execution_info)

@app.route("/list-workflows", methods=["GET"])
async def list_workflows(request: Request):
    """List all uploaded workflows"""
    try:
        workflows = []
        for filename in os.listdir(WORKFLOWS_DIR):
            if filename.endswith('.json'):
                workflow_id = filename[:-5]  # Remove .json
                workflow_path = os.path.join(WORKFLOWS_DIR, filename)
                
                try:
                    with open(workflow_path, 'r') as f:
                        workflow_data = json.load(f)
                    
                    workflows.append({
                        "workflow_id": workflow_id,
                        "steps": len(workflow_data) if isinstance(workflow_data, list) else len(workflow_data.get("steps", [])),
                        "created": datetime.fromtimestamp(os.path.getctime(workflow_path)).isoformat()
                    })
                except Exception as e:
                    workflows.append({
                        "workflow_id": workflow_id,
                        "error": str(e)
                    })
        
        return response.json({"workflows": workflows})
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/list-data-files", methods=["GET"])
async def list_data_files(request: Request):
    """List all uploaded data files"""
    try:
        data_files = []
        for filename in os.listdir(UPLOAD_DIR):
            file_path = os.path.join(UPLOAD_DIR, filename)
            if os.path.isfile(file_path):
                data_files.append({
                    "filename": filename,
                    "file_path": file_path,
                    "size": os.path.getsize(file_path),
                    "created": datetime.fromtimestamp(os.path.getctime(file_path)).isoformat()
                })
        
        return response.json({"data_files": data_files})
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/list-executions", methods=["GET"])
async def list_executions(request: Request):
    """List all workflow executions"""
    return response.json({"executions": executions})

async def run_workflow_async(execution_id: str, workflow_path: str, data_file_path: str = None):
    """Execute workflow asynchronously"""
    try:
        executions[execution_id]["status"] = "running"
        
        # Auto-discover tools
        if tool_manager:
            num_tools = tool_manager.discover_tools()
            executions[execution_id]["tools_discovered"] = num_tools
        
        # Execute workflow
        if run_universal_workflow:
            results = run_universal_workflow(workflow_path, data_file_path)
        else:
            # Fallback: basic workflow execution
            with open(workflow_path, 'r') as f:
                workflow_data = json.load(f)
            results = {"message": "Basic execution - enhanced runner not available", "workflow": workflow_data}
        
        # Save results
        results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        executions[execution_id].update({
            "status": "completed",
            "end_time": datetime.now().isoformat(),
            "results_file": results_file
        })
        
    except Exception as e:
        executions[execution_id].update({
            "status": "failed",
            "end_time": datetime.now().isoformat(),
            "error": str(e),
            "traceback": traceback.format_exc()
        })

# Enhanced HTML interface
@app.route("/ui", methods=["GET"])
async def web_ui(request: Request):
    """Enhanced web interface with better styling and helper buttons"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>🚀 Workflow Executor</title>
        <style>
            * { box-sizing: border-box; }
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background: #f8f9fa; 
                color: #333;
            }
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                background: white; 
                padding: 30px; 
                border-radius: 15px; 
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            }
            h1 { 
                text-align: center; 
                color: #2c3e50; 
                margin-bottom: 30px; 
                font-size: 2.5em;
            }
            .section { 
                margin: 30px 0; 
                padding: 25px; 
                border: 2px solid #e9ecef; 
                border-radius: 10px; 
                background: #f8f9fa;
            }
            .section h3 { 
                color: #495057; 
                margin-top: 0; 
                border-bottom: 2px solid #dee2e6; 
                padding-bottom: 10px;
            }
            input[type="file"], input[type="text"] { 
                width: 100%; 
                padding: 12px; 
                margin: 10px 0; 
                border: 2px solid #ced4da; 
                border-radius: 8px; 
                font-size: 16px;
                transition: border-color 0.3s ease;
            }
            input[type="file"]:focus, input[type="text"]:focus { 
                outline: none; 
                border-color: #007bff; 
                box-shadow: 0 0 0 3px rgba(0,123,255,0.25);
            }
            button { 
                background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
                color: white; 
                border: none; 
                padding: 12px 20px; 
                margin: 5px; 
                border-radius: 8px; 
                cursor: pointer; 
                font-size: 16px;
                transition: all 0.3s ease;
            }
            button:hover { 
                transform: translateY(-2px); 
                box-shadow: 0 5px 15px rgba(0,123,255,0.4);
            }
            .btn-secondary { background: linear-gradient(135deg, #6c757d 0%, #495057 100%); }
            .btn-success { background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%); }
            .btn-warning { background: linear-gradient(135deg, #ffc107 0%, #d39e00 100%); color: #212529; }
            .btn-info { background: linear-gradient(135deg, #17a2b8 0%, #117a8b 100%); }
            
            .results { 
                background: #343a40; 
                color: #f8f9fa; 
                padding: 20px; 
                border-radius: 8px; 
                white-space: pre-wrap; 
                font-family: 'Courier New', monospace; 
                max-height: 400px; 
                overflow-y: auto;
                margin-top: 20px;
                border: 2px solid #495057;
            }
            .helper-buttons { 
                display: flex; 
                gap: 10px; 
                margin: 15px 0; 
                flex-wrap: wrap;
            }
            .copy-btn { 
                background: #17a2b8; 
                font-size: 12px; 
                padding: 5px 10px;
            }
            .workflow-item, .data-item { 
                background: white; 
                padding: 15px; 
                margin: 10px 0; 
                border-radius: 8px; 
                border-left: 4px solid #007bff;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .workflow-id, .file-path { 
                font-family: monospace; 
                background: #e9ecef; 
                padding: 5px 8px; 
                border-radius: 4px; 
                font-size: 14px;
                word-break: break-all;
            }
            .status { 
                display: inline-block; 
                padding: 4px 8px; 
                border-radius: 15px; 
                font-size: 12px; 
                font-weight: bold;
            }
            .status.running { background: #ffc107; color: #000; }
            .status.completed { background: #28a745; color: white; }
            .status.failed { background: #dc3545; color: white; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
            @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 Workflow Executor</h1>
            
            <div class="grid">
                <div class="section">
                    <h3>📤 Upload Workflow</h3>
                    <form id="workflow-form" enctype="multipart/form-data">
                        <input type="file" name="workflow" accept=".json" required>
                        <button type="submit">Upload Workflow</button>
                    </form>
                    <div class="helper-buttons">
                        <button class="btn-info" onclick="showWorkflows()">📋 Show All Workflows</button>
                        <button class="btn-secondary" onclick="clearResults()">🗑️ Clear Results</button>
                    </div>
                </div>
                
                <div class="section">
                    <h3>📁 Upload Data Files</h3>
                    <form id="data-form" enctype="multipart/form-data">
                        <input type="file" name="data" multiple>
                        <button type="submit">Upload Data Files</button>
                    </form>
                    <div class="helper-buttons">
                        <button class="btn-info" onclick="showDataFiles()">📂 Show All Data Files</button>
                        <button class="btn-secondary" onclick="clearResults()">🗑️ Clear Results</button>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <h3>▶️ Execute Workflow</h3>
                <input type="text" id="workflow-id" placeholder="Workflow ID (use button above to see available IDs)">
                <input type="text" id="data-path" placeholder="Data file path (use button above to see available paths)">
                <button onclick="executeWorkflow()">Execute Workflow</button>
                <div class="helper-buttons">
                    <button class="btn-warning" onclick="getLatestWorkflowId()">🆔 Get Latest Workflow ID</button>
                    <button class="btn-warning" onclick="getLatestDataPath()">📄 Get Latest Data Path</button>
                </div>
            </div>
            
            <div class="section">
                <h3>📊 Monitor Execution</h3>
                <input type="text" id="execution-id" placeholder="Execution ID">
                <button onclick="checkStatus()" class="btn-success">Check Status</button>
                <div class="helper-buttons">
                    <button class="btn-info" onclick="listExecutions()">📊 Show All Executions</button>
                    <button class="btn-warning" onclick="getLatestExecutionId()">🆔 Get Latest Execution ID</button>
                    <button class="btn-secondary" onclick="startAutoRefresh()">🔄 Auto-Refresh</button>
                </div>
            </div>
            
            <div id="results" class="results">Welcome to Workflow Executor! 🎉</div>
        </div>
        
        <script>
            const results = document.getElementById('results');
            let autoRefreshInterval = null;
            let lastWorkflowId = '';
            let lastDataPath = '';
            let lastExecutionId = '';
            
            function showResults(data) {
                results.textContent = JSON.stringify(data, null, 2);
            }
            
            function clearResults() {
                results.textContent = 'Results cleared. Ready for next operation! ✨';
            }
            
            // Upload workflow
            document.getElementById('workflow-form').onsubmit = async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                try {
                    const response = await fetch('/upload-workflow', { method: 'POST', body: formData });
                    const data = await response.json();
                    if (data.workflow_id) {
                        lastWorkflowId = data.workflow_id;
                        document.getElementById('workflow-id').value = lastWorkflowId;
                    }
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            };
            
            // Upload data
            document.getElementById('data-form').onsubmit = async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                try {
                    const response = await fetch('/upload-data', { method: 'POST', body: formData });
                    const data = await response.json();
                    if (data.uploaded_files && data.uploaded_files.length > 0) {
                        lastDataPath = data.uploaded_files[0].file_path;
                        document.getElementById('data-path').value = lastDataPath;
                    }
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            };
            
            // Execute workflow
            async function executeWorkflow() {
                const workflowId = document.getElementById('workflow-id').value;
                const dataPath = document.getElementById('data-path').value;
                try {
                    const response = await fetch('/execute-workflow', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({workflow_id: workflowId, data_file_path: dataPath})
                    });
                    const data = await response.json();
                    if (data.execution_id) {
                        lastExecutionId = data.execution_id;
                        document.getElementById('execution-id').value = lastExecutionId;
                    }
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            }
            
            // Check status
            async function checkStatus() {
                const executionId = document.getElementById('execution-id').value;
                try {
                    const response = await fetch(`/execution-status/${executionId}`);
                    const data = await response.json();
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            }
            
            // Helper functions
            async function showWorkflows() {
                try {
                    const response = await fetch('/list-workflows');
                    const data = await response.json();
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            }
            
            async function showDataFiles() {
                try {
                    const response = await fetch('/list-data-files');
                    const data = await response.json();
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            }
            
            async function listExecutions() {
                try {
                    const response = await fetch('/list-executions');
                    const data = await response.json();
                    showResults(data);
                } catch (error) {
                    showResults({error: error.message});
                }
            }
            
            // Get latest IDs
            function getLatestWorkflowId() {
                if (lastWorkflowId) {
                    document.getElementById('workflow-id').value = lastWorkflowId;
                    showResults({message: `Latest workflow ID: ${lastWorkflowId}`});
                } else {
                    showResults({message: 'No workflow uploaded yet. Upload a workflow first!'});
                }
            }
            
            function getLatestDataPath() {
                if (lastDataPath) {
                    document.getElementById('data-path').value = lastDataPath;
                    showResults({message: `Latest data path: ${lastDataPath}`});
                } else {
                    showResults({message: 'No data file uploaded yet. Upload data files first!'});
                }
            }
            
            function getLatestExecutionId() {
                if (lastExecutionId) {
                    document.getElementById('execution-id').value = lastExecutionId;
                    showResults({message: `Latest execution ID: ${lastExecutionId}`});
                } else {
                    showResults({message: 'No execution started yet. Execute a workflow first!'});
                }
            }
            
            // Auto-refresh
            function startAutoRefresh() {
                if (autoRefreshInterval) {
                    clearInterval(autoRefreshInterval);
                    autoRefreshInterval = null;
                    showResults({message: 'Auto-refresh stopped! 🛑'});
                } else {
                    const executionId = document.getElementById('execution-id').value;
                    if (!executionId) {
                        showResults({message: 'Please enter an execution ID first!'});
                        return;
                    }
                    autoRefreshInterval = setInterval(checkStatus, 3000);
                    showResults({message: 'Auto-refresh started! 🔄 (every 3 seconds)'});
                }
            }
        </script>
    </body>
    </html>
    """
    return response.html(html)

if __name__ == "__main__":
    print("🚀 Starting Workflow Executor API")
    print("📋 Available endpoints:")
    print("  GET  /           - Health check")
    print("  GET  /ui         - Enhanced web interface")
    print("  POST /upload-workflow - Upload JSON workflow")
    print("  POST /upload-data     - Upload data files")
    print("  POST /execute-workflow - Execute workflow")
    print("  GET  /execution-status/<id> - Check execution status")
    print("  GET  /list-workflows  - List all workflows")
    print("  GET  /list-data-files - List all data files") 
    print("  GET  /list-executions - List all executions")
    print("\n🌐 Access enhanced UI at: http://localhost:8000/ui")
    
    app.run(host="0.0.0.0", port=8000, debug=True)