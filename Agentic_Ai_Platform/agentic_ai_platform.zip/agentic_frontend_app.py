#!/usr/bin/env python3

from sanic import Sanic, response
from sanic.request import Request
import json
import os
import asyncio
import uuid
from datetime import datetime
import traceback

# Import your existing workflow components
try:
    from enhanced_agent_runner import run_universal_workflow
    from tool_manager import tool_manager
except ImportError:
    print("Warning: Enhanced agent runner not found. Using basic workflow execution.")
    run_universal_workflow = None
    tool_manager = None

app = Sanic("WorkflowExecutor")

# Configuration
UPLOAD_DIR = "./uploads"
WORKFLOWS_DIR = "./workflows"
RESULTS_DIR = "./results"

# Ensure directories exist
for dir_path in [UPLOAD_DIR, WORKFLOWS_DIR, RESULTS_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# In-memory execution tracking
executions = {}

@app.route("/", methods=["GET"])
async def health_check(request: Request):
    """Health check endpoint"""
    return response.json({
        "status": "healthy",
        "service": "Workflow Executor",
        "timestamp": datetime.now().isoformat()
    })

@app.route("/upload-workflow", methods=["POST"])
async def upload_workflow(request: Request):
    """Upload a JSON workflow file"""
    try:
        # Handle file upload
        if 'workflow' not in request.files:
            return response.json({"error": "No workflow file provided"}, status=400)
        
        workflow_file = request.files['workflow'][0]
        workflow_id = str(uuid.uuid4())
        
        # Save workflow file
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        with open(workflow_path, 'wb') as f:
            f.write(workflow_file.body)
        
        # Validate JSON
        try:
            with open(workflow_path, 'r') as f:
                workflow_data = json.load(f)
        except json.JSONDecodeError as e:
            os.remove(workflow_path)
            return response.json({"error": f"Invalid JSON: {str(e)}"}, status=400)
        
        return response.json({
            "workflow_id": workflow_id,
            "status": "uploaded",
            "steps": len(workflow_data) if isinstance(workflow_data, list) else len(workflow_data.get("steps", [])),
            "message": "Workflow uploaded successfully"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/upload-data", methods=["POST"])
async def upload_data(request: Request):
    """Upload data files for workflow execution"""
    try:
        uploaded_files = []
        
        for field_name, file_list in request.files.items():
            for file_obj in file_list:
                file_id = str(uuid.uuid4())
                file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file_obj.name}")
                
                with open(file_path, 'wb') as f:
                    f.write(file_obj.body)
                
                uploaded_files.append({
                    "field_name": field_name,
                    "original_name": file_obj.name,
                    "file_id": file_id,
                    "file_path": file_path
                })
        
        return response.json({
            "uploaded_files": uploaded_files,
            "message": f"Uploaded {len(uploaded_files)} files successfully"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/execute-workflow", methods=["POST"])
async def execute_workflow(request: Request):
    """Execute a workflow with optional data file"""
    try:
        data = request.json
        workflow_id = data.get('workflow_id')
        data_file_path = data.get('data_file_path')
        
        if not workflow_id:
            return response.json({"error": "workflow_id required"}, status=400)
        
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        if not os.path.exists(workflow_path):
            return response.json({"error": "Workflow not found"}, status=404)
        
        # Create execution record
        execution_id = str(uuid.uuid4())
        executions[execution_id] = {
            "status": "started",
            "workflow_id": workflow_id,
            "start_time": datetime.now().isoformat(),
            "data_file": data_file_path
        }
        
        # Start execution in background
        asyncio.create_task(run_workflow_async(execution_id, workflow_path, data_file_path))
        
        return response.json({
            "execution_id": execution_id,
            "status": "started",
            "message": "Workflow execution started"
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/execution-status/<execution_id>", methods=["GET"])
async def get_execution_status(request: Request, execution_id: str):
    """Get execution status and results"""
    if execution_id not in executions:
        return response.json({"error": "Execution not found"}, status=404)
    
    execution_info = executions[execution_id]
    
    # Check if results file exists
    results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
    if os.path.exists(results_file):
        try:
            with open(results_file, 'r') as f:
                results = json.load(f)
            execution_info["results"] = results
        except Exception as e:
            execution_info["results_error"] = str(e)
    
    return response.json(execution_info)

@app.route("/list-workflows", methods=["GET"])
async def list_workflows(request: Request):
    """List all uploaded workflows"""
    try:
        workflows = []
        for filename in os.listdir(WORKFLOWS_DIR):
            if filename.endswith('.json'):
                workflow_id = filename[:-5]  # Remove .json
                workflow_path = os.path.join(WORKFLOWS_DIR, filename)
                
                try:
                    with open(workflow_path, 'r') as f:
                        workflow_data = json.load(f)
                    
                    workflows.append({
                        "workflow_id": workflow_id,
                        "steps": len(workflow_data) if isinstance(workflow_data, list) else len(workflow_data.get("steps", [])),
                        "created": datetime.fromtimestamp(os.path.getctime(workflow_path)).isoformat()
                    })
                except Exception as e:
                    workflows.append({
                        "workflow_id": workflow_id,
                        "error": str(e)
                    })
        
        return response.json({"workflows": workflows})
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/list-executions", methods=["GET"])
async def list_executions(request: Request):
    """List all workflow executions"""
    return response.json({"executions": executions})

async def run_workflow_async(execution_id: str, workflow_path: str, data_file_path: str = None):
    """Execute workflow asynchronously"""
    try:
        executions[execution_id]["status"] = "running"
        
        # Auto-discover tools
        if tool_manager:
            num_tools = tool_manager.discover_tools()
            executions[execution_id]["tools_discovered"] = num_tools
        
        # Execute workflow
        if run_universal_workflow:
            results = run_universal_workflow(workflow_path, data_file_path)
        else:
            # Fallback: basic workflow execution
            with open(workflow_path, 'r') as f:
                workflow_data = json.load(f)
            results = {"message": "Basic execution - enhanced runner not available", "workflow": workflow_data}
        
        # Save results
        results_file = os.path.join(RESULTS_DIR, f"{execution_id}_results.json")
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        executions[execution_id].update({
            "status": "completed",
            "end_time": datetime.now().isoformat(),
            "results_file": results_file
        })
        
    except Exception as e:
        executions[execution_id].update({
            "status": "failed",
            "end_time": datetime.now().isoformat(),
            "error": str(e),
            "traceback": traceback.format_exc()
        })

# Basic HTML interface for testing
@app.route("/ui", methods=["GET"])
async def web_ui(request: Request):
    """Simple web interface for testing"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Workflow Executor</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; }
            input, button { margin: 10px 0; padding: 10px; }
            button { background: #007cba; color: white; border: none; cursor: pointer; }
            .results { background: #f5f5f5; padding: 10px; white-space: pre-wrap; }
        </style>
    </head>
    <body>
        <h1>Workflow Executor API</h1>
        
        <div class="section">
            <h3>Upload Workflow</h3>
            <form id="workflow-form" enctype="multipart/form-data">
                <input type="file" name="workflow" accept=".json" required>
                <button type="submit">Upload Workflow</button>
            </form>
        </div>
        
        <div class="section">
            <h3>Upload Data Files</h3>
            <form id="data-form" enctype="multipart/form-data">
                <input type="file" name="data" multiple>
                <button type="submit">Upload Data</button>
            </form>
        </div>
        
        <div class="section">
            <h3>Execute Workflow</h3>
            <input type="text" id="workflow-id" placeholder="Workflow ID">
            <input type="text" id="data-path" placeholder="Data file path (optional)">
            <button onclick="executeWorkflow()">Execute</button>
        </div>
        
        <div class="section">
            <h3>Check Status</h3>
            <input type="text" id="execution-id" placeholder="Execution ID">
            <button onclick="checkStatus()">Check Status</button>
        </div>
        
        <div class="section">
            <button onclick="listWorkflows()">List Workflows</button>
            <button onclick="listExecutions()">List Executions</button>
        </div>
        
        <div id="results" class="results"></div>
        
        <script>
            const results = document.getElementById('results');
            
            document.getElementById('workflow-form').onsubmit = async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const response = await fetch('/upload-workflow', { method: 'POST', body: formData });
                results.textContent = JSON.stringify(await response.json(), null, 2);
            };
            
            document.getElementById('data-form').onsubmit = async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const response = await fetch('/upload-data', { method: 'POST', body: formData });
                results.textContent = JSON.stringify(await response.json(), null, 2);
            };
            
            async function executeWorkflow() {
                const workflowId = document.getElementById('workflow-id').value;
                const dataPath = document.getElementById('data-path').value;
                const response = await fetch('/execute-workflow', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({workflow_id: workflowId, data_file_path: dataPath})
                });
                results.textContent = JSON.stringify(await response.json(), null, 2);
            }
            
            async function checkStatus() {
                const executionId = document.getElementById('execution-id').value;
                const response = await fetch(`/execution-status/${executionId}`);
                results.textContent = JSON.stringify(await response.json(), null, 2);
            }
            
            async function listWorkflows() {
                const response = await fetch('/list-workflows');
                results.textContent = JSON.stringify(await response.json(), null, 2);
            }
            
            async function listExecutions() {
                const response = await fetch('/list-executions');
                results.textContent = JSON.stringify(await response.json(), null, 2);
            }
        </script>
    </body>
    </html>
    """
    return response.html(html)

if __name__ == "__main__":
    print("🚀 Starting Workflow Executor API")
    print("📋 Available endpoints:")
    print("  GET  /           - Health check")
    print("  GET  /ui         - Web interface")
    print("  POST /upload-workflow - Upload JSON workflow")
    print("  POST /upload-data     - Upload data files")
    print("  POST /execute-workflow - Execute workflow")
    print("  GET  /execution-status/<id> - Check execution status")
    print("  GET  /list-workflows  - List all workflows")
    print("  GET  /list-executions - List all executions")
    print("\n🌐 Access web UI at: http://localhost:8000/ui")
    
    app.run(host="0.0.0.0", port=8000, debug=True)