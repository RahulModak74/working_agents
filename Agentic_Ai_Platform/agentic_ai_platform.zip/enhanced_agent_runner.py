#!/usr/bin/env python3

import os
import sys
import json
import re
from typing import Dict, Any, List, Optional

# Import the enhanced workflow executor
from workflow_executor import WorkflowExecutor

# Import the necessary modules (keeping existing imports)
from tool_manager import tool_manager
from utils import (
    extract_json_from_text, 
    extract_tool_calls, 
    is_hashable, 
    log_api, 
    get_config
)

# Import the call_api function
from call_api import call_api

# Get configuration
CONFIG = get_config()

def run_agent(agent_name: str, prompt: str, file_path: Optional[str] = None, 
              output_format: Optional[Dict[str, Any]] = None,
              references: Optional[Dict[str, Any]] = None,
              required_tools: List[str] = None,
              workflow_context=None) -> Dict[str, Any]:
    """Run a single agent with the universal workflow runner (enhanced with workflow context)"""
    
    # Determine the output type and schema
    output_type = "text"
    schema = None
    sections = None
    
    if output_format:
        output_type = output_format.get("type", "text")
        schema = output_format.get("schema")
        sections = output_format.get("sections")
    
    # Enhance prompt with format instructions
    enhanced_prompt = prompt
    
    # Add reference information if provided
    if references:
        enhanced_prompt += "\n\n### Reference Information:\n"
        for ref_name, ref_content in references.items():
            enhanced_prompt += f"\n#### Output from {ref_name}:\n"
            if isinstance(ref_content, dict):
                enhanced_prompt += json.dumps(ref_content, indent=2)
            else:
                enhanced_prompt += str(ref_content)
    
    # Add workflow context variables if available
    if workflow_context and hasattr(workflow_context, 'state'):
        available_vars = workflow_context.state.get_state_summary()
        if available_vars.get('variables'):
            enhanced_prompt += "\n\n### Available Workflow Variables:\n"
            for var_name, var_value in available_vars['variables'].items():
                enhanced_prompt += f"- {var_name}: {var_value}\n"
    
    # Add file content if provided
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                file_content = f.read()
                
                # For large files, just include a limited amount
                if len(file_content) > 10000:
                    preview = file_content[:10000]
                    enhanced_prompt += f"\n\nHere is a preview of the content of {os.path.basename(file_path)}:\n```\n{preview}\n```"
                else:
                    enhanced_prompt += f"\n\nHere is the content of {os.path.basename(file_path)}:\n```\n{file_content}\n```"
            
            print(f"Successfully loaded file: {file_path}")
        except Exception as e:
            print(f"Warning: Could not read file {file_path}: {e}")
    else:
        if file_path:
            print(f"Warning: File not found: {file_path}")
    
    # Add explicit formatting instructions
    if output_type == "json" and schema:
        enhanced_prompt += "\n\n### Response Format Instructions:\n"
        enhanced_prompt += "You MUST respond with a valid JSON object exactly matching this schema:\n"
        enhanced_prompt += f"```json\n{json.dumps(schema, indent=2)}\n```\n"
        enhanced_prompt += "\nReturning properly formatted JSON is CRITICAL. Do not include any explanations or text outside the JSON object."
    elif output_type == "markdown" and sections:
        enhanced_prompt += "\n\n### Response Format Instructions:\n"
        enhanced_prompt += "You MUST format your response as a Markdown document containing these exact sections:\n\n"
        for section in sections:
            enhanced_prompt += f"# {section}\n\n"
        enhanced_prompt += "\nEnsure each section heading uses a single # character followed by the exact section name as listed above."
    
    # Build the payload
    format_type = "JSON" if output_type == "json" else "markdown"
    system_message = f"You are a specialized assistant handling {format_type} outputs. Your responses must strictly follow the format specified in the instructions."
    
    # Add domain-specific additions to system message
    if "security" in agent_name.lower() or "threat" in agent_name.lower() or "cyber" in prompt.lower():
        system_message = "You are a cybersecurity analysis assistant. " + system_message
    elif "journey" in agent_name.lower() or "customer" in agent_name.lower() or "segment" in prompt.lower():
        system_message = "You are a customer journey analysis assistant. " + system_message
    elif "finance" in agent_name.lower() or "investment" in agent_name.lower() or "portfolio" in prompt.lower():
        system_message = "You are a financial analysis assistant. " + system_message
    
    # Add tool information to prompt if required_tools is provided
    if required_tools:
        available_tools = []
        unavailable_tools = []
        
        for tool_id in required_tools:
            if tool_manager.is_tool_available(tool_id):
                available_tools.append(tool_id)
            else:
                unavailable_tools.append(tool_id)
        
        if available_tools:
            enhanced_prompt += f"\n\nYou have access to these tools: {', '.join(available_tools)}"
            system_message += """
You have access to tools specified in the instructions. To use a tool, format your response like this:

I need to use the tool: $TOOL_NAME
Parameters:
{
  "param1": "value1",
  "param2": "value2"
}

Wait for the tool result before continuing.
"""
        
        if unavailable_tools:
            enhanced_prompt += f"\n\nNote: The following tools are not available: {', '.join(unavailable_tools)}"
    
    # Define conversation for tool usage
    conversation = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": enhanced_prompt}
    ]
    
    # Output file
    output_file = os.path.join(CONFIG["output_dir"], f"{agent_name}_output.txt")
    final_response = None
    
    # Execute the call with potential tool usage loop
    print(f"🤖 Running agent: {agent_name}")
    try:
        # Initial API call
        api_response = call_api(conversation, CONFIG)
        response_content = api_response
        log_api(agent_name, enhanced_prompt, response_content)
        
        # Save the initial response for debugging
        with open(os.path.join(CONFIG["output_dir"], f"{agent_name}_initial_response.txt"), 'w', encoding='utf-8') as f:
            f.write(response_content)
        
        # Enhanced tool call handling with workflow context
        if "I need to use the tool:" in response_content:
            print(f"Detected tool call attempts in the response for {agent_name}")
            
            # Process all tool calls in the response
            all_tool_calls = extract_tool_calls(response_content)
            
            if all_tool_calls:
                # We have tool calls to process
                for idx, tool_call in enumerate(all_tool_calls[:5]):  # Limit to 5 tool calls
                    tool_name = tool_call["tool_name"]
                    params = tool_call["params"]
                    
                    print(f"📡 Processing tool call {idx+1}: {tool_name}")
                    
                    # Execute the tool with workflow context if available
                    if workflow_context and hasattr(workflow_context, 'handle_tool_execution'):
                        tool_result = workflow_context.handle_tool_execution(tool_name, **params)
                    else:
                        tool_result = tool_manager.execute_tool(tool_name, **params)
                    
                    tool_result_str = json.dumps(tool_result, indent=2)
                    
                    # Replace the tool call with the result in the response
                    tool_call_text = tool_call["full_text"]
                    response_content = response_content.replace(
                        tool_call_text, 
                        f"Tool result for {tool_name}:\n```json\n{tool_result_str}\n```"
                    )
                
                # Now get a new response with the tool results incorporated
                final_prompt = f"Here is the result of executing your tool calls:\n\n{response_content}\n\nBased on these results, please provide your final response."
                
                # Add this to the conversation
                conversation.append({"role": "assistant", "content": api_response})
                conversation.append({"role": "user", "content": final_prompt})
                
                # Get the final response
                final_response = call_api(conversation, CONFIG)
            else:
                # No valid tool calls found, use the original response
                final_response = response_content
        else:
            # The response doesn't contain tool calls, use it directly
            final_response = response_content
        
        # Save the content to the output file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(final_response)
        
        # Process based on output type
        if output_type == "json":
            result = extract_json_from_text(final_response)
            if "error" in result:
                print(f"⚠️ Warning: JSON extraction failed for {agent_name}. Content: {final_response[:100]}...")
            print(f"✅ {agent_name} completed")
            return result
        elif output_type == "markdown":
            # Verify sections if required
            if sections:
                missing_sections = []
                for section in sections:
                    if not re.search(rf"#\s*{re.escape(section)}", final_response, re.IGNORECASE):
                        missing_sections.append(section)
                
                if missing_sections:
                    print(f"Warning: Missing {len(missing_sections)} required sections in markdown output")
            
            print(f"✅ {agent_name} completed")
            return {"markdown_content": final_response}
        else:
            print(f"✅ {agent_name} completed")
            return {"text_content": final_response}
    
    except Exception as e:
        print(f"❌ Error with {agent_name}: {e}")
        return {"error": f"Error: {str(e)}", "content": str(e)}

def run_universal_workflow(workflow_file: str, data_file: str = None):
    """Run any workflow using the enhanced universal approach with flow control"""
    
    # Get the directory where the workflow file is located
    workflow_dir = os.path.dirname(os.path.abspath(workflow_file))
    
    # First, discover all tools in the current directory and subdirectories
    num_tools = tool_manager.discover_tools()
    print(f"🔧 Auto-discovered {num_tools} tools")
    
    # Load the workflow
    with open(workflow_file, 'r', encoding='utf-8') as f:
        workflow_data = json.load(f)
    
    # Create the enhanced workflow executor
    executor = WorkflowExecutor(tool_manager, run_agent)
    
    # Inject the workflow context into the run_agent function
    def run_agent_with_context(*args, **kwargs):
        kwargs['workflow_context'] = executor.context
        return run_agent(*args, **kwargs)
    
    # Update executor's run_agent reference
    executor.run_agent = run_agent_with_context
    
    # Execute the workflow with the enhanced executor
    print(f"🚀 Executing enhanced workflow: {workflow_file}")
    results = executor.execute_workflow(workflow_data, data_file)
    
    # Save the complete results
    output_file = os.path.join(CONFIG["output_dir"], "enhanced_workflow_results.json")
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"Complete enhanced analysis saved to {output_file}")
    except Exception as e:
        print(f"Error saving results: {e}")
    
    return results

def main():
    """Main function with enhanced workflow support"""
    # Parse command line arguments
    if len(sys.argv) > 1 and sys.argv[1] == "--workflow":
        if len(sys.argv) < 3:
            print("Usage: python enhanced_agent_runner.py --workflow <workflow_file> [data_file]")
            sys.exit(1)
        
        workflow_file = sys.argv[2]
        
        if not os.path.exists(workflow_file):
            print(f"Workflow file not found: {workflow_file}")
            sys.exit(1)
        
        data_file = None
        if len(sys.argv) > 3:
            data_file = sys.argv[3]
            if not os.path.exists(data_file):
                print(f"Data file not found: {data_file}")
                sys.exit(1)
        
        # Run the enhanced workflow
        print(f"🚀 Executing enhanced workflow: {workflow_file}")
        results = run_universal_workflow(workflow_file, data_file)
        
        # Print a summary of the results
        print("\n🎉 Enhanced workflow completed with results:")
        for agent, result in results.items():
            if agent == "workflow_state":
                print(f"\n=== Workflow State Summary ===")
                if isinstance(result, dict):
                    for key, value in result.items():
                        print(f"{key}: {value}")
            elif isinstance(result, dict) and "error" in result:
                print(f"\n=== {agent} ===")
                print(f"❌ Error: {result['error']}")
            else:
                print(f"\n=== {agent} ===")
                print("✅ Success")
    else:
        # Start the interactive CLI if available
        try:
            from cli import AgentShell
            AgentShell().cmdloop()
        except ImportError:
            print("Error: Could not import AgentShell from cli")
            print("Usage: python enhanced_agent_runner.py --workflow <workflow_file> [data_file]")
            sys.exit(1)

# When this file is run directly, execute main()
if __name__ == "__main__":
    # Ensure the main directory is in the path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)

    # Also ensure COMPONENT directory is in the path
    component_dir = os.path.join(current_dir, "COMPONENT")
    if os.path.exists(component_dir) and component_dir not in sys.path:
        sys.path.insert(0, component_dir)
        
    main()