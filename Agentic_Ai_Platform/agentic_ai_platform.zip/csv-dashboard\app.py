import os
import csv
import json
import traceback
import requests
import pandas as pd
import numpy as np
import io
from datetime import datetime, timedelta
from flask import Flask, render_template, request, send_file, jsonify, redirect, make_response, session
from werkzeug.utils import secure_filename
import logging

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Generate a random secret key

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Ensure upload and insights folders exist
os.makedirs('uploads', exist_ok=True)
os.makedirs('insights', exist_ok=True)

# Ollama configuration
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "deepseek-r1:7b"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_csv():
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
        
        if file and file.filename.endswith('.csv'):
            filename = secure_filename(file.filename)
            filepath = os.path.join('uploads', filename)
            file.save(filepath)
            
            logger.info(f'Uploaded file: {filename} - {filepath}')
            
            with open('uploads/latest_csv.txt', 'w') as f:
                f.write(filename)  # Store just the filename, not the full path
            
            try:
                df = pd.read_csv(filepath)
                if df.empty:
                    return jsonify({"error": "The CSV file is empty"}), 400
            except Exception as csv_error:
                logger.error(f'Error reading CSV file: {str(csv_error)}')
                logger.error(traceback.format_exc())
                return jsonify({"error": f"Error reading CSV file: {str(csv_error)}"}), 400
            
            insights = generate_ai_insights(filepath)
            
            if not insights:
                return jsonify({"error": "Failed to generate insights from the AI"}), 500
            
            insights_path = os.path.join('insights', 'latest_insights.json')
            with open(insights_path, 'w') as f:
                json.dump(insights, f)
            
            logger.info(f'Saved insights to {insights_path}')
            
            return redirect('/dashboard')
        
        return jsonify({"error": "Invalid file type. Please upload a CSV."}), 400
    
    except Exception as e:
        logger.error(f"Unexpected error in upload: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({"error": f"Unexpected error during upload: {str(e)}"}), 500

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/get_insights')
def get_insights():
    insights_path = os.path.join('insights', 'latest_insights.json')
    
    try:
        with open(insights_path, 'r') as f:
            insights = json.load(f)
        return jsonify(insights)
    except FileNotFoundError:
        return jsonify({"error": "No insights found"}), 404

@app.route('/insights_csv')
def insights_csv():
    insights_path = os.path.join('insights', 'latest_insights.json')
    
    try:
        with open(insights_path, 'r') as f:
            insights = json.load(f)
        
        csv_data = []
        for insight in insights:
            csv_data.append({
                'title': insight['title'],
                'description': insight['description'],
                'chart_type': insight['chart_type'],
                'x_axis': insight['x_axis'],
                'y_axis': insight['y_axis']
            })
        
        si = io.StringIO()
        cw = csv.DictWriter(si, fieldnames=csv_data[0].keys())
        cw.writeheader()
        cw.writerows(csv_data)
        output = make_response(si.getvalue())
        output.headers["Content-Disposition"] = "attachment; filename=insights.csv"
        output.headers["Content-type"] = "text/csv"
        return output
    except FileNotFoundError:
        return jsonify({"error": "No insights found"}), 404

@app.route('/get_csv_data')
def get_csv_data():
    try:
        # Get the filename of the most recently uploaded CSV file
        with open('uploads/latest_csv.txt', 'r') as f:
            filename = f.read().strip()
        
        # Construct the full path
        filepath = os.path.join('uploads', filename)
        
        # Read the CSV file
        df = pd.read_csv(filepath)
        
        # Handle NaN values before converting to JSON
        # Replace NaN with None which will be converted to null in JSON
        df = df.replace({np.nan: None})
        
        # Convert DataFrame to list of dictionaries
        data = df.to_dict(orient='records')
        
        return jsonify(data)
    except FileNotFoundError:
        logger.error(f"CSV file not found")
        return jsonify({"error": "No CSV file found"}), 404
    except Exception as e:
        logger.error(f"Error reading CSV data: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({"error": f"Error reading CSV data: {str(e)}"}), 500

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """Serve uploaded files"""
    return send_file(os.path.join('uploads', filename))

def call_ollama(prompt):
    """Call local Ollama API"""
    try:
        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        }
        
        response = requests.post(
            f"{OLLAMA_BASE_URL}/api/generate",
            json=payload,
            timeout=120  # Increase timeout for local processing
        )
        
        if response.status_code == 200:
            result = response.json()
            return result.get('response', '')
        else:
            logger.error(f"Ollama API error: {response.status_code} - {response.text}")
            return None
            
    except requests.RequestException as e:
        logger.error(f"Error calling Ollama API: {e}")
        return None

def generate_ai_insights(filepath):
    try:
        df = pd.read_csv(filepath)
        df.columns = [col.strip() for col in df.columns]
        
        column_stats = {}
        categorical_columns = []
        numeric_columns = []
        date_columns = []
        
        for col in df.columns:
            if df[col].dtype == 'object':
                value_counts = df[col].value_counts().head(5).to_dict()
                null_count = df[col].isna().sum()
                categorical_columns.append(col)
                column_stats[col] = {
                    'type': 'categorical',
                    'unique_values': df[col].nunique(),
                    'top_values': value_counts,
                    'null_count': null_count,
                    'null_percentage': (null_count / len(df)) * 100
                }
            elif pd.api.types.is_numeric_dtype(df[col]):
                numeric_columns.append(col)
                column_stats[col] = {
                    'type': 'numeric',
                    'min': float(df[col].min()) if not pd.isna(df[col].min()) else 0,
                    'max': float(df[col].max()) if not pd.isna(df[col].max()) else 0,
                    'mean': float(df[col].mean()) if not pd.isna(df[col].mean()) else 0,
                    'median': float(df[col].median()) if not pd.isna(df[col].median()) else 0,
                    'null_count': df[col].isna().sum(),
                    'null_percentage': (df[col].isna().sum() / len(df)) * 100
                }
            
            try:
                if df[col].dtype == 'object':
                    date_series = pd.to_datetime(df[col], errors='coerce')
                    if date_series.notna().sum() > 0.7 * len(df):
                        date_columns.append(col)
                        column_stats[col]['type'] = 'date'
                        column_stats[col]['min_date'] = str(date_series.min())
                        column_stats[col]['max_date'] = str(date_series.max())
            except:
                pass
        
        prompt = f"""Analyze the following CSV data and provide 6 key insights for visualizations:

Data Overview:
- CSV Filename: {os.path.basename(filepath)}
- Total Rows: {len(df)}
- Total Columns: {len(df.columns)}

Column Types:
- Categorical Columns: {', '.join(categorical_columns)}
- Numeric Columns: {', '.join(numeric_columns)}
- Date Columns: {', '.join(date_columns)}

Column Details:
"""
        for col, stats in column_stats.items():
            prompt += f"\n{col} ({stats['type']}):\n"
            if stats['type'] == 'categorical':
                prompt += f"  - Unique Values: {stats['unique_values']}\n"
                prompt += f"  - Top Values: {str(stats['top_values'])}\n"
                prompt += f"  - Null Values: {stats['null_count']} ({stats['null_percentage']:.1f}%)\n"
            elif stats['type'] == 'numeric':
                prompt += f"  - Range: {stats['min']} to {stats['max']}\n"
                prompt += f"  - Mean: {stats['mean']}\n"
                prompt += f"  - Median: {stats['median']}\n"
                prompt += f"  - Null Values: {stats['null_count']} ({stats['null_percentage']:.1f}%)\n"
            elif stats['type'] == 'date':
                prompt += f"  - Date Range: {stats['min_date']} to {stats['max_date']}\n"
        
        prompt += f"\nSample Data (first 5 rows):\n{df.head().to_string()}\n\n"
        
        prompt += """
Based on this data, provide 6 insights for visualization. Each insight should use a different chart type: bar chart, line chart, pie chart, scatter plot, horizontal bar chart, and doughnut chart.

Provide insights in this strict JSON format:
[
    {
        "title": "Clear insightful title",
        "description": "Detailed explanation of the insight",
        "chart_type": "bar|line|pie|scatter|horizontalBar|doughnut",
        "x_axis": "ColumnName",
        "y_axis": "ColumnName or COUNT(ColumnName)"
    },
    ...
]

CRITICAL RULES:
1. Use only existing column names from the data
2. Use exactly these 6 different chart types: bar, line, pie, scatter, horizontalBar, doughnut
3. Choose meaningful columns that exist in the data
4. Ensure valuable business insights
5. Return EXACTLY 6 insight objects
6. Return ONLY the JSON array, no other text
7. Make sure x_axis and y_axis refer to actual column names that exist
"""
        
        try:
            ai_response = call_ollama(prompt)
            
            if not ai_response:
                logger.error("No response from Ollama")
                return generate_fallback_insights(df)
            
            logger.info(f"Raw AI Response: {ai_response}")
            
            try:
                # Clean up the response
                if ai_response.startswith('```json'):
                    ai_response = ai_response[7:-3]
                elif ai_response.startswith('```'):
                    ai_response = ai_response[3:-3]
                
                # Try to extract JSON from the response
                start_idx = ai_response.find('[')
                end_idx = ai_response.rfind(']') + 1
                
                if start_idx != -1 and end_idx > start_idx:
                    json_str = ai_response[start_idx:end_idx]
                    insights_data = json.loads(json_str)
                else:
                    insights_data = json.loads(ai_response)
                
                if not isinstance(insights_data, list):
                    insights_data = [insights_data]
                
                # Validate and fix insights
                valid_insights = []
                chart_types = ['bar', 'line', 'pie', 'scatter', 'horizontalBar', 'doughnut']
                used_types = set()
                
                for insight in insights_data:
                    insight.setdefault('title', 'Untitled Insight')
                    insight.setdefault('description', 'No description provided')
                    insight.setdefault('chart_type', 'bar')
                    
                    # Ensure chart type is valid and unique
                    if insight['chart_type'] not in chart_types or insight['chart_type'] in used_types:
                        for chart_type in chart_types:
                            if chart_type not in used_types:
                                insight['chart_type'] = chart_type
                                break
                    
                    used_types.add(insight['chart_type'])
                    
                    # Validate axis columns exist in dataframe
                    if not insight.get('x_axis') or insight['x_axis'] not in df.columns:
                        insight['x_axis'] = df.columns[0]
                    
                    if not insight.get('y_axis'):
                        if len(numeric_columns) > 0:
                            insight['y_axis'] = numeric_columns[0]
                        else:
                            insight['y_axis'] = f"COUNT({df.columns[0]})"
                    elif insight['y_axis'] not in df.columns and not insight['y_axis'].startswith('COUNT('):
                        if len(numeric_columns) > 0:
                            insight['y_axis'] = numeric_columns[0]
                        else:
                            insight['y_axis'] = f"COUNT({insight['x_axis']})"
                    
                    valid_insights.append(insight)
                
                # Ensure we have exactly 6 insights
                while len(valid_insights) < 6:
                    remaining_types = [t for t in chart_types if t not in [i['chart_type'] for i in valid_insights]]
                    chart_type = remaining_types[0] if remaining_types else 'bar'
                    
                    valid_insights.append({
                        'title': f'Additional Insight {len(valid_insights) + 1}',
                        'description': 'Automatically generated to meet requirement',
                        'chart_type': chart_type,
                        'x_axis': df.columns[0],
                        'y_axis': f"COUNT({df.columns[0]})"
                    })
                
                valid_insights = valid_insights[:6]
                
                return valid_insights
            
            except json.JSONDecodeError as json_err:
                logger.error(f"JSON Parsing Error: {json_err}")
                logger.error(f"Problematic Response: {ai_response}")
                return generate_fallback_insights(df)
        
        except Exception as ai_error:
            logger.error(f"Error calling AI: {ai_error}")
            return generate_fallback_insights(df)
    
    except Exception as e:
        logger.error(f"Unexpected error generating insights: {e}")
        logger.error(traceback.format_exc())
        return generate_fallback_insights(df)

def generate_fallback_insights(df):
    """Generate basic insights when AI fails"""
    categorical_columns = [col for col in df.columns if df[col].dtype == 'object']
    numeric_columns = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]
    
    insights = []
    chart_types = ['bar', 'line', 'pie', 'scatter', 'horizontalBar', 'doughnut']
    
    for i, chart_type in enumerate(chart_types):
        if i < len(df.columns):
            x_col = df.columns[i % len(df.columns)]
            if len(numeric_columns) > 0:
                y_col = numeric_columns[i % len(numeric_columns)]
            else:
                y_col = f"COUNT({x_col})"
            
            insights.append({
                'title': f'Analysis of {x_col}',
                'description': f'Basic {chart_type} chart showing {x_col} data',
                'chart_type': chart_type,
                'x_axis': x_col,
                'y_axis': y_col
            })
        else:
            insights.append({
                'title': f'Data Overview {i+1}',
                'description': f'Basic {chart_type} chart',
                'chart_type': chart_type,
                'x_axis': df.columns[0],
                'y_axis': f"COUNT({df.columns[0]})"
            })
    
    return insights

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)