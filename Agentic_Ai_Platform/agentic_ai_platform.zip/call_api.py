import subprocess
import json
import requests

def call_api(conversation, config):
    """
    Call the API with the given conversation and configuration.
    Updated to work with both OpenAI-compatible and native Ollama endpoints.
    """
    
    # Check if using Ollama
    if "localhost:11434" in config["endpoint"]:
        return call_ollama_api(conversation, config)
    else:
        return call_openai_api(conversation, config)

def call_ollama_api(conversation, config):
    """Call Ollama API using requests instead of curl"""
    try:
        # Use requests for better error handling
        if "/v1/chat/completions" in config["endpoint"]:
            # OpenAI-compatible format
            payload = {
                "model": config["default_model"],
                "messages": conversation,
                "stream": False
            }
            
            response = requests.post(
                config["endpoint"],
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=60
            )
            
            if response.status_code == 200:
                json_response = response.json()
                content = json_response.get('choices', [{}])[0].get('message', {}).get('content', '')
                return content
            else:
                return f"Error: HTTP {response.status_code} - {response.text}"
                
        else:
            # Native Ollama format
            payload = {
                "model": config["default_model"],
                "messages": conversation,
                "stream": False
            }
            
            response = requests.post(
                config["endpoint"],
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=60
            )
            
            if response.status_code == 200:
                json_response = response.json()
                content = json_response.get('message', {}).get('content', '')
                return content
            else:
                return f"Error: HTTP {response.status_code} - {response.text}"
                
    except requests.exceptions.ConnectionError:
        return "Error: Cannot connect to Ollama. Make sure Ollama is running with: ollama serve"
    except requests.exceptions.Timeout:
        return "Error: Request timed out. The model might be loading."
    except Exception as e:
        return f"Error: {str(e)}"

def call_openai_api(conversation, config):
    """Original curl-based API call for OpenAI/OpenRouter"""
    payload = {
        "model": config["default_model"],
        "messages": conversation
    }

    # Safely encode the payload to JSON
    payload_str = json.dumps(payload).replace("'", "'\\''")

    curl_command = f"""curl {config["endpoint"]} \\
      -H "Authorization: Bearer {config["api_key"]}" \\
      -H "Content-Type: application/json" \\
      -d '{payload_str}'"""

    output_file = "temp_output.json"
    try:
        subprocess.run(curl_command + f" -o {output_file}", shell=True, check=True, timeout=3600)
        
        with open(output_file, 'r', encoding='utf-8') as f:
            response = f.read()

        json_response = json.loads(response)

        content = json_response.get('content', '') or \
                  json_response.get('choices', [{}])[0].get('message', {}).get('content', '')

        return content

    except Exception as e:
        print(f"Error calling API: {e}")
        return f"Error: {str(e)}"