#!/usr/bin/env python3

from typing import Dict, Any, List, Optional, Union
import logging
import time
import json

logger = logging.getLogger("flow_control")

# Set tool namespace
TOOL_NAMESPACE = "flow"

def repeat_until(condition: str, max_iterations: int = 100, **kwargs) -> Dict[str, Any]:
    """
    Tool for repeat execution until condition is met.
    This is a marker tool - actual execution is handled by the workflow executor.
    
    Args:
        condition: Condition string to evaluate
        max_iterations: Maximum number of iterations
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "repeat_until",
        "condition": condition,
        "max_iterations": max_iterations,
        "parameters": kwargs
    }

def repeat_count(count: int, **kwargs) -> Dict[str, Any]:
    """
    Tool for executing steps N times.
    
    Args:
        count: Number of times to repeat
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control", 
        "flow_type": "repeat_count",
        "count": count,
        "parameters": kwargs
    }

def while_condition(condition: str, max_iterations: int = 100, **kwargs) -> Dict[str, Any]:
    """
    Tool for while loop execution.
    
    Args:
        condition: Condition to check before each iteration
        max_iterations: Safety limit on iterations
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "while_condition", 
        "condition": condition,
        "max_iterations": max_iterations,
        "parameters": kwargs
    }

def for_each(collection: Union[str, List], item_variable: str = "current_item", **kwargs) -> Dict[str, Any]:
    """
    Tool for iterating over collections.
    
    Args:
        collection: Collection to iterate over (variable name or actual list)
        item_variable: Variable name to store current item
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "for_each",
        "collection": collection,
        "item_variable": item_variable,
        "parameters": kwargs
    }

def if_then_else(condition: str, **kwargs) -> Dict[str, Any]:
    """
    Tool for conditional execution.
    
    Args:
        condition: Condition to evaluate
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "if_then_else",
        "condition": condition,
        "parameters": kwargs
    }

def switch_case(switch_variable: str, **kwargs) -> Dict[str, Any]:
    """
    Tool for multi-way branching.
    
    Args:
        switch_variable: Variable to switch on
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "switch_case",
        "switch_variable": switch_variable,
        "parameters": kwargs
    }

def parallel_execution(max_parallel: int = 5, **kwargs) -> Dict[str, Any]:
    """
    Tool for parallel step execution.
    
    Args:
        max_parallel: Maximum number of parallel executions
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "parallel_execution",
        "max_parallel": max_parallel,
        "parameters": kwargs
    }

def sequential_batch(batch_size: int = 10, **kwargs) -> Dict[str, Any]:
    """
    Tool for processing items in batches.
    
    Args:
        batch_size: Number of items per batch
        
    Returns:
        Configuration for the workflow executor
    """
    return {
        "tool_type": "flow_control",
        "flow_type": "sequential_batch",
        "batch_size": batch_size,
        "parameters": kwargs
    }

# State management tools
def save_checkpoint(checkpoint_name: str, **kwargs) -> Dict[str, Any]:
    """
    Save current workflow state as checkpoint.
    
    Args:
        checkpoint_name: Name for the checkpoint
        
    Returns:
        Success status
    """
    # This will be handled by the workflow context
    return {
        "tool_type": "state_management",
        "operation": "save_checkpoint",
        "checkpoint_name": checkpoint_name,
        "parameters": kwargs
    }

def restore_checkpoint(checkpoint_name: str, **kwargs) -> Dict[str, Any]:
    """
    Restore workflow state from checkpoint.
    
    Args:
        checkpoint_name: Name of checkpoint to restore
        
    Returns:
        Success status
    """
    return {
        "tool_type": "state_management", 
        "operation": "restore_checkpoint",
        "checkpoint_name": checkpoint_name,
        "parameters": kwargs
    }

def set_variable(variable_name: str, value: Any, scope: str = None, **kwargs) -> Dict[str, Any]:
    """
    Set workflow variable.
    
    Args:
        variable_name: Name of variable
        value: Value to set
        scope: Scope to set variable in (current scope if None)
        
    Returns:
        Success status
    """
    return {
        "tool_type": "state_management",
        "operation": "set_variable", 
        "variable_name": variable_name,
        "value": value,
        "scope": scope,
        "parameters": kwargs
    }

def get_variable(variable_name: str, scope: str = None, **kwargs) -> Dict[str, Any]:
    """
    Get workflow variable.
    
    Args:
        variable_name: Name of variable
        scope: Scope to get variable from
        
    Returns:
        Variable value
    """
    return {
        "tool_type": "state_management",
        "operation": "get_variable",
        "variable_name": variable_name, 
        "scope": scope,
        "parameters": kwargs
    }

def clear_variables(scope: str = None, **kwargs) -> Dict[str, Any]:
    """
    Clear variables in scope.
    
    Args:
        scope: Scope to clear (current scope if None)
        
    Returns:
        Success status
    """
    return {
        "tool_type": "state_management",
        "operation": "clear_variables",
        "scope": scope,
        "parameters": kwargs
    }

def push_scope(scope_name: str, variables: Dict[str, Any] = None, **kwargs) -> Dict[str, Any]:
    """
    Create new execution scope.
    
    Args:
        scope_name: Name for new scope
        variables: Initial variables for scope
        
    Returns:
        Success status
    """
    return {
        "tool_type": "state_management",
        "operation": "push_scope",
        "scope_name": scope_name,
        "variables": variables or {},
        "parameters": kwargs
    }

def pop_scope(**kwargs) -> Dict[str, Any]:
    """
    Return to parent scope.
    
    Returns:
        Information about popped scope
    """
    return {
        "tool_type": "state_management",
        "operation": "pop_scope",
        "parameters": kwargs
    }

def get_workflow_status(**kwargs) -> Dict[str, Any]:
    """
    Get current workflow execution status.
    
    Returns:
        Workflow status information
    """
    return {
        "tool_type": "state_management",
        "operation": "get_status",
        "parameters": kwargs
    }

def increment_counter(counter_name: str, **kwargs) -> Dict[str, Any]:
    """
    Increment a counter variable.
    
    Args:
        counter_name: Name of counter
        
    Returns:
        New counter value
    """
    return {
        "tool_type": "state_management",
        "operation": "increment_counter",
        "counter_name": counter_name,
        "parameters": kwargs
    }

def reset_counter(counter_name: str, **kwargs) -> Dict[str, Any]:
    """
    Reset counter to 0.
    
    Args:
        counter_name: Name of counter to reset
        
    Returns:
        Success status
    """
    return {
        "tool_type": "state_management",
        "operation": "reset_counter", 
        "counter_name": counter_name,
        "parameters": kwargs
    }

def delay_execution(seconds: float, **kwargs) -> Dict[str, Any]:
    """
    Add delay to workflow execution.
    
    Args:
        seconds: Number of seconds to delay
        
    Returns:
        Success status
    """
    time.sleep(seconds)
    return {
        "success": True,
        "delayed_seconds": seconds,
        "message": f"Delayed execution by {seconds} seconds"
    }

def log_message(message: str, level: str = "info", **kwargs) -> Dict[str, Any]:
    """
    Log a message during workflow execution.
    
    Args:
        message: Message to log
        level: Log level (debug, info, warning, error)
        
    Returns:
        Success status
    """
    log_func = getattr(logger, level.lower(), logger.info)
    log_func(f"Workflow: {message}")
    
    return {
        "success": True,
        "message": message,
        "level": level
    }

# Tool registry for manual registration if needed
TOOL_REGISTRY = {
    "repeat_until": repeat_until,
    "repeat_count": repeat_count, 
    "while_condition": while_condition,
    "for_each": for_each,
    "if_then_else": if_then_else,
    "switch_case": switch_case,
    "parallel_execution": parallel_execution,
    "sequential_batch": sequential_batch,
    "save_checkpoint": save_checkpoint,
    "restore_checkpoint": restore_checkpoint,
    "set_variable": set_variable,
    "get_variable": get_variable,
    "clear_variables": clear_variables,
    "push_scope": push_scope,
    "pop_scope": pop_scope,
    "get_workflow_status": get_workflow_status,
    "increment_counter": increment_counter,
    "reset_counter": reset_counter,
    "delay_execution": delay_execution,
    "log_message": log_message
}

print("✅ Flow control and state management tools loaded")