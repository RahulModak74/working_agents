#!/usr/bin/env python3

import os
import sys
import json
import uuid
import asyncio
import pandas as pd
from sanic import Sanic, Request, response
from sanic.response import html, json as json_response, file_stream
from sanic_cors import CORS
import aiofiles
from typing import Dict, Any, List
import logging

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Import our existing modules
from agent_runner import run_universal_workflow
from tool_manager import tool_manager
from utils import get_config

# Update the tool manager to exclude the web app file
tool_manager.excluded_files.add('app.py')

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sanic_app")

# Create Sanic app
app = Sanic("MLWorkflowApp")
CORS(app)

# Configuration
UPLOAD_DIR = os.path.join(current_dir, "uploads")
WORKFLOWS_DIR = os.path.join(current_dir, "generated_workflows")
RESULTS_DIR = os.path.join(current_dir, "results")

# Ensure directories exist
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(WORKFLOWS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# Store active sessions
active_sessions = {}

class WorkflowGenerator:
    """Generate workflow JSON based on user requirements"""
    
    @staticmethod
    def analyze_csv_columns(file_path: str) -> Dict[str, Any]:
        """Analyze CSV to understand column types and suggest targets"""
        try:
            df = pd.read_csv(file_path)
            
            column_info = {}
            for col in df.columns:
                dtype = str(df[col].dtype)
                unique_count = int(df[col].nunique())  # Convert to Python int
                
                # Get sample values and convert numpy types to Python types
                sample_values = []
                for val in df[col].dropna().head(5):
                    if pd.isna(val):
                        sample_values.append(None)
                    elif isinstance(val, (pd.Timestamp, pd.Period)):
                        sample_values.append(str(val))
                    elif hasattr(val, 'item'):  # numpy scalar
                        sample_values.append(val.item())
                    else:
                        sample_values.append(val)
                
                # Determine if likely categorical or numerical
                is_categorical = (dtype == 'object' or unique_count < 10)
                
                column_info[col] = {
                    "dtype": dtype,
                    "unique_count": unique_count,
                    "sample_values": sample_values,
                    "is_categorical": is_categorical,
                    "null_count": int(df[col].isnull().sum())  # Convert to Python int
                }
            
            return {
                "columns": column_info,
                "total_rows": int(len(df)),  # Convert to Python int
                "shape": [int(df.shape[0]), int(df.shape[1])],  # Convert tuple to list of ints
                "suggested_targets": [col for col, info in column_info.items() 
                                    if info["is_categorical"] and info["unique_count"] <= 20]
            }
        except Exception as e:
            logger.error(f"Error analyzing CSV: {e}")
            import traceback
            logger.error(f"Full traceback: {traceback.format_exc()}")
            return {"error": str(e)}
    
    @staticmethod
    def generate_workflow(requirements: Dict[str, Any], csv_filename: str, csv_full_path: str) -> Dict[str, Any]:
        """Generate workflow JSON based on requirements"""
        
        task_type = requirements.get("task_type", "classification").lower()
        target_column = requirements.get("target_column", "target")
        algorithms = requirements.get("algorithms", ["random_forest"])
        test_size = requirements.get("test_size", 0.2)
        
        # Generate unique model IDs
        session_id = str(uuid.uuid4())[:8]
        
        workflow = []
        
        # Training step for each algorithm
        for i, algorithm in enumerate(algorithms):
            model_id = f"{task_type}_{algorithm}_{session_id}"
            
            # Training agent - use full path to CSV
            training_step = {
                "agent": f"trainer_{algorithm}_{i}",
                "content": f"""Train a {algorithm} {task_type} model on the uploaded dataset. Use these EXACT parameters:

I need to use the tool: ml:train_model
Parameters:
{{
  "data": "{csv_full_path}",
  "model_type": "{task_type}",
  "algorithm": "{algorithm}",
  "target_column": "{target_column}",
  "test_size": {test_size},
  "model_id": "{model_id}"
}}

Analyze the training results and provide insights.""",
                "tools": ["ml:train_model"],
                "output_format": {
                    "type": "json",
                    "schema": {
                        "model_id": "string",
                        "accuracy": "number",
                        "algorithm": "string",
                        "training_status": "string",
                        "metrics": "object",
                        "insights": "string"
                    }
                }
            }
            
            workflow.append(training_step)
            
            # Evaluation step
            eval_step = {
                "agent": f"evaluator_{algorithm}_{i}",
                "content": f"""Evaluate the {algorithm} model using cross-validation:

I need to use the tool: ml:evaluate_model
Parameters:
{{
  "model_id": "{model_id}",
  "data": "{csv_full_path}",
  "cv_folds": 5
}}

Provide detailed evaluation insights.""",
                "tools": ["ml:evaluate_model"],
                "readFrom": [f"trainer_{algorithm}_{i}"],
                "output_format": {
                    "type": "json",
                    "schema": {
                        "cv_accuracy_mean": "number",
                        "cv_accuracy_std": "number",
                        "model_id": "string",
                        "evaluation_status": "string",
                        "performance_analysis": "string"
                    }
                }
            }
            
            workflow.append(eval_step)
            
            # Prediction step
            pred_step = {
                "agent": f"predictor_{algorithm}_{i}",
                "content": f"""Make predictions with the {algorithm} model:

I need to use the tool: ml:predict
Parameters:
{{
  "model_id": "{model_id}",
  "data": "{csv_full_path}"
}}

Analyze prediction results and model performance.""",
                "tools": ["ml:predict"],
                "readFrom": [f"trainer_{algorithm}_{i}"],
                "output_format": {
                    "type": "json",
                    "schema": {
                        "num_predictions": "number",
                        "test_accuracy": "number",
                        "model_id": "string",
                        "prediction_status": "string",
                        "prediction_insights": "string"
                    }
                }
            }
            
            workflow.append(pred_step)
        
        # Comparison step if multiple algorithms
        if len(algorithms) > 1:
            comparison_step = {
                "agent": "model_comparator",
                "content": f"""Compare all trained models and recommend the best one. Analyze:
1. Training accuracy and metrics
2. Cross-validation performance 
3. Prediction accuracy
4. Model complexity and interpretability
5. Provide final recommendation

Reference all previous training, evaluation, and prediction results.""",
                "readFrom": ["*"],
                "output_format": {
                    "type": "json",
                    "schema": {
                        "best_model": "string",
                        "comparison_metrics": "object",
                        "recommendation_reason": "string",
                        "model_rankings": "array"
                    }
                }
            }
            
            workflow.append(comparison_step)
        
        return {
            "workflow": workflow,
            "session_id": session_id,
            "metadata": {
                "task_type": task_type,
                "target_column": target_column,
                "algorithms": algorithms,
                "csv_file": csv_filename,
                "csv_full_path": csv_full_path,
                "test_size": test_size
            }
        }

# Initialize tools on startup
@app.before_server_start
async def setup_tools(app, loop):
    """Initialize tools before server starts"""
    logger.info("Discovering ML tools...")
    num_tools = tool_manager.discover_tools()
    logger.info(f"Discovered {num_tools} tools")
    
    if num_tools == 0:
        logger.warning("No tools discovered! Check dependencies.")

@app.route("/")
async def index(request: Request):
    """Serve the main HTML page"""
    return await response.file_stream(
        os.path.join(current_dir, "templates", "index.html"),
        headers={"Content-Type": "text/html"}
    )

@app.route("/static/<file_path:path>")
async def static_files(request: Request, file_path: str):
    """Serve static files"""
    static_dir = os.path.join(current_dir, "static")
    file_full_path = os.path.join(static_dir, file_path)
    
    if not os.path.exists(file_full_path):
        return response.text("File not found", status=404)
    
    return await response.file_stream(file_full_path)

@app.route("/upload", methods=["POST"])
async def upload_csv(request: Request):
    """Handle CSV file upload and analysis"""
    try:
        if "csv_file" not in request.files:
            return json_response({"error": "No CSV file uploaded"}, status=400)
        
        csv_file = request.files["csv_file"][0]
        
        # Validate file type
        if not csv_file.name.endswith('.csv'):
            return json_response({"error": "Please upload a CSV file"}, status=400)
        
        # Generate unique filename
        session_id = str(uuid.uuid4())
        filename = f"{session_id}_{csv_file.name}"
        file_path = os.path.join(UPLOAD_DIR, filename)
        
        # Save file
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(csv_file.body)
        
        # Analyze CSV
        analysis = WorkflowGenerator.analyze_csv_columns(file_path)
        
        if "error" in analysis:
            return json_response({"error": f"CSV analysis failed: {analysis['error']}"}, status=400)
        
        # Store session info
        active_sessions[session_id] = {
            "filename": filename,
            "file_path": file_path,
            "analysis": analysis,
            "created_at": pd.Timestamp.now().isoformat()
        }
        
        return json_response({
            "session_id": session_id,
            "filename": csv_file.name,
            "analysis": analysis
        })
        
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return json_response({"error": f"Upload failed: {str(e)}"}, status=500)

@app.route("/generate_workflow", methods=["POST"])
async def generate_workflow_endpoint(request: Request):
    """Generate workflow based on user requirements"""
    try:
        data = request.json
        session_id = data.get("session_id")
        
        if session_id not in active_sessions:
            return json_response({"error": "Invalid session ID"}, status=400)
        
        session_info = active_sessions[session_id]
        csv_filename = session_info["filename"]
        csv_full_path = session_info["file_path"]
        
        # Generate workflow
        workflow_data = WorkflowGenerator.generate_workflow(data, csv_filename, csv_full_path)
        
        # Save workflow to file
        workflow_filename = f"workflow_{workflow_data['session_id']}.json"
        workflow_path = os.path.join(WORKFLOWS_DIR, workflow_filename)
        
        with open(workflow_path, 'w') as f:
            json.dump(workflow_data["workflow"], f, indent=2)
        
        # Store workflow info in session
        active_sessions[session_id]["workflow"] = {
            "path": workflow_path,
            "filename": workflow_filename,
            "metadata": workflow_data["metadata"]
        }
        
        return json_response({
            "workflow_generated": True,
            "workflow_filename": workflow_filename,
            "session_id": session_id,
            "metadata": workflow_data["metadata"]
        })
        
    except Exception as e:
        logger.error(f"Workflow generation error: {e}")
        return json_response({"error": f"Workflow generation failed: {str(e)}"}, status=500)

@app.route("/execute_workflow", methods=["POST"])
async def execute_workflow_endpoint(request: Request):
    """Execute the generated workflow"""
    try:
        data = request.json
        session_id = data.get("session_id")
        
        if session_id not in active_sessions:
            return json_response({"error": "Invalid session ID"}, status=400)
        
        session_info = active_sessions[session_id]
        
        if "workflow" not in session_info:
            return json_response({"error": "No workflow generated for this session"}, status=400)
        
        workflow_path = session_info["workflow"]["path"]
        csv_path = session_info["file_path"]
        
        # Execute workflow in background
        logger.info(f"Executing workflow for session {session_id}")
        
        # Run the workflow (CSV path is now embedded in the workflow JSON)
        results = run_universal_workflow(workflow_path, None)
        
        # Save results
        results_filename = f"results_{session_id}.json"
        results_path = os.path.join(RESULTS_DIR, results_filename)
        
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2)
        
        # Update session with results
        active_sessions[session_id]["results"] = {
            "path": results_path,
            "filename": results_filename,
            "data": results
        }
        
        return json_response({
            "execution_complete": True,
            "results": results,
            "results_filename": results_filename,
            "session_id": session_id
        })
        
    except Exception as e:
        logger.error(f"Workflow execution error: {e}")
        return json_response({"error": f"Workflow execution failed: {str(e)}"}, status=500)

@app.route("/session/<session_id>")
async def get_session_info(request: Request, session_id: str):
    """Get information about a session"""
    if session_id not in active_sessions:
        return json_response({"error": "Session not found"}, status=404)
    
    session_info = active_sessions[session_id]
    
    # Remove file paths for security
    safe_info = {
        "session_id": session_id,
        "filename": session_info["filename"],
        "analysis": session_info["analysis"],
        "created_at": session_info["created_at"],
        "has_workflow": "workflow" in session_info,
        "has_results": "results" in session_info
    }
    
    if "workflow" in session_info:
        safe_info["workflow_metadata"] = session_info["workflow"]["metadata"]
    
    if "results" in session_info:
        safe_info["results"] = session_info["results"]["data"]
    
    return json_response(safe_info)

@app.route("/download/<session_id>/<file_type>")
async def download_file(request: Request, session_id: str, file_type: str):
    """Download files (workflow, results) for a session"""
    if session_id not in active_sessions:
        return response.text("Session not found", status=404)
    
    session_info = active_sessions[session_id]
    
    if file_type == "workflow" and "workflow" in session_info:
        file_path = session_info["workflow"]["path"]
        filename = session_info["workflow"]["filename"]
    elif file_type == "results" and "results" in session_info:
        file_path = session_info["results"]["path"]
        filename = session_info["results"]["filename"]
    else:
        return response.text("File not found", status=404)
    
    return await response.file_stream(
        file_path,
        headers={
            "Content-Disposition": f"attachment; filename={filename}",
            "Content-Type": "application/json"
        }
    )

@app.route("/tools/status")
async def tools_status(request: Request):
    """Get status of available tools"""
    stats = tool_manager.get_stats()
    tools_by_module = tool_manager.list_tools_by_module()
    
    return json_response({
        "tools_available": stats["total_tools"] > 0,
        "stats": stats,
        "tools_by_module": tools_by_module
    })

if __name__ == "__main__":
    # Create templates directory if it doesn't exist
    templates_dir = os.path.join(current_dir, "templates")
    os.makedirs(templates_dir, exist_ok=True)
    
    print("🚀 Starting Sanic ML Workflow Server...")
    print(f"📁 Upload directory: {UPLOAD_DIR}")
    print(f"📄 Workflows directory: {WORKFLOWS_DIR}")
    print(f"📊 Results directory: {RESULTS_DIR}")
    
    app.run(host="0.0.0.0", port=8000, debug=True)