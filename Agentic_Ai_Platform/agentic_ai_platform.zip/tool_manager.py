#!/usr/bin/env python3

import os
import sys
import json
import inspect
import importlib.util
import glob
from typing import Dict, Any, List, Optional, Callable, Set
from functools import wraps
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("tool_manager")

class ToolManager:
    """Enhanced tool manager with automatic function discovery"""
    
    def __init__(self):
        self.tools = {}  # Tool registry (internal use only, not exposed)
        self.imported_modules = set()  # Track imported modules
        self.namespace_prefixes = {}  # Map module to namespace prefix
        self.excluded_files = {
            'agent_runner.py', 'tool_manager.py', 'utils.py', 'config.py', 'call_api.py',
            '__init__.py', 'cli.py'  # Add any other core files to exclude
        }
        self.excluded_functions = {
            'main', '__init__', 'setup', 'teardown', 'test_', 'debug_'
        }
    
    def discover_tools(self, directories: List[str] = None) -> int:
        """Automatically discover all Python modules and their functions in given directories"""
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if directories is None:
            directories = [current_dir]
            
            # Also include any directories within current_dir
            for item in os.listdir(current_dir):
                item_path = os.path.join(current_dir, item)
                if os.path.isdir(item_path) and not item.startswith('.') and item != '__pycache__':
                    directories.append(item_path)
        
        total_tools = 0
        logger.info(f"Scanning directories: {directories}")
        
        # Find all Python files
        for directory in directories:
            if not os.path.exists(directory):
                logger.warning(f"Directory does not exist: {directory}")
                continue
                
            python_files = glob.glob(os.path.join(directory, "*.py"))
            logger.info(f"Found {len(python_files)} Python files in {directory}")
            
            for py_file in python_files:
                filename = os.path.basename(py_file)
                
                # Skip excluded files
                if filename in self.excluded_files:
                    logger.debug(f"Skipping excluded file: {filename}")
                    continue
                
                module_name = filename[:-3]  # Remove .py
                
                # Skip if already imported
                if module_name in self.imported_modules:
                    logger.debug(f"Module already imported: {module_name}")
                    continue
                
                try:
                    # Import the module
                    spec = importlib.util.spec_from_file_location(module_name, py_file)
                    if spec is None or spec.loader is None:
                        logger.warning(f"Could not create spec for {py_file}")
                        continue
                        
                    module = importlib.util.module_from_spec(spec)
                    
                    # Add the module's directory to sys.path temporarily
                    module_dir = os.path.dirname(py_file)
                    if module_dir not in sys.path:
                        sys.path.insert(0, module_dir)
                        added_to_path = True
                    else:
                        added_to_path = False
                    
                    try:
                        spec.loader.exec_module(module)
                        self.imported_modules.add(module_name)
                        
                        # Determine namespace prefix
                        if hasattr(module, 'TOOL_NAMESPACE'):
                            prefix = getattr(module, 'TOOL_NAMESPACE')
                        else:
                            # By default, use the module name
                            prefix = module_name
                            
                            # Special case: if it ends with _adapter, remove that part
                            if prefix.endswith("_adapter"):
                                prefix = prefix[:-8]  # Remove "_adapter"
                        
                        self.namespace_prefixes[module_name] = prefix
                        
                        # Priority 1: If the module has TOOL_REGISTRY, register those tools
                        registry_tools = 0
                        if hasattr(module, 'TOOL_REGISTRY'):
                            tool_registry = getattr(module, 'TOOL_REGISTRY')
                            if isinstance(tool_registry, dict):
                                for tool_id, tool_handler in tool_registry.items():
                                    self.register_tool(tool_id, tool_handler)
                                    registry_tools += 1
                                    total_tools += 1
                                logger.info(f"Registered {registry_tools} tools from TOOL_REGISTRY in {module_name}")
                        
                        # Priority 2: Auto-discover functions that should be registered as tools
                        auto_tools = self._discover_module_tools(module, prefix)
                        total_tools += len(auto_tools)
                        
                        logger.info(f"Imported module {module_name} with {registry_tools} registry tools + {len(auto_tools)} auto-discovered functions")
                        
                    finally:
                        # Remove from sys.path if we added it
                        if added_to_path:
                            sys.path.remove(module_dir)
                    
                except Exception as e:
                    logger.error(f"Error importing {module_name} from {py_file}: {e}")
                    # Continue with other modules even if one fails
                    continue
        
        logger.info(f"Total tools discovered: {total_tools}")
        return total_tools
    
    def _discover_module_tools(self, module, prefix: str) -> List[str]:
        """Discover and register tools from a module"""
        discovered_tools = []
        
        # Get all functions from the module
        for name, obj in inspect.getmembers(module):
            # Skip private functions, special methods, and non-functions
            if name.startswith('_') or not inspect.isfunction(obj):
                continue
            
            # Skip functions that start with excluded prefixes
            if any(name.startswith(excluded) for excluded in self.excluded_functions):
                continue
                
            # Skip functions that are already in TOOL_REGISTRY (avoid duplicates)
            if hasattr(module, 'TOOL_REGISTRY'):
                tool_registry = getattr(module, 'TOOL_REGISTRY')
                if isinstance(tool_registry, dict) and any(handler == obj for handler in tool_registry.values()):
                    continue
            
            # Check if function has a docstring (we only want documented functions)
            if obj.__doc__ and obj.__doc__.strip():
                # Create a tool ID based on the prefix and function name
                tool_id = f"{prefix}:{name}"
                self.register_tool(tool_id, obj)
                discovered_tools.append(tool_id)
                logger.debug(f"Auto-registered tool: {tool_id}")
        
        return discovered_tools
    
    def register_tool(self, tool_id: str, handler: Callable) -> None:
        """Register a function as a tool with flexible parameter handling"""
        @wraps(handler)
        def flexible_handler(**kwargs):
            try:
                # Get function signature
                sig = inspect.signature(handler)
                
                # If function takes **kwargs, pass everything
                if any(param.kind == param.VAR_KEYWORD for param in sig.parameters.values()):
                    return handler(**kwargs)
                
                # Otherwise, filter kwargs to match function signature
                filtered_kwargs = {}
                for param_name, param in sig.parameters.items():
                    if param_name in kwargs:
                        filtered_kwargs[param_name] = kwargs[param_name]
                    elif param.default == param.empty and param.kind not in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                        # Required parameter missing
                        logger.warning(f"Required parameter '{param_name}' missing for tool {tool_id}")
                        return {"error": f"Required parameter '{param_name}' missing"}
                
                return handler(**filtered_kwargs)
                
            except Exception as e:
                logger.error(f"Tool execution failed for {tool_id}: {str(e)}")
                return {"error": f"Tool execution failed: {str(e)}"}
        
        self.tools[tool_id] = flexible_handler
        logger.debug(f"Registered tool: {tool_id}")
    
    def execute_tool(self, tool_id: str, **kwargs) -> Any:
        """Execute a registered tool"""
        if tool_id not in self.tools:
            # Try to find it by prefix and auto-load
            if ':' in tool_id:
                prefix = tool_id.split(':', 1)[0]
                
                # Look for modules that might contain this tool
                for module_name, module_prefix in self.namespace_prefixes.items():
                    if module_prefix == prefix and module_name not in self.imported_modules:
                        # Try to import module
                        self._try_load_module(module_name, prefix)
                        break
        
        if tool_id not in self.tools:
            available_tools = self.get_available_tools_by_prefix(tool_id.split(':', 1)[0] if ':' in tool_id else '')
            error_msg = f"Unknown tool: {tool_id}"
            if available_tools:
                error_msg += f". Available tools with similar prefix: {', '.join(available_tools[:5])}"
            return {"error": error_msg}
        
        try:
            logger.info(f"Executing tool {tool_id} with params: {list(kwargs.keys())}")
            result = self.tools[tool_id](**kwargs)
            logger.debug(f"Tool {tool_id} executed successfully")
            return result
        except Exception as e:
            logger.error(f"Error executing tool {tool_id}: {str(e)}")
            return {"error": str(e)}
    
    def _try_load_module(self, module_name: str, prefix: str):
        """Try to load a module that might contain tools"""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            
            # Check multiple possible locations
            possible_paths = [
                os.path.join(current_dir, f"{module_name}.py"),
                os.path.join(current_dir, "COMPONENT", f"{module_name}.py"),
                os.path.join(current_dir, "tools", f"{module_name}.py"),
                os.path.join(current_dir, "adapters", f"{module_name}.py"),
            ]
            
            for module_path in possible_paths:
                if os.path.exists(module_path):
                    spec = importlib.util.spec_from_file_location(module_name, module_path)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        self._discover_module_tools(module, prefix)
                        self.imported_modules.add(module_name)
                        logger.info(f"Dynamically loaded module: {module_name}")
                        break
                        
        except Exception as e:
            logger.warning(f"Failed to dynamically load module {module_name}: {e}")
    
    def get_all_tools(self) -> List[str]:
        """Get a list of all registered tool IDs"""
        return sorted(list(self.tools.keys()))
    
    def get_tools_by_prefix(self, prefix: str) -> List[str]:
        """Get tools by namespace prefix"""
        return [tool_id for tool_id in self.tools.keys() if tool_id.startswith(f"{prefix}:")]
    
    def get_available_tools_by_prefix(self, prefix: str) -> List[str]:
        """Get available tools that match a prefix"""
        if not prefix:
            return []
        return [tool_id for tool_id in self.tools.keys() if tool_id.startswith(prefix)]
    
    def is_tool_available(self, tool_id: str) -> bool:
        """Check if a tool is available"""
        return tool_id in self.tools
    
    def get_tool_info(self, tool_id: str) -> Dict[str, Any]:
        """Get information about a specific tool"""
        if tool_id not in self.tools:
            return {"error": f"Tool not found: {tool_id}"}
        
        try:
            # Get the original function from the wrapper
            original_func = self.tools[tool_id].__wrapped__ if hasattr(self.tools[tool_id], '__wrapped__') else self.tools[tool_id]
            
            # Get function signature and docstring
            sig = inspect.signature(original_func)
            
            return {
                "tool_id": tool_id,
                "name": original_func.__name__,
                "module": original_func.__module__ if hasattr(original_func, '__module__') else 'unknown',
                "docstring": original_func.__doc__ or "No documentation available",
                "parameters": {
                    name: {
                        "type": str(param.annotation) if param.annotation != param.empty else "Any",
                        "default": str(param.default) if param.default != param.empty else "Required",
                        "kind": str(param.kind)
                    }
                    for name, param in sig.parameters.items()
                }
            }
        except Exception as e:
            return {"error": f"Could not get tool info: {str(e)}"}
    
    def list_tools_by_module(self) -> Dict[str, List[str]]:
        """List tools organized by module/namespace"""
        tools_by_module = {}
        for tool_id in self.tools.keys():
            if ':' in tool_id:
                prefix, _ = tool_id.split(':', 1)
                if prefix not in tools_by_module:
                    tools_by_module[prefix] = []
                tools_by_module[prefix].append(tool_id)
            else:
                if 'global' not in tools_by_module:
                    tools_by_module['global'] = []
                tools_by_module['global'].append(tool_id)
        
        return tools_by_module
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the tool manager"""
        tools_by_module = self.list_tools_by_module()
        
        return {
            "total_tools": len(self.tools),
            "total_modules": len(self.imported_modules),
            "tools_by_module": {k: len(v) for k, v in tools_by_module.items()},
            "namespaces": list(self.namespace_prefixes.values())
        }

# Create a global tool manager instance
tool_manager = ToolManager()

# Additional utility functions that can be used as tools themselves
def list_all_tools(**kwargs) -> Dict[str, Any]:
    """List all available tools"""
    return {
        "tools": tool_manager.get_all_tools(),
        "stats": tool_manager.get_stats(),
        "by_module": tool_manager.list_tools_by_module()
    }

def get_tool_info(**kwargs) -> Dict[str, Any]:
    """Get information about a specific tool"""
    tool_id = kwargs.get('tool_id', '')
    if not tool_id:
        return {"error": "tool_id parameter is required"}
    
    return tool_manager.get_tool_info(tool_id)

def reload_tools(**kwargs) -> Dict[str, Any]:
    """Reload and rediscover all tools"""
    try:
        # Clear current tools and modules
        tool_manager.tools.clear()
        tool_manager.imported_modules.clear()
        tool_manager.namespace_prefixes.clear()
        
        # Rediscover tools
        total_tools = tool_manager.discover_tools()
        
        return {
            "success": True,
            "total_tools": total_tools,
            "stats": tool_manager.get_stats()
        }
    except Exception as e:
        return {"error": f"Failed to reload tools: {str(e)}"}

# Register these utility tools
tool_manager.register_tool("tools:list_all", list_all_tools)
tool_manager.register_tool("tools:get_info", get_tool_info)
tool_manager.register_tool("tools:reload", reload_tools)
