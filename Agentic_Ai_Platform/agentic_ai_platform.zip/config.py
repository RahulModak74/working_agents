#!/usr/bin/env python3

import os

# Configuration settings for the agent system
CONFIG = {
    "output_dir": "./agent_outputs",
    "memory_dir": "./agent_memory",
    "default_model": "qwen3:8b",
    "api_key": "",  # Ollama doesn't need API key
    "endpoint": "http://localhost:11434/v1/chat/completions",  # OpenAI-compatible endpoint
    "memory_db": "agent_memory.db",
    "sqlite_db": "test_sqlite.db" 
}

# Ensure output directories exist
os.makedirs(CONFIG["output_dir"], exist_ok=True)
os.makedirs(CONFIG["memory_dir"], exist_ok=True)