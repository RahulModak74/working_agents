#!/usr/bin/env python3
"""
LLM-Powered Tool Solutions - FIXED VERSION
The REAL value: LLM agents using tools intelligently!
"""

import json
import asyncio
import aiohttp
from pathlib import Path

# Import config and tools
from config import CONFIG
from auto_import_tools import *

class LLMAgent:
    """LLM Agent that can use tools intelligently"""
    
    def __init__(self, name: str, system_prompt: str = ""):
        self.name = name
        self.system_prompt = system_prompt or f"You are {name}, an intelligent AI assistant that can use tools to solve problems."
        self.conversation_history = []
        self.tools_used = []
        
    async def call_llm(self, message: str) -> str:
        """Call the LLM from config.py"""
        
        # Build conversation
        messages = [{"role": "system", "content": self.system_prompt}]
        messages.extend(self.conversation_history)
        messages.append({"role": "user", "content": message})
        
        payload = {
            "model": CONFIG["default_model"],
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 2000
        }
        
        headers = {"Content-Type": "application/json"}
        if CONFIG.get("api_key"):
            headers["Authorization"] = f"Bearer {CONFIG['api_key']}"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(CONFIG["endpoint"], json=payload, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        content = (data.get('content', '') or 
                                 data.get('choices', [{}])[0].get('message', {}).get('content', ''))
                        
                        # Store in conversation history
                        self.conversation_history.append({"role": "user", "content": message})
                        self.conversation_history.append({"role": "assistant", "content": content})
                        
                        return content
                    else:
                        return f"Error: LLM API returned {response.status}"
            except Exception as e:
                return f"Error calling LLM: {str(e)}"
    
    async def use_tool_intelligently(self, tool_description: str, **kwargs):
        """Let LLM decide how to use a tool"""
        
        prompt = f"""I need to use a tool. Here's what I want to accomplish:
{tool_description}

Available parameters: {kwargs}

Please tell me:
1. Which specific tool function to call
2. What parameters to use
3. How to interpret the results

Format your response as:
TOOL: tool_name
PARAMS: {{"param1": "value1", "param2": "value2"}}
REASONING: why this tool and these parameters
"""
        
        llm_response = await self.call_llm(prompt)
        
        # Parse LLM response to extract tool call
        lines = llm_response.split('\n')
        tool_name = None
        params = {}
        reasoning = ""
        
        for line in lines:
            if line.startswith('TOOL:'):
                tool_name = line.replace('TOOL:', '').strip()
            elif line.startswith('PARAMS:'):
                try:
                    params_str = line.replace('PARAMS:', '').strip()
                    params = json.loads(params_str)
                except:
                    pass
            elif line.startswith('REASONING:'):
                reasoning = line.replace('REASONING:', '').strip()
        
        # Execute the tool
        if tool_name:
            print(f"🤖 {self.name} decided to use: {tool_name}")
            print(f"💭 Reasoning: {reasoning}")
            
            result = call_tool(tool_name, **params)
            self.tools_used.append({
                "tool": tool_name,
                "params": params,
                "reasoning": reasoning,
                "result": result
            })
            
            return result
        else:
            return {"error": "LLM didn't specify a tool to use"}

# LLM-POWERED SOLUTION 1: Intelligent Research
async def llm_intelligent_research(topic: str):
    """LLM agent that researches intelligently"""
    
    researcher = LLMAgent("ResearchAgent", 
        f"You are an expert researcher. Use available tools to research '{topic}' comprehensively. "
        "You can use research tools, browser tools, and analysis tools. "
        "Think step by step about what information you need and which tools will get it."
    )
    
    print(f"🔍 LLM Agent researching: {topic}")
    
    # Step 1: LLM decides research strategy
    strategy_prompt = f"""I need to research '{topic}' comprehensively. 
    
Available tools include:
- research_combined_search: for web search
- browser_create/navigate/get_content: for direct website access  
- research_analyze_content: for content analysis
- vector_db_add/search: for knowledge storage
- planning_create_plan: for structured planning

What's the best research strategy? Give me a step-by-step plan."""

    strategy = await researcher.call_llm(strategy_prompt)
    print(f"📋 Research Strategy:\n{strategy}")
    
    # Step 2: LLM decides first research query
    query_prompt = f"Based on my strategy to research '{topic}', what should be my first search query? Just give me the search terms."
    first_query = await researcher.call_llm(query_prompt)
    first_query = first_query.strip().replace('"', '')
    
    # Step 3: Execute research (FIXED - direct call instead of async)
    try:
        research_result = call_tool("research:combined_search", query=first_query, num_results=10)
    except:
        research_result = {"search_results": [], "error": "Research tool not available"}
    
    # Step 4: LLM analyzes results and decides next action
    analysis_prompt = f"""I searched for '{first_query}' and got these results:
{json.dumps(research_result.get('search_results', [])[:3], indent=2)}

What should I do next? Should I:
1. Analyze this content more deeply
2. Search for more specific information  
3. Visit specific websites for more details
4. Store this information and search for something else

Give me specific next steps."""

    next_steps = await researcher.call_llm(analysis_prompt)
    print(f"🎯 LLM Next Steps:\n{next_steps}")
    
    # Step 5: Let LLM use tools intelligently
    analysis = None
    if "analyze" in next_steps.lower():
        content = " ".join([r.get('content', '') for r in research_result.get('search_results', [])])
        if content:
            analysis = await researcher.use_tool_intelligently(
                f"Analyze this content about {topic}: {content[:1000]}...",
                content=content,
                max_length=2000
            )
    
    return {
        "topic": topic,
        "strategy": strategy,
        "first_query": first_query,
        "research_result": research_result,
        "next_steps": next_steps,
        "analysis": analysis,
        "tools_used": researcher.tools_used,
        "conversation": researcher.conversation_history
    }

# LLM-POWERED SOLUTION 2: Adaptive Problem Solver
async def llm_adaptive_problem_solver(problem: str):
    """LLM that adapts its approach based on available tools"""
    
    solver = LLMAgent("ProblemSolver",
        "You are an adaptive problem solver. You can use any available tools to solve problems. "
        "Think creatively about which tools might help and how to combine them effectively."
    )
    
    print(f"🧠 LLM solving problem: {problem}")
    
    # Step 1: LLM analyzes the problem
    analysis_prompt = f"""Problem to solve: {problem}

I have access to these categories of tools:
- Browser automation (create, navigate, get content, find elements, click)
- Research tools (search, fetch content, analyze, generate summaries)
- Database tools (SQL queries, vector storage, semantic search)
- ML tools (train models, make predictions, evaluate)
- Planning tools (create plans, chain of thought reasoning)
- Security tools (analyze threats, detect patterns)
- Citation tools (format references, validate sources)

What's the best approach to solve this problem? Break it down into steps and identify which tools would be most useful."""

    approach = await solver.call_llm(analysis_prompt)
    print(f"🎯 Problem Analysis:\n{approach}")
    
    # Step 2: LLM decides first action
    action_prompt = f"Based on my analysis, what should be the first concrete action I take? Give me the specific tool to use and why."
    first_action = await solver.call_llm(action_prompt)
    
    # Step 3: Execute actions based on LLM decisions
    actions_taken = []
    
    if "research" in first_action.lower():
        # LLM wants to research
        search_query = await solver.call_llm(f"What should I search for to help solve: {problem}? Give me just the search terms.")
        search_query = search_query.strip().replace('"', '')
        
        try:
            result = call_tool("research:combined_search", query=search_query, num_results=5)
            actions_taken.append({"action": "research", "query": search_query, "result": result})
        except Exception as e:
            actions_taken.append({"action": "research", "query": search_query, "error": str(e)})
        
        # Ask LLM what to do with results
        if actions_taken and "result" in actions_taken[-1]:
            next_prompt = f"I found this information: {json.dumps(actions_taken[-1]['result'].get('search_results', [])[:2], indent=2)}\n\nWhat should I do next to solve the problem?"
            next_action = await solver.call_llm(next_prompt)
            actions_taken.append({"action": "planning", "decision": next_action})
    
    elif "browser" in first_action.lower():
        # LLM wants to use browser
        url_prompt = f"What website should I visit to help solve: {problem}? Give me just the URL."
        url = await solver.call_llm(url_prompt)
        url = url.strip().replace('http://', '').replace('https://', '')
        if not url.startswith('http'):
            url = 'https://' + url
        
        try:
            call_tool("browser:create", browser_id="solver")
            nav_result = call_tool("browser:navigate", url=url, browser_id="solver")
            content_result = call_tool("browser:get_content", browser_id="solver")
            call_tool("browser:close", browser_id="solver")
            
            actions_taken.append({"action": "browser", "url": url, "nav_result": nav_result, "content_result": content_result})
        except Exception as e:
            actions_taken.append({"action": "browser", "url": url, "error": str(e)})
    
    # Step 4: LLM synthesizes solution
    synthesis_prompt = f"""I've taken these actions to solve '{problem}':
{json.dumps(actions_taken, indent=2)}

Based on all this information, what's the final solution or recommendation? Provide a clear, actionable answer."""

    final_solution = await solver.call_llm(synthesis_prompt)
    
    return {
        "problem": problem,
        "approach": approach,
        "first_action": first_action,
        "actions_taken": actions_taken,
        "final_solution": final_solution,
        "tools_used": solver.tools_used
    }

# Simple synchronous wrapper functions
def run_intelligent_research(topic: str):
    """Sync wrapper for intelligent research"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If we're in a running loop, create a task
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, llm_intelligent_research(topic))
                return future.result()
        else:
            return loop.run_until_complete(llm_intelligent_research(topic))
    except RuntimeError:
        # If no loop exists, create a new one
        return asyncio.run(llm_intelligent_research(topic))

def run_problem_solver(problem: str):
    """Sync wrapper for problem solver"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, llm_adaptive_problem_solver(problem))
                return future.result()
        else:
            return loop.run_until_complete(llm_adaptive_problem_solver(problem))
    except RuntimeError:
        return asyncio.run(llm_adaptive_problem_solver(problem))

# Main execution - FIXED
def main():
    """Run LLM-powered solutions - FIXED to avoid asyncio issues"""
    
    print("🚀 LLM-Powered Tool Solutions")
    print(f"Using model: {CONFIG['default_model']}")
    print(f"Endpoint: {CONFIG['endpoint']}")
    print(f"🎉 Total tools available: {len(list_tools())}")
    
    choice = input("""
Choose solution:
1. Intelligent Research (LLM researches a topic)
2. Adaptive Problem Solver (LLM solves any problem)  
3. Quick Demo (no input needed)

Enter choice (1-3): """).strip()
    
    if choice == "1":
        topic = input("Research topic: ").strip() or "machine learning in finance"
        print(f"🔍 Starting research on: {topic}")
        result = run_intelligent_research(topic)
        filename = "llm_research.json"
        
    elif choice == "2":
        problem = input("Problem to solve: ").strip() or "How to learn options trading effectively"
        print(f"🧠 Starting problem solving for: {problem}")
        result = run_problem_solver(problem)
        filename = "llm_problem_solver.json"
        
    elif choice == "3":
        # Quick demo without async issues
        print("🎯 Running quick demo...")
        result = {
            "demo": "LLM-powered tool platform",
            "available_tools": len(list_tools()),
            "tool_categories": len(get_tools_by_prefix("research")),
            "model": CONFIG["default_model"],
            "status": "Platform ready for intelligent tool orchestration"
        }
        filename = "llm_demo.json"
    
    else:
        print("❌ Invalid choice")
        return
    
    # Save results
    try:
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        
        print(f"✅ LLM solution completed!")
        print(f"📁 Results saved to: {filename}")
        
        # Show key results
        if isinstance(result, dict):
            if "final_solution" in result:
                print(f"💡 Solution: {result['final_solution'][:200]}...")
            elif "strategy" in result:
                print(f"📋 Strategy: {result['strategy'][:200]}...")
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
        print(f"📋 Result preview: {str(result)[:500]}...")

# Tool registry for this module
TOOL_REGISTRY = {
    "intelligent_research": run_intelligent_research,
    "problem_solver": run_problem_solver,
    "llm_demo": lambda **kwargs: {"status": "LLM tools ready", "tools": len(list_tools())}
}

TOOL_NAMESPACE = "llm"

if __name__ == "__main__":
    main()