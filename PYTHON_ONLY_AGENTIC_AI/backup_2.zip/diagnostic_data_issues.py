#!/usr/bin/env python3
"""
Quick diagnosis script to identify why data collection failed
"""

import sys
from pathlib import Path

# Add framework to path
framework_dir = Path(__file__).parent
sys.path.insert(0, str(framework_dir))

from tool_manager import tool_manager

def diagnose_research_tools():
    """Test research functionality step by step"""
    print("🔍 DIAGNOSING RESEARCH TOOLS")
    print("=" * 50)
    
    # Test 1: Basic research search
    print("\n1. Testing basic research search...")
    result = tool_manager.execute_tool(
        "research:search", 
        query="cryptocurrency market trends", 
        num_results=3
    )
    
    print(f"   Status: {result.get('status', 'unknown')}")
    print(f"   Results: {result.get('num_results', 0)}")
    
    if result.get('status') == 'success' and result.get('results'):
        print("   ✅ Basic search working")
        first_url = result['results'][0].get('link', '')
        print(f"   First URL: {first_url}")
        
        # Test 2: Content fetching
        if first_url:
            print("\n2. Testing content fetching...")
            content_result = tool_manager.execute_tool(
                "research:fetch_content",
                url=first_url
            )
            
            print(f"   Status: {content_result.get('status', 'unknown')}")
            if content_result.get('status') == 'success':
                content_length = len(content_result.get('content', ''))
                print(f"   ✅ Content fetch working: {content_length} chars")
            else:
                print(f"   ❌ Content fetch failed: {content_result.get('error')}")
        
        # Test 3: Combined search (the one used in workflow)
        print("\n3. Testing combined search (used in workflow)...")
        combined_result = tool_manager.execute_tool(
            "research:combined_search",
            query="options trading market trends 2024",
            num_results=5
        )
        
        print(f"   Status: {combined_result.get('status', 'unknown')}")
        print(f"   Search Results: {len(combined_result.get('search_results', []))}")
        print(f"   Content Results: {len(combined_result.get('content_results', []))}")
        
        if combined_result.get('status') == 'success':
            search_count = len(combined_result.get('search_results', []))
            content_count = len(combined_result.get('content_results', []))
            print(f"   ✅ Combined search: {search_count} searches, {content_count} content")
            
            if search_count == 0:
                print("   ⚠️ ISSUE FOUND: No search results for options trading query")
                print("   This explains why your workflow got 0 sources!")
                
                # Test with simpler query
                print("\n   Testing with simpler query...")
                simple_result = tool_manager.execute_tool(
                    "research:search",
                    query="trading",
                    num_results=3
                )
                print(f"   Simple query results: {simple_result.get('num_results', 0)}")
                
        else:
            print(f"   ❌ Combined search failed: {combined_result.get('error')}")
            print("   🎯 ROOT CAUSE FOUND: Combined search not working")
            
    else:
        print(f"   ❌ Basic search failed: {result.get('error')}")
        print("   🎯 ROOT CAUSE FOUND: Basic research broken")

def diagnose_browser_tools():
    """Test browser functionality"""
    print("\n\n🌐 DIAGNOSING BROWSER TOOLS")
    print("=" * 50)
    
    # Test browser creation
    print("\n1. Testing browser creation...")
    result = tool_manager.execute_tool("browser:create", browser_id="diagnosis")
    
    if result.get('status') == 'success':
        print("   ✅ Browser creation working")
        
        # Test navigation to simple site
        print("\n2. Testing navigation to simple site...")
        nav_result = tool_manager.execute_tool(
            "browser:navigate",
            url="https://httpbin.org/html",
            browser_id="diagnosis"
        )
        
        if nav_result.get('status') == 'success':
            print(f"   ✅ Navigation working: {nav_result.get('title')}")
            
            # Test financial site navigation
            print("\n3. Testing financial site navigation...")
            finance_result = tool_manager.execute_tool(
                "browser:navigate",
                url="https://finance.yahoo.com/quote/SPY/options",
                browser_id="diagnosis"
            )
            
            if finance_result.get('status') == 'success':
                print(f"   ✅ Financial site access: {finance_result.get('title')}")
                
                # Test content extraction
                content_result = tool_manager.execute_tool(
                    "browser:get_content",
                    browser_id="diagnosis"
                )
                
                if content_result.get('status') == 'success':
                    content_length = len(content_result.get('content', ''))
                    print(f"   ✅ Content extraction: {content_length} chars")
                    
                    # Check if content contains useful data
                    content = content_result.get('content', '').lower()
                    if any(word in content for word in ['option', 'call', 'put', 'strike']):
                        print("   ✅ Content contains options data")
                    else:
                        print("   ⚠️ Content missing options data - site may be blocking")
                        
                else:
                    print(f"   ❌ Content extraction failed: {content_result.get('error')}")
            else:
                print(f"   ❌ Financial site blocked: {finance_result.get('error')}")
                print("   🎯 ISSUE: Financial sites blocking simple HTTP requests")
        else:
            print(f"   ❌ Navigation failed: {nav_result.get('error')}")
        
        # Cleanup
        tool_manager.execute_tool("browser:close", browser_id="diagnosis")
        
    else:
        print(f"   ❌ Browser creation failed: {result.get('error')}")

def diagnose_tool_discovery():
    """Check if tools are properly discovered"""
    print("\n\n🔧 DIAGNOSING TOOL DISCOVERY")
    print("=" * 50)
    
    all_tools = tool_manager.get_all_tools()
    print(f"Total tools discovered: {len(all_tools)}")
    
    research_tools = tool_manager.get_tools_by_prefix("research")
    browser_tools = tool_manager.get_tools_by_prefix("browser")
    
    print(f"Research tools: {len(research_tools)} - {research_tools}")
    print(f"Browser tools: {len(browser_tools)} - {browser_tools}")
    
    if len(research_tools) == 0:
        print("❌ CRITICAL: No research tools found!")
    if len(browser_tools) == 0:
        print("❌ CRITICAL: No browser tools found!")

def main():
    """Run complete diagnosis"""
    print("🚀 DATA COLLECTION DIAGNOSIS")
    print("=" * 60)
    print("This will identify why your options workflow got 0 data sources")
    print("=" * 60)
    
    try:
        # Discover tools first
        tool_count = tool_manager.discover_tools()
        print(f"Discovered {tool_count} tools")
        
        # Run diagnostics
        diagnose_tool_discovery()
        diagnose_research_tools()
        diagnose_browser_tools()
        
        print("\n" + "=" * 60)
        print("📋 DIAGNOSIS SUMMARY")
        print("=" * 60)
        print("Check the output above for:")
        print("❌ Failed tests = Root cause of data collection failure")
        print("✅ Successful tests = These components are working")
        print("\nMost likely issues:")
        print("1. DuckDuckGo API returning empty results for financial queries")
        print("2. Financial websites blocking simple HTTP requests")
        print("3. Missing API keys for better search engines")
        
    except Exception as e:
        print(f"❌ Diagnosis failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()