#!/usr/bin/env python3
"""
Quick validation script to test browsing and research capabilities
"""

import sys
import os
from pathlib import Path

# Add the framework directory to path
framework_dir = Path(__file__).parent
sys.path.insert(0, str(framework_dir))

def test_tool_discovery():
    """Test if tools are properly discovered"""
    print("🔍 Testing tool discovery...")
    
    try:
        from tool_manager import tool_manager
        
        # Discover all tools
        tool_count = tool_manager.discover_tools()
        
        print(f"✅ Discovered {tool_count} tools")
        
        # Get stats
        stats = tool_manager.get_stats()
        print(f"📊 Tool stats: {stats}")
        
        # Check for browser tools
        browser_tools = tool_manager.get_tools_by_prefix("browser")
        print(f"🌐 Browser tools: {len(browser_tools)}")
        
        # Check for research tools  
        research_tools = tool_manager.get_tools_by_prefix("research")
        print(f"🔍 Research tools: {len(research_tools)}")
        
        return len(browser_tools) > 0 and len(research_tools) > 0
        
    except Exception as e:
        print(f"❌ Tool discovery failed: {e}")
        return False

def test_research_functionality():
    """Test research tools"""
    print("\n🔍 Testing research functionality...")
    
    try:
        from tool_manager import tool_manager
        
        # Test basic search
        result = tool_manager.execute_tool("research:search", 
                                         query="artificial intelligence", 
                                         num_results=3)
        
        if result.get("status") == "success":
            print(f"✅ Search working: Found {result.get('num_results', 0)} results")
            
            # Test content fetching if we have results
            if result.get("results"):
                first_url = result["results"][0].get("link")
                if first_url:
                    content_result = tool_manager.execute_tool("research:fetch_content", 
                                                             url=first_url)
                    if content_result.get("status") == "success":
                        print(f"✅ Content fetch working: {len(content_result.get('content', ''))} chars")
                        return True
                    else:
                        print(f"⚠️ Content fetch issue: {content_result.get('error')}")
                        return True  # Search still works
            return True
        else:
            print(f"❌ Search failed: {result.get('error')}")
            return False
            
    except Exception as e:
        print(f"❌ Research test failed: {e}")
        return False

def test_browser_functionality():
    """Test browser tools"""
    print("\n🌐 Testing browser functionality...")
    
    try:
        from tool_manager import tool_manager
        
        # Test browser creation
        result = tool_manager.execute_tool("browser:create", 
                                         browser_id="test", 
                                         headless=True)
        
        if result.get("status") == "success":
            print("✅ Browser creation working")
            
            # Test navigation
            nav_result = tool_manager.execute_tool("browser:navigate", 
                                                 url="https://httpbin.org/html", 
                                                 browser_id="test")
            
            if nav_result.get("status") == "success":
                print("✅ Browser navigation working")
                
                # Test content extraction
                content_result = tool_manager.execute_tool("browser:get_content", 
                                                         browser_id="test")
                
                if content_result.get("status") == "success":
                    print(f"✅ Content extraction working: {len(content_result.get('content', ''))} chars")
                    
                    # Cleanup
                    tool_manager.execute_tool("browser:close", browser_id="test")
                    print("✅ Browser cleanup completed")
                    return True
                else:
                    print(f"⚠️ Content extraction issue: {content_result.get('error')}")
            else:
                print(f"⚠️ Navigation issue: {nav_result.get('error')}")
        else:
            print(f"❌ Browser creation failed: {result.get('error')}")
            if "Playwright" in str(result.get('error', '')):
                print("💡 Install Playwright: pip install playwright && playwright install")
            
        return False
            
    except Exception as e:
        print(f"❌ Browser test failed: {e}")
        return False

def test_integration():
    """Test integrated workflow"""
    print("\n🎯 Testing integrated workflow...")
    
    try:
        from tool_manager import tool_manager
        
        # Combined research test
        result = tool_manager.execute_tool("research:combined_search", 
                                         query="python web scraping", 
                                         num_results=2)
        
        if result.get("status") == "success":
            print(f"✅ Combined research working")
            print(f"📊 Found {len(result.get('search_results', []))} search results")
            print(f"📄 Fetched {len(result.get('content_results', []))} content pages")
            return True
        else:
            print(f"❌ Combined research failed: {result.get('error')}")
            return False
            
    except Exception as e:
        print(f"❌ Integration test failed: {e}")
        return False

def check_dependencies():
    """Check if required dependencies are available"""
    print("🔧 Checking dependencies...")
    
    dependencies = {
        'requests': 'pip install requests',
        'beautifulsoup4': 'pip install beautifulsoup4', 
        'playwright': 'pip install playwright && playwright install'
    }
    
    missing = []
    
    for dep, install_cmd in dependencies.items():
        try:
            if dep == 'beautifulsoup4':
                import bs4
            elif dep == 'playwright':
                from playwright.sync_api import sync_playwright
            else:
                __import__(dep)
            print(f"✅ {dep}")
        except ImportError:
            print(f"❌ {dep} - Run: {install_cmd}")
            missing.append((dep, install_cmd))
    
    return missing

def main():
    """Run all validation tests"""
    print("🚀 Validating Python Agentic Framework")
    print("=" * 50)
    
    # Check dependencies first
    missing_deps = check_dependencies()
    
    if missing_deps:
        print("\n⚠️ Missing dependencies detected!")
        print("Install them with:")
        for dep, cmd in missing_deps:
            print(f"  {cmd}")
        print()
    
    # Run tests
    tests = [
        ("Tool Discovery", test_tool_discovery),
        ("Research Functionality", test_research_functionality), 
        ("Browser Functionality", test_browser_functionality),
        ("Integration", test_integration)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            results[test_name] = False
    
    # Summary
    print("\n" + "=" * 50)
    print("📋 VALIDATION SUMMARY")
    print("=" * 50)
    
    passed = sum(results.values())
    total = len(results)
    
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{test_name:.<30} {status}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed >= 2:  # Research + Discovery minimum
        print("🎉 Framework is functional for research tasks!")
        if passed == total:
            print("🏆 All capabilities working perfectly!")
    else:
        print("⚠️ Framework needs fixes before use")
    
    # Quick usage example
    if results.get("Research Functionality"):
        print("\n💡 Quick usage example:")
        print("```python")
        print("from tool_manager import tool_manager")
        print("result = tool_manager.execute_tool('research:search', query='AI news', num_results=5)")
        print("print(result)")
        print("```")

if __name__ == "__main__":
    main()