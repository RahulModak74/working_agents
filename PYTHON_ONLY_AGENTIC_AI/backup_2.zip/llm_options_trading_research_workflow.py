#!/usr/bin/env python3
"""
Enhanced Options Trading Research Workflow with LLM Intelligence
Integrates your existing framework with LLM-powered analysis
"""

import sys
import json
import time
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

# Add framework to path
framework_dir = Path(__file__).parent
sys.path.insert(0, str(framework_dir))

from tool_manager import tool_manager
from llm_powered_solution import LLMAgent
from config import CONFIG

class EnhancedOptionsTradeResearchPipeline:
    """Options trading research with LLM intelligence"""
    
    def __init__(self):
        self.session_id = f"options_research_{int(time.time())}"
        self.browser_id = "options_browser"
        
        # Initialize LLM agents for different tasks
        self.market_analyst = LLMAgent(
            "MarketAnalyst", 
            "You are an expert options trading analyst. Analyze market data, "
            "identify trends, and provide actionable insights for options strategies."
        )
        
        self.risk_analyst = LLMAgent(
            "RiskAnalyst",
            "You are a risk management expert specializing in options trading. "
            "Assess risks, calculate probabilities, and recommend position sizing."
        )
        
        self.strategy_optimizer = LLMAgent(
            "StrategyOptimizer",
            "You are an options strategy expert. Recommend optimal strategies "
            "based on market conditions, volatility, and risk tolerance."
        )
        
        self.results = {
            "market_data": {},
            "llm_analysis": {},
            "options_strategies": {},
            "risk_assessment": {},
            "recommendations": [],
            "sources": []
        }
        
    async def stage_1_intelligent_market_analysis(self):
        """Stage 1: LLM-powered market intelligence"""
        print("🧠 STAGE 1: Intelligent Market Analysis")
        print("=" * 60)
        
        # Research with standard tools
        research_queries = [
            "options trading market trends 2024",
            "VIX volatility analysis today",
            "SPY options unusual activity",
            "earnings season options strategies"
        ]
        
        all_research_data = []
        for query in research_queries:
            print(f"\n📊 Researching: {query}")
            
            research_result = tool_manager.execute_tool(
                "research_combined_search",
                query=query,
                depth=2,
                num_results=5
            )
            
            if research_result.get("status") == "success":
                all_research_data.extend(research_result.get("content_results", []))
                self.results["sources"].extend(research_result.get("search_results", []))
        
        # LLM ANALYSIS: Intelligent interpretation of research data
        if all_research_data:
            combined_content = " ".join([item.get("content", "")[:1500] for item in all_research_data])
            
            # Market Analyst LLM interprets the data
            market_analysis_prompt = f"""
Analyze this options trading market research data:

{combined_content}

Provide analysis in this JSON format:
{{
    "market_sentiment": "bullish/bearish/neutral",
    "volatility_outlook": "high/medium/low",
    "key_opportunities": ["opportunity1", "opportunity2"],
    "risk_factors": ["risk1", "risk2"],
    "recommended_focus": "sector or strategy to focus on",
    "confidence_level": "1-10 scale"
}}
"""
            
            llm_analysis = await self.market_analyst.call_llm(market_analysis_prompt)
            self.results["llm_analysis"]["market_interpretation"] = llm_analysis
            
            print(f"🧠 LLM Market Analysis Complete")
            print(f"📊 Analysis: {llm_analysis[:200]}...")
        
        return all_research_data
    
    async def stage_2_llm_enhanced_data_collection(self):
        """Stage 2: LLM guides data collection strategy"""
        print("\n🤖 STAGE 2: LLM-Enhanced Data Collection")
        print("=" * 60)
        
        # Ask LLM what specific data to collect
        data_strategy_prompt = """
Based on current market conditions, what specific options trading data should I collect?
Prioritize the most important sources and metrics.

Respond with specific URLs and data points to focus on:
- CBOE data priorities
- Yahoo Finance options chains to check
- Key volatility metrics to track
- Market sentiment indicators

Format as actionable data collection plan.
"""
        
        collection_strategy = await self.market_analyst.call_llm(data_strategy_prompt)
        print(f"🎯 LLM Data Collection Strategy:\n{collection_strategy}")
        
        # Execute enhanced data collection
        browser_result = tool_manager.execute_tool("browser_create", browser_id=self.browser_id, headless=True)
        
        # LLM-recommended data sources (you can expand this based on LLM recommendations)
        priority_sources = [
            {
                "name": "CBOE VIX Data",
                "url": "https://www.cboe.com/tradeable_products/vix/",
                "focus": "Current VIX level and term structure"
            },
            {
                "name": "SPY Options Chain", 
                "url": "https://finance.yahoo.com/quote/SPY/options",
                "focus": "Put/call ratios and unusual volume"
            }
        ]
        
        collected_data = []
        for source in priority_sources:
            print(f"\n📈 Collecting: {source['name']}")
            
            nav_result = tool_manager.execute_tool(
                "browser_navigate",
                url=source["url"],
                browser_id=self.browser_id
            )
            
            if nav_result.get("status") == "success":
                content_result = tool_manager.execute_tool(
                    "browser_get_content",
                    browser_id=self.browser_id,
                    content_type="text"
                )
                
                if content_result.get("status") == "success":
                    # LLM ENHANCEMENT: Have LLM extract key metrics
                    content = content_result.get("content", "")
                    
                    extraction_prompt = f"""
Extract key options trading metrics from this {source['name']} data:

{content[:2000]}

Focus on: {source['focus']}

Return specific numbers, percentages, and actionable data points in JSON format.
"""
                    
                    extracted_metrics = await self.market_analyst.call_llm(extraction_prompt)
                    
                    collected_data.append({
                        "source": source["name"],
                        "url": source["url"],
                        "raw_content_length": len(content),
                        "llm_extracted_metrics": extracted_metrics,
                        "timestamp": datetime.now().isoformat()
                    })
                    
                    print(f"✅ LLM extracted metrics from {source['name']}")
        
        tool_manager.execute_tool("browser_close", browser_id=self.browser_id)
        self.results["market_data"]["llm_enhanced_collection"] = collected_data
        
        return collected_data
    
    async def stage_3_llm_strategy_optimization(self):
        """Stage 3: LLM optimizes options strategies"""
        print("\n🎯 STAGE 3: LLM Strategy Optimization")
        print("=" * 60)
        
        # Prepare context for strategy optimization
        market_context = {
            "research_data": self.results.get("llm_analysis", {}),
            "live_data": self.results.get("market_data", {}),
            "timestamp": datetime.now().isoformat()
        }
        
        strategy_optimization_prompt = f"""
Based on this comprehensive market analysis:

{json.dumps(market_context, indent=2)}

Recommend the top 3 options strategies for current market conditions.

For each strategy, provide:
1. Strategy name and type
2. Market conditions it's best suited for
3. Risk/reward profile
4. Specific implementation details
5. Position sizing recommendations
6. Exit criteria

Format as detailed JSON with specific, actionable recommendations.
"""
        
        strategy_recommendations = await self.strategy_optimizer.call_llm(strategy_optimization_prompt)
        self.results["options_strategies"]["llm_recommendations"] = strategy_recommendations
        
        print("🧠 LLM Strategy Optimization Complete")
        
        # Risk Analysis by dedicated risk analyst
        risk_analysis_prompt = f"""
Analyze the risks of these recommended strategies:

{strategy_recommendations}

Provide:
1. Risk assessment for each strategy (1-10 scale)
2. Maximum potential loss scenarios
3. Probability of profit estimates
4. Market conditions that would invalidate each strategy
5. Portfolio correlation risks
6. Recommended position sizing based on risk tolerance

Format as comprehensive risk analysis in JSON.
"""
        
        risk_analysis = await self.risk_analyst.call_llm(risk_analysis_prompt)
        self.results["risk_assessment"]["llm_analysis"] = risk_analysis
        
        print("⚠️ LLM Risk Analysis Complete")
        
        return strategy_recommendations, risk_analysis
    
    async def stage_4_final_llm_synthesis(self):
        """Stage 4: LLM synthesizes everything into actionable plan"""
        print("\n📋 STAGE 4: Final LLM Synthesis")
        print("=" * 60)
        
        # Combine all analysis for final synthesis
        complete_analysis = {
            "market_analysis": self.results.get("llm_analysis", {}),
            "data_collection": self.results.get("market_data", {}),
            "strategy_recommendations": self.results.get("options_strategies", {}),
            "risk_assessment": self.results.get("risk_assessment", {})
        }
        
        synthesis_prompt = f"""
Synthesize this complete options trading analysis into an executive summary and action plan:

{json.dumps(complete_analysis, indent=2)}

Create a comprehensive report with:

1. EXECUTIVE SUMMARY (2-3 sentences)
2. TOP 3 ACTIONABLE RECOMMENDATIONS
3. RISK WARNINGS
4. IMPLEMENTATION TIMELINE
5. MONITORING CHECKLIST

Make it specific, actionable, and ready for immediate implementation.
Format as structured JSON for easy parsing.
"""
        
        final_synthesis = await self.market_analyst.call_llm(synthesis_prompt)
        
        # Parse and structure the final recommendations
        try:
            import re
            json_match = re.search(r'\{.*\}', final_synthesis, re.DOTALL)
            if json_match:
                parsed_synthesis = json.loads(json_match.group())
                self.results["recommendations"] = parsed_synthesis
            else:
                self.results["recommendations"] = {"raw_synthesis": final_synthesis}
        except:
            self.results["recommendations"] = {"raw_synthesis": final_synthesis}
        
        return final_synthesis
    
    async def run_enhanced_workflow(self):
        """Execute the complete LLM-enhanced workflow"""
        print("🚀 ENHANCED OPTIONS TRADING RESEARCH WITH LLM")
        print("=" * 80)
        print(f"Using LLM Model: {CONFIG['default_model']}")
        print(f"Endpoint: {CONFIG['endpoint']}")
        print(f"Session ID: {self.session_id}")
        print("=" * 80)
        
        start_time = time.time()
        
        try:
            # Execute all stages with LLM intelligence
            await self.stage_1_intelligent_market_analysis()
            await self.stage_2_llm_enhanced_data_collection()
            strategy_recs, risk_analysis = await self.stage_3_llm_strategy_optimization()
            final_synthesis = await self.stage_4_final_llm_synthesis()
            
            end_time = time.time()
            execution_time = end_time - start_time
            
            # Generate final report
            report = {
                "executive_summary": {
                    "timestamp": datetime.now().isoformat(),
                    "execution_time": execution_time,
                    "llm_model_used": CONFIG['default_model'],
                    "analysis_confidence": "High (LLM-enhanced)",
                    "total_sources": len(self.results["sources"])
                },
                "llm_insights": self.results["llm_analysis"],
                "enhanced_data": self.results["market_data"],
                "strategy_recommendations": self.results["options_strategies"],
                "risk_assessment": self.results["risk_assessment"],
                "final_recommendations": self.results["recommendations"],
                "data_sources": self.results["sources"]
            }
            
            # Save comprehensive report
            report_file = f"llm_enhanced_options_report_{self.session_id}.json"
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            # Print enhanced summary
            print("\n" + "=" * 80)
            print("🧠 LLM-ENHANCED EXECUTIVE SUMMARY")
            print("=" * 80)
            
            if isinstance(self.results["recommendations"], dict):
                if "executive_summary" in self.results["recommendations"]:
                    print(f"📊 {self.results['recommendations']['executive_summary']}")
                
                if "top_recommendations" in self.results["recommendations"]:
                    print(f"\n🎯 TOP RECOMMENDATIONS:")
                    for i, rec in enumerate(self.results["recommendations"]["top_recommendations"][:3], 1):
                        print(f"   {i}. {rec}")
            
            print(f"\n⏱️ Execution Time: {execution_time:.1f} seconds")
            print(f"🤖 LLM Model: {CONFIG['default_model']}")
            print(f"📁 Enhanced Report: {report_file}")
            
            print(f"\n✅ LLM-Enhanced Workflow Completed Successfully!")
            return report, report_file
            
        except Exception as e:
            print(f"❌ Enhanced workflow failed: {str(e)}")
            import traceback
            traceback.print_exc()
            return None, None

def main():
    """Main execution function"""
    print("🧠 LLM-ENHANCED OPTIONS TRADING RESEARCH")
    print("=" * 80)
    print("This enhanced version adds LLM intelligence to:")
    print("✅ Market data interpretation")
    print("✅ Strategy optimization") 
    print("✅ Risk analysis")
    print("✅ Final synthesis and recommendations")
    print("=" * 80)
    
    # Check LLM configuration
    print(f"🤖 LLM Configuration:")
    print(f"   Model: {CONFIG['default_model']}")
    print(f"   Endpoint: {CONFIG['endpoint']}")
    print(f"   API Key: {'✅ Set' if CONFIG.get('api_key') else '❌ Not needed for Ollama'}")
    
    # Initialize and run the enhanced pipeline
    pipeline = EnhancedOptionsTradeResearchPipeline()
    
    # Handle async execution
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, pipeline.run_enhanced_workflow())
                report, report_file = future.result()
        else:
            report, report_file = asyncio.run(pipeline.run_enhanced_workflow())
    except RuntimeError:
        report, report_file = asyncio.run(pipeline.run_enhanced_workflow())
    
    if report:
        print("\n💡 LLM-ENHANCED CAPABILITIES DEMONSTRATED:")
        print("✅ Intelligent market data interpretation")
        print("✅ Smart data collection strategy")
        print("✅ AI-optimized strategy recommendations")
        print("✅ Comprehensive risk analysis")
        print("✅ Synthesized actionable insights")
        
        return report_file
    else:
        print("❌ Enhanced workflow execution failed")
        return None

if __name__ == "__main__":
    result = main()