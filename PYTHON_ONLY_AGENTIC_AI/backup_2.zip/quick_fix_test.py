#!/usr/bin/env python3
"""
Quick test of the simple browser adapter (no Playwright needed)
"""

def test_simple_browser():
    """Test the simple browser implementation"""
    print("🚀 Testing Simple Browser (No Playwright)")
    print("=" * 50)
    
    try:
        # Replace the old browser_adapter with simple one
        import os
        import sys
        from pathlib import Path
        
        # Get the framework directory
        framework_dir = Path(__file__).parent
        component_dir = framework_dir / "COMPONENT"
        
        # Backup old browser_adapter if it exists
        old_adapter = component_dir / "browser_adapter.py"
        backup_adapter = component_dir / "browser_adapter_playwright_backup.py"
        
        if old_adapter.exists() and not backup_adapter.exists():
            import shutil
            shutil.copy2(old_adapter, backup_adapter)
            print("✅ Backed up Playwright adapter")
        
        # Write the simple browser adapter
        simple_adapter_code = '''#!/usr/bin/env python3

import os
import sys
import json
import time
import logging
import requests
import re
from typing import Dict, Any, List, Optional
from datetime import datetime
from urllib.parse import urljoin, urlparse

# IMPORTANT: Add tool namespace for tool_manager discovery
TOOL_NAMESPACE = "browser"

# Set up logging
logger = logging.getLogger("browser_adapter")

# Try to import BeautifulSoup
try:
    from bs4 import BeautifulSoup
    BEAUTIFULSOUP_AVAILABLE = True
    logger.info("✅ BeautifulSoup successfully imported")
except ImportError:
    BEAUTIFULSOUP_AVAILABLE = False
    logger.warning("❌ BeautifulSoup not available. Install with 'pip install beautifulsoup4'")

class SimpleBrowserSession:
    """Simple browser session using requests + BeautifulSoup"""
    
    def __init__(self, session_id: str = "default"):
        self.session_id = session_id
        self.session = requests.Session()
        self.current_url = None
        self.current_soup = None
        self.history = []
        
        # Set realistic headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })

class SimpleBrowserManager:
    """Browser manager using simple HTTP requests"""
    
    def __init__(self):
        self.sessions = {}
        self.default_timeout = 30
        
    def create_browser(self, browser_id: str = None, browser_type: str = "simple", 
                      headless: bool = True) -> Dict[str, Any]:
        """Create a new browser session"""
        if browser_id is None:
            browser_id = "default"
        
        try:
            session = SimpleBrowserSession(browser_id)
            self.sessions[browser_id] = session
            
            logger.info(f"✅ Browser created: {browser_id}")
            
            return {
                "status": "success", 
                "browser_id": browser_id, 
                "type": "simple_http",
                "message": f"Simple browser session created: {browser_id}"
            }
            
        except Exception as e:
            logger.error(f"❌ Error creating browser: {str(e)}")
            return {"error": f"Failed to create browser: {str(e)}"}
    
    def navigate(self, url: str, browser_id: str = None, wait_until: str = "load") -> Dict[str, Any]:
        """Navigate to a URL"""
        if browser_id is None:
            browser_id = "default"
            
        # Create browser if it doesn't exist
        if browser_id not in self.sessions:
            result = self.create_browser(browser_id)
            if "error" in result:
                return result
        
        session_obj = self.sessions.get(browser_id)
        if not session_obj:
            return {"error": f"No session found for browser {browser_id}"}
        
        # Fix URL if needed
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        try:
            start_time = time.time()
            response = session_obj.session.get(url, timeout=self.default_timeout)
            response.raise_for_status()
            end_time = time.time()
            
            # Store current state
            session_obj.current_url = response.url
            session_obj.history.append(response.url)
            
            # Parse with BeautifulSoup if available
            if BEAUTIFULSOUP_AVAILABLE:
                session_obj.current_soup = BeautifulSoup(response.content, 'html.parser')
                page_title = session_obj.current_soup.title.string.strip() if session_obj.current_soup.title else "No Title"
            else:
                session_obj.current_soup = None
                # Try to extract title from raw HTML
                title_match = re.search(r'<title[^>]*>([^<]+)</title>', response.text, re.IGNORECASE)
                page_title = title_match.group(1).strip() if title_match else "No Title"
            
            logger.info(f"✅ Navigated to: {response.url}")
            
            return {
                "status": "success",
                "url": response.url,
                "title": page_title,
                "status_code": response.status_code,
                "navigation_time_seconds": round(end_time - start_time, 2)
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Navigation error: {str(e)}")
            return {"error": f"Failed to navigate to {url}: {str(e)}"}
        except Exception as e:
            logger.error(f"❌ Unexpected error: {str(e)}")
            return {"error": f"Unexpected error: {str(e)}"}
    
    def get_page_content(self, browser_id: str = None, content_type: str = "text") -> Dict[str, Any]:
        """Get page content"""
        if browser_id is None:
            browser_id = "default"
            
        session_obj = self.sessions.get(browser_id)
        if not session_obj:
            return {"error": f"No session found for browser {browser_id}"}
        
        if not session_obj.current_url:
            return {"error": "No page loaded. Navigate to a URL first."}
        
        try:
            # Get fresh content
            response = session_obj.session.get(session_obj.current_url, timeout=self.default_timeout)
            response.raise_for_status()
            
            if content_type.lower() == "html":
                content = response.text
            else:
                # Extract clean text
                if BEAUTIFULSOUP_AVAILABLE:
                    soup = BeautifulSoup(response.content, 'html.parser')
                    
                    # Remove unwanted elements
                    for element in soup(["script", "style", "nav", "header", "footer", "aside"]):
                        element.decompose()
                    
                    # Try to get main content
                    main_content = (soup.find('main') or 
                                  soup.find('article') or 
                                  soup.find('div', {'id': 'content'}) or 
                                  soup.find('div', {'class': 'content'}) or 
                                  soup.body)
                    
                    if main_content:
                        content = main_content.get_text(separator=' ', strip=True)
                    else:
                        content = soup.get_text(separator=' ', strip=True)
                    
                    # Clean up text
                    content = re.sub(r'\\s+', ' ', content).strip()
                else:
                    # Fallback: try to extract text from HTML
                    content = re.sub(r'<[^>]+>', ' ', response.text)
                    content = re.sub(r'\\s+', ' ', content).strip()
            
            metadata = {
                "url": session_obj.current_url,
                "content_length": len(content),
                "content_type": content_type,
                "timestamp": datetime.now().isoformat()
            }
            
            return {
                "status": "success",
                "content": content,
                "metadata": metadata
            }
            
        except Exception as e:
            logger.error(f"❌ Content extraction error: {str(e)}")
            return {"error": f"Failed to get page content: {str(e)}"}
    
    def close_browser(self, browser_id: str = None) -> Dict[str, Any]:
        """Close browser session"""
        if browser_id is None:
            browser_id = "default"
        
        try:
            if browser_id in self.sessions:
                session_obj = self.sessions[browser_id]
                session_obj.session.close()
                del self.sessions[browser_id]
                
                logger.info(f"✅ Browser closed: {browser_id}")
                return {"status": "success", "message": f"Browser {browser_id} closed"}
            else:
                return {"error": f"Browser {browser_id} not found"}
                
        except Exception as e:
            logger.error(f"❌ Close error: {str(e)}")
            return {"error": f"Failed to close browser: {str(e)}"}

# Global browser manager
BROWSER_MANAGER = SimpleBrowserManager()

# Tool Registry Functions
def browser_create(browser_id: str = None, browser_type: str = "simple", headless: bool = True, **kwargs) -> Dict[str, Any]:
    """Create a new simple browser session"""
    return BROWSER_MANAGER.create_browser(browser_id, browser_type, headless)

def browser_navigate(url: str, browser_id: str = None, wait_until: str = "load", **kwargs) -> Dict[str, Any]:
    """Navigate to a URL"""
    return BROWSER_MANAGER.navigate(url, browser_id, wait_until)

def browser_get_content(browser_id: str = None, content_type: str = "text", **kwargs) -> Dict[str, Any]:
    """Get page content"""
    return BROWSER_MANAGER.get_page_content(browser_id, content_type)

def browser_close(browser_id: str = None, **kwargs) -> Dict[str, Any]:
    """Close browser"""
    return BROWSER_MANAGER.close_browser(browser_id)

def browser_stats(**kwargs) -> Dict[str, Any]:
    """Get browser statistics"""
    return {
        "active_sessions": len(BROWSER_MANAGER.sessions),
        "browser_type": "simple_http",
        "beautifulsoup_available": BEAUTIFULSOUP_AVAILABLE,
        "timestamp": datetime.now().isoformat()
    }

# Register tools
TOOL_REGISTRY = {
    "create": browser_create,
    "navigate": browser_navigate, 
    "get_content": browser_get_content,
    "close": browser_close,
    "stats": browser_stats
}

logger.info(f"✅ Simple browser tools registered: {list(TOOL_REGISTRY.keys())}")
'''
        
        # Write the simple adapter
        with open(old_adapter, 'w', encoding='utf-8') as f:
            f.write(simple_adapter_code)
        
        print("✅ Replaced browser adapter with simple version")
        
        # Now test it
        print("\n🧪 Testing simple browser functionality...")
        
        # Add paths
        sys.path.insert(0, str(component_dir))
        sys.path.insert(0, str(framework_dir))
        
        # Import and test
        from tool_manager import tool_manager
        
        # Rediscover tools to pick up the new adapter
        tool_manager.tools.clear()
        tool_manager.imported_modules.clear()
        tool_count = tool_manager.discover_tools()
        
        print(f"✅ Rediscovered {tool_count} tools")
        
        # Test browser creation
        print("\\n1. Testing browser creation...")
        result = tool_manager.execute_tool("browser:create", browser_id="test")
        if result.get("status") == "success":
            print("✅ Browser creation: SUCCESS")
        else:
            print(f"❌ Browser creation failed: {result.get('error')}")
            return False
        
        # Test navigation
        print("\\n2. Testing navigation...")
        result = tool_manager.execute_tool("browser:navigate", 
                                         url="https://httpbin.org/html", 
                                         browser_id="test")
        if result.get("status") == "success":
            print(f"✅ Navigation: SUCCESS - {result.get('title')}")
        else:
            print(f"❌ Navigation failed: {result.get('error')}")
            return False
        
        # Test content extraction
        print("\\n3. Testing content extraction...")
        result = tool_manager.execute_tool("browser:get_content", browser_id="test")
        if result.get("status") == "success":
            content_length = len(result.get("content", ""))
            print(f"✅ Content extraction: SUCCESS - {content_length} chars")
        else:
            print(f"❌ Content extraction failed: {result.get('error')}")
            return False
        
        # Test cleanup
        print("\\n4. Testing cleanup...")
        result = tool_manager.execute_tool("browser:close", browser_id="test")
        if result.get("status") == "success":
            print("✅ Browser cleanup: SUCCESS")
        else:
            print(f"❌ Cleanup failed: {result.get('error')}")
        
        print("\\n🎉 All simple browser tests PASSED!")
        print("\\n💡 Your framework now has working browser capabilities!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_combined_functionality():
    """Test research + simple browser together"""
    print("\\n🔄 Testing Combined Research + Browser...")
    
    try:
        from tool_manager import tool_manager
        
        # 1. Research with simple search
        print("1. Performing research...")
        research_result = tool_manager.execute_tool(
            "research:search", 
            query="python requests tutorial", 
            num_results=2
        )
        
        if research_result.get("status") != "success":
            print(f"❌ Research failed: {research_result.get('error')}")
            return False
        
        print(f"✅ Found {research_result.get('num_results')} results")
        
        # 2. Get a URL from research and browse it
        if research_result.get("results"):
            first_url = research_result["results"][0].get("link")
            if first_url:
                print(f"2. Browsing first result: {first_url[:50]}...")
                
                # Create browser and navigate
                tool_manager.execute_tool("browser:create", browser_id="research")
                nav_result = tool_manager.execute_tool("browser:navigate", 
                                                     url=first_url, 
                                                     browser_id="research")
                
                if nav_result.get("status") == "success":
                    print(f"✅ Browsed to: {nav_result.get('title')}")
                    
                    # Get content
                    content_result = tool_manager.execute_tool("browser:get_content", 
                                                             browser_id="research")
                    
                    if content_result.get("status") == "success":
                        content_length = len(content_result.get("content", ""))
                        print(f"✅ Extracted {content_length} chars of content")
                        
                        # Cleanup
                        tool_manager.execute_tool("browser:close", browser_id="research")
                        
                        print("\\n🚀 COMBINED FUNCTIONALITY WORKING!")
                        print("Your framework can now:")
                        print("  ✅ Search the web")
                        print("  ✅ Fetch web content") 
                        print("  ✅ Browse websites")
                        print("  ✅ Extract page content")
                        print("  ✅ Work together seamlessly")
                        
                        return True
                    else:
                        print(f"❌ Content extraction failed: {content_result.get('error')}")
                else:
                    print(f"❌ Navigation failed: {nav_result.get('error')}")
        
        return False
        
    except Exception as e:
        print(f"❌ Combined test failed: {e}")
        return False

if __name__ == "__main__":
    print("🚀 QUICK FIX: Replacing Playwright with Simple Browser")
    print("=" * 60)
    
    success = test_simple_browser()
    
    if success:
        print("\\n" + "=" * 60)
        combined_success = test_combined_functionality()
        
        if combined_success:
            print("\\n🏆 FRAMEWORK FULLY FUNCTIONAL!")
            print("\\nQuick usage:")
            print("```python")
            print("from tool_manager import tool_manager")
            print("# Search")
            print("result = tool_manager.execute_tool('research:search', query='AI news')")
            print("# Browse") 
            print("tool_manager.execute_tool('browser:create')")
            print("tool_manager.execute_tool('browser:navigate', url='https://example.com')")
            print("content = tool_manager.execute_tool('browser:get_content')")
            print("```")
        else:
            print("\\n⚠️ Simple browser works, but combined functionality needs work")
    else:
        print("\\n❌ Simple browser replacement failed")
        print("\\nFallback: Your research tools still work!")
        print("Just use research:search and research:fetch_content")