#!/usr/bin/env python3

import os
import sys
import json
import inspect
import importlib.util
import glob
from typing import Dict, Any, List, Optional, Callable, Set
from functools import wraps
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("tool_manager")

class ToolManager:
    """Enhanced tool manager with automatic function discovery"""
    
    def __init__(self):
        self.tools = {}  # Tool registry
        self.imported_modules = set()  # Track imported modules
        self.namespace_prefixes = {}  # Map module to namespace prefix
        self.excluded_files = {
            'agent_runner.py', 'tool_manager.py', 'utils.py', 'config.py', 'call_api.py',
            '__init__.py', 'cli.py', 'async_executor.py', 'async_framework_main.py',
            'workflow_executor.py', 'workflow_state.py', 'enhanced_agent_runner.py'
        }
        self.excluded_functions = {
            'main', '__init__', 'setup', 'teardown', 'test_', 'debug_'
        }
        
        # Priority loading patterns - these get loaded first
        self.priority_patterns = [
            '*_adapter.py',  # All adapter files
            '*_manager.py',  # All manager files
            'memory_*.py',   # Memory-related files
            'cognitive_*.py' # Cognitive-related files
        ]
    
    def discover_tools(self, directories: List[str] = None) -> int:
        """Automatically discover all Python modules and their functions in given directories"""
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if directories is None:
            directories = [current_dir]
            
            # Add COMPONENT directory if it exists
            component_dir = os.path.join(current_dir, "COMPONENT")
            if os.path.exists(component_dir):
                directories.append(component_dir)
                logger.info(f"Added COMPONENT directory: {component_dir}")
            
            # Also include any other directories within current_dir
            for item in os.listdir(current_dir):
                item_path = os.path.join(current_dir, item)
                if (os.path.isdir(item_path) and 
                    not item.startswith('.') and 
                    item not in ['__pycache__', 'COMPONENT', 'async_outputs', 'agent_outputs']):
                    directories.append(item_path)
        
        total_tools = 0
        logger.info(f"Scanning directories: {directories}")
        
        # **FIXED: Load priority files first**
        all_python_files = []
        priority_files = []
        
        # Find all Python files and categorize them
        for directory in directories:
            if not os.path.exists(directory):
                logger.warning(f"Directory does not exist: {directory}")
                continue
                
            python_files = glob.glob(os.path.join(directory, "*.py"))
            
            for py_file in python_files:
                filename = os.path.basename(py_file)
                
                # Skip excluded files
                if filename in self.excluded_files:
                    logger.debug(f"Skipping excluded file: {filename}")
                    continue
                
                # Check if it's a priority file
                is_priority = False
                for pattern in self.priority_patterns:
                    if self._matches_pattern(filename, pattern):
                        priority_files.append(py_file)
                        is_priority = True
                        break
                
                if not is_priority:
                    all_python_files.append(py_file)
        
        logger.info(f"Found {len(priority_files)} priority files and {len(all_python_files)} regular files")
        
        # Load priority files first
        for py_file in priority_files:
            total_tools += self._load_single_file(py_file)
        
        # Then load regular files
        for py_file in all_python_files:
            total_tools += self._load_single_file(py_file)
        
        logger.info(f"🔧 Total tools discovered: {total_tools}")
        return total_tools
    
    def _matches_pattern(self, filename: str, pattern: str) -> bool:
        """Check if filename matches a glob pattern"""
        import fnmatch
        return fnmatch.fnmatch(filename, pattern)
    
    def _load_single_file(self, py_file: str) -> int:
        """Load a single Python file and register its tools"""
        filename = os.path.basename(py_file)
        module_name = filename[:-3]  # Remove .py
        
        # Skip if already imported
        if module_name in self.imported_modules:
            logger.debug(f"Module already imported: {module_name}")
            return 0
        
        tools_count = 0
        
        try:
            # **FIXED: More robust module loading with better error handling**
            module = self._load_module_safely(py_file, module_name)
            if module is None:
                return 0
            
            self.imported_modules.add(module_name)
            
            # Determine namespace prefix
            if hasattr(module, 'TOOL_NAMESPACE'):
                prefix = getattr(module, 'TOOL_NAMESPACE')
            else:
                # By default, use the module name
                prefix = module_name
                
                # Special case: if it ends with _adapter, remove that part
                if prefix.endswith("_adapter"):
                    prefix = prefix[:-8]  # Remove "_adapter"
            
            self.namespace_prefixes[module_name] = prefix
            
            # **PRIORITY 1: Register TOOL_REGISTRY tools first**
            registry_tools = 0
            if hasattr(module, 'TOOL_REGISTRY'):
                tool_registry = getattr(module, 'TOOL_REGISTRY')
                if isinstance(tool_registry, dict):
                    for tool_id, tool_handler in tool_registry.items():
                        # Handle full tool IDs properly
                        if ':' in tool_id:
                            full_tool_id = tool_id  # Already has namespace
                        else:
                            full_tool_id = f"{prefix}:{tool_id}"
                        
                        # **FIXED: Validate tool handler before registration**
                        if callable(tool_handler):
                            self.register_tool(full_tool_id, tool_handler)
                            registry_tools += 1
                            tools_count += 1
                        else:
                            logger.warning(f"Tool handler for {tool_id} is not callable")
                    
                    logger.info(f"✅ Registered {registry_tools} tools from TOOL_REGISTRY in {module_name}")
            
            # **PRIORITY 2: Auto-discover functions that should be registered as tools**
            auto_tools = self._discover_module_tools(module, prefix)
            tools_count += len(auto_tools)
            
            logger.info(f"✅ Imported module {module_name} with {registry_tools} registry tools + {len(auto_tools)} auto-discovered functions")
            
        except Exception as e:
            logger.error(f"❌ Error importing {module_name} from {py_file}: {e}")
            import traceback
            logger.debug(f"Full traceback: {traceback.format_exc()}")
        
        return tools_count
    
    def _load_module_safely(self, py_file: str, module_name: str):
        """Safely load a module with proper error handling"""
        try:
            # **FIXED: Add the module directory to sys.path BEFORE creating spec**
            module_dir = os.path.dirname(py_file)
            path_added = False
            if module_dir not in sys.path:
                sys.path.insert(0, module_dir)
                path_added = True
            
            try:
                # Create spec
                spec = importlib.util.spec_from_file_location(module_name, py_file)
                if spec is None or spec.loader is None:
                    logger.warning(f"Could not create spec for {py_file}")
                    return None
                
                # Create module
                module = importlib.util.module_from_spec(spec)
                
                # **FIXED: Add module to sys.modules before execution**
                sys.modules[module_name] = module
                
                # Execute module
                spec.loader.exec_module(module)
                logger.debug(f"Successfully loaded module: {module_name}")
                return module
                
            except Exception as e:
                logger.error(f"Error executing module {module_name}: {e}")
                # Remove from sys.modules if execution failed
                if module_name in sys.modules:
                    del sys.modules[module_name]
                return None
                
            finally:
                # Remove from sys.path if we added it
                if path_added and module_dir in sys.path:
                    sys.path.remove(module_dir)
                    
        except Exception as e:
            logger.error(f"Error loading module {module_name}: {e}")
            return None
    
    def _discover_module_tools(self, module, prefix: str) -> List[str]:
        """Discover and register tools from a module"""
        discovered_tools = []
        
        # Get all functions from the module
        for name, obj in inspect.getmembers(module):
            # Skip private functions, special methods, and non-functions
            if name.startswith('_') or not inspect.isfunction(obj):
                continue
            
            # Skip functions that start with excluded prefixes
            if any(name.startswith(excluded) for excluded in self.excluded_functions):
                continue
                
            # Skip functions that are already in TOOL_REGISTRY (avoid duplicates)
            if hasattr(module, 'TOOL_REGISTRY'):
                tool_registry = getattr(module, 'TOOL_REGISTRY')
                if isinstance(tool_registry, dict) and any(handler == obj for handler in tool_registry.values()):
                    continue
            
            # Check if function has a docstring (we only want documented functions)
            if obj.__doc__ and obj.__doc__.strip():
                # Create a tool ID based on the prefix and function name
                tool_id = f"{prefix}:{name}"
                self.register_tool(tool_id, obj)
                discovered_tools.append(tool_id)
                logger.debug(f"Auto-registered tool: {tool_id}")
        
        return discovered_tools
    
    def register_tool(self, tool_id: str, handler: Callable) -> None:
        """Register a function as a tool with flexible parameter handling"""
        @wraps(handler)
        def flexible_handler(**kwargs):
            try:
                # Get function signature
                sig = inspect.signature(handler)
                
                # If function takes **kwargs, pass everything
                if any(param.kind == param.VAR_KEYWORD for param in sig.parameters.values()):
                    return handler(**kwargs)
                
                # Otherwise, filter kwargs to match function signature
                filtered_kwargs = {}
                for param_name, param in sig.parameters.items():
                    if param_name in kwargs:
                        filtered_kwargs[param_name] = kwargs[param_name]
                    elif param.default == param.empty and param.kind not in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                        # Required parameter missing
                        logger.warning(f"Required parameter '{param_name}' missing for tool {tool_id}")
                        return {"error": f"Required parameter '{param_name}' missing"}
                
                return handler(**filtered_kwargs)
                
            except Exception as e:
                logger.error(f"Tool execution failed for {tool_id}: {str(e)}")
                return {"error": f"Tool execution failed: {str(e)}"}
        
        self.tools[tool_id] = flexible_handler
        logger.debug(f"Registered tool: {tool_id}")
    
    def execute_tool(self, tool_id: str, **kwargs) -> Any:
        """Execute a registered tool"""
        if tool_id not in self.tools:
            # Try to find it by prefix and auto-load
            if ':' in tool_id:
                prefix = tool_id.split(':', 1)[0]
                
                # Look for modules that might contain this tool
                for module_name, module_prefix in self.namespace_prefixes.items():
                    if module_prefix == prefix and module_name not in self.imported_modules:
                        # Try to import module
                        self._try_load_module(module_name, prefix)
                        break
        
        if tool_id not in self.tools:
            available_tools = self.get_available_tools_by_prefix(tool_id.split(':', 1)[0] if ':' in tool_id else '')
            error_msg = f"Unknown tool: {tool_id}"
            if available_tools:
                error_msg += f". Available tools with similar prefix: {', '.join(available_tools[:5])}"
            return {"error": error_msg}
        
        try:
            logger.info(f"Executing tool {tool_id} with params: {list(kwargs.keys())}")
            result = self.tools[tool_id](**kwargs)
            logger.debug(f"Tool {tool_id} executed successfully")
            return result
        except Exception as e:
            logger.error(f"Error executing tool {tool_id}: {str(e)}")
            return {"error": str(e)}
    
    def _try_load_module(self, module_name: str, prefix: str):
        """Try to load a module that might contain tools"""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            
            # Check multiple possible locations
            possible_paths = [
                os.path.join(current_dir, f"{module_name}.py"),
                os.path.join(current_dir, "COMPONENT", f"{module_name}.py"),
                os.path.join(current_dir, "tools", f"{module_name}.py"),
                os.path.join(current_dir, "adapters", f"{module_name}.py"),
            ]
            
            for module_path in possible_paths:
                if os.path.exists(module_path):
                    self._load_single_file(module_path)
                    logger.info(f"Dynamically loaded module: {module_name}")
                    break
                        
        except Exception as e:
            logger.warning(f"Failed to dynamically load module {module_name}: {e}")
    
    def get_all_tools(self) -> List[str]:
        """Get a list of all registered tool IDs"""
        return sorted(list(self.tools.keys()))
    
    def get_tools_by_prefix(self, prefix: str) -> List[str]:
        """Get tools by namespace prefix"""
        return [tool_id for tool_id in self.tools.keys() if tool_id.startswith(f"{prefix}:")]
    
    def get_available_tools_by_prefix(self, prefix: str) -> List[str]:
        """Get available tools that match a prefix"""
        if not prefix:
            return []
        return [tool_id for tool_id in self.tools.keys() if tool_id.startswith(prefix)]
    
    def is_tool_available(self, tool_id: str) -> bool:
        """Check if a tool is available"""
        return tool_id in self.tools
    
    def get_tool_info(self, tool_id: str) -> Dict[str, Any]:
        """Get information about a specific tool"""
        if tool_id not in self.tools:
            return {"error": f"Tool not found: {tool_id}"}
        
        try:
            # Get the original function from the wrapper
            original_func = self.tools[tool_id].__wrapped__ if hasattr(self.tools[tool_id], '__wrapped__') else self.tools[tool_id]
            
            # Get function signature and docstring
            sig = inspect.signature(original_func)
            
            return {
                "tool_id": tool_id,
                "name": original_func.__name__,
                "module": original_func.__module__ if hasattr(original_func, '__module__') else 'unknown',
                "docstring": original_func.__doc__ or "No documentation available",
                "parameters": {
                    name: {
                        "type": str(param.annotation) if param.annotation != param.empty else "Any",
                        "default": str(param.default) if param.default != param.empty else "Required",
                        "kind": str(param.kind)
                    }
                    for name, param in sig.parameters.items()
                }
            }
        except Exception as e:
            return {"error": f"Could not get tool info: {str(e)}"}
    
    def list_tools_by_module(self) -> Dict[str, List[str]]:
        """List tools organized by module/namespace"""
        tools_by_module = {}
        for tool_id in self.tools.keys():
            if ':' in tool_id:
                prefix, _ = tool_id.split(':', 1)
                if prefix not in tools_by_module:
                    tools_by_module[prefix] = []
                tools_by_module[prefix].append(tool_id)
            else:
                if 'global' not in tools_by_module:
                    tools_by_module['global'] = []
                tools_by_module['global'].append(tool_id)
        
        return tools_by_module
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the tool manager"""
        tools_by_module = self.list_tools_by_module()
        
        return {
            "total_tools": len(self.tools),
            "total_modules": len(self.imported_modules),
            "tools_by_module": {k: len(v) for k, v in tools_by_module.items()},
            "namespaces": list(self.namespace_prefixes.values())
        }
    
    def force_reload_adapters(self) -> Dict[str, Any]:
        """Force reload all adapter modules"""
        try:
            # Clear existing state
            self.tools.clear()
            self.imported_modules.clear()
            self.namespace_prefixes.clear()
            
            # Re-discover all tools
            total_tools = self.discover_tools()
            
            return {
                "success": True,
                "total_tools": total_tools,
                "stats": self.get_stats()
            }
        except Exception as e:
            return {"error": f"Failed to force reload adapters: {str(e)}"}
    
    def debug_tool_loading(self) -> Dict[str, Any]:
        """Debug information about tool loading"""
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Check for adapter files
        adapter_files = []
        for pattern in self.priority_patterns:
            adapter_files.extend(glob.glob(os.path.join(current_dir, pattern)))
        
        return {
            "current_directory": current_dir,
            "adapter_files_found": [os.path.basename(f) for f in adapter_files],
            "imported_modules": list(self.imported_modules),
            "namespace_prefixes": self.namespace_prefixes,
            "total_tools": len(self.tools),
            "tools_by_namespace": self.list_tools_by_module()
        }

# Create a global tool manager instance
tool_manager = ToolManager()

# Additional utility functions that can be used as tools themselves
def list_all_tools(**kwargs) -> Dict[str, Any]:
    """List all available tools"""
    return {
        "tools": tool_manager.get_all_tools(),
        "stats": tool_manager.get_stats(),
        "by_module": tool_manager.list_tools_by_module()
    }

def get_tool_info(**kwargs) -> Dict[str, Any]:
    """Get information about a specific tool"""
    tool_id = kwargs.get('tool_id', '')
    if not tool_id:
        return {"error": "tool_id parameter is required"}
    
    return tool_manager.get_tool_info(tool_id)

def reload_tools(**kwargs) -> Dict[str, Any]:
    """Reload and rediscover all tools"""
    return tool_manager.force_reload_adapters()

def debug_tool_loading(**kwargs) -> Dict[str, Any]:
    """Debug tool loading process"""
    return tool_manager.debug_tool_loading()

# Register these utility tools
tool_manager.register_tool("tools:list_all", list_all_tools)
tool_manager.register_tool("tools:get_info", get_tool_info)
tool_manager.register_tool("tools:reload", reload_tools)
tool_manager.register_tool("tools:debug", debug_tool_loading)

# **FIXED: Initialize tool discovery on import**
if __name__ == "__main__":
    # Run tool discovery
    discovered_count = tool_manager.discover_tools()
    print(f"🔧 Tool Manager initialized with {discovered_count} tools")
    
    # Print debug info
    debug_info = tool_manager.debug_tool_loading()
    print(f"📁 Found adapter files: {debug_info['adapter_files_found']}")
    print(f"🎯 Namespaces: {debug_info['namespace_prefixes']}")
else:
    # Auto-discover tools when imported
    try:
        discovered_count = tool_manager.discover_tools()
        print(f"🔧 Tool Manager auto-initialized with {discovered_count} tools")
    except Exception as e:
        print(f"❌ Tool Manager initialization failed: {e}")