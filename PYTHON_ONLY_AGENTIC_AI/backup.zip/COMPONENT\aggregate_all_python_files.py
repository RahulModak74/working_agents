#!/usr/bin/env python3
"""
Python Files Aggregator Script
Creates a single text file containing the name and content of all Python files in the current directory.
"""

import os
import glob
from datetime import datetime

def aggregate_python_files():
    """Aggregate all Python files in the current directory into a single text file."""
    
    # Set the output file name
    output_file = "all_python_files.txt"
    
    # Get all Python files in current directory
    python_files = glob.glob("*.py")
    
    # Sort files alphabetically for consistent output
    python_files.sort()
    
    try:
        with open(output_file, 'w', encoding='utf-8') as outfile:
            # Write header
            outfile.write("Python Files Content Aggregation\n")
            outfile.write(f"Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}\n")
            outfile.write("=" * 50 + "\n\n")
            
            file_count = 0
            
            # Process each Python file
            for py_file in python_files:
                # Skip the output file itself if it's a .py file
                if py_file == __file__.split('\\')[-1] or py_file == __file__.split('/')[-1]:
                    continue
                    
                file_count += 1
                print(f"Processing: {py_file}")
                
                try:
                    # Write file separator and name
                    outfile.write("=" * 50 + "\n")
                    outfile.write(f"FILE: {py_file}\n")
                    outfile.write("=" * 50 + "\n\n")
                    
                    # Read and write file content
                    with open(py_file, 'r', encoding='utf-8') as infile:
                        content = infile.read()
                        outfile.write(content)
                        
                        # Ensure there's a newline at the end if not present
                        if not content.endswith('\n'):
                            outfile.write('\n')
                    
                    # Add blank lines between files
                    outfile.write("\n\n")
                    
                except UnicodeDecodeError:
                    # Handle files with encoding issues
                    print(f"Warning: Could not read {py_file} with UTF-8 encoding. Trying with errors='ignore'")
                    try:
                        with open(py_file, 'r', encoding='utf-8', errors='ignore') as infile:
                            content = infile.read()
                            outfile.write(content)
                            if not content.endswith('\n'):
                                outfile.write('\n')
                        outfile.write("\n\n")
                    except Exception as e:
                        outfile.write(f"ERROR: Could not read file {py_file}: {str(e)}\n\n\n")
                        print(f"Error reading {py_file}: {str(e)}")
                        
                except Exception as e:
                    outfile.write(f"ERROR: Could not read file {py_file}: {str(e)}\n\n\n")
                    print(f"Error reading {py_file}: {str(e)}")
            
            # Write summary
            outfile.write("=" * 50 + "\n")
            outfile.write(f"SUMMARY: Processed {file_count} Python files\n")
            outfile.write(f"Output saved to: {output_file}\n")
            
        print(f"\nScript completed successfully!")
        print(f"Processed {file_count} Python files")
        print(f"Output saved to: {output_file}")
        
        # Display file size
        file_size = os.path.getsize(output_file)
        print(f"Output file size: {file_size:,} bytes")
        
    except Exception as e:
        print(f"Error creating output file: {str(e)}")
        return False
    
    return True

def main():
    """Main function to run the aggregation."""
    print("Python Files Aggregator")
    print("-" * 25)
    
    # Check if we're in a directory with Python files
    python_files = glob.glob("*.py")
    if not python_files:
        print("No Python files found in the current directory.")
        return
    
    print(f"Found {len(python_files)} Python file(s) in current directory:")
    for py_file in sorted(python_files):
        print(f"  - {py_file}")
    
    print("\nStarting aggregation...")
    
    if aggregate_python_files():
        print("\nAggregation completed successfully!")
    else:
        print("\nAggregation failed!")

if __name__ == "__main__":
    main()