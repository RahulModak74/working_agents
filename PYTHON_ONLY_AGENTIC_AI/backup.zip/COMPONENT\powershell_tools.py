#!/usr/bin/env python3

import os
import subprocess
import json
import base64
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger("powershell_tools")

# Set tool namespace
TOOL_NAMESPACE = "ps"

class PowerShellExecutor:
    """Execute PowerShell commands safely and return structured results"""
    
    def __init__(self):
        self.execution_policy_set = False
    
    def _ensure_execution_policy(self):
        """Ensure PowerShell execution policy allows script execution"""
        if not self.execution_policy_set:
            try:
                # Set execution policy for current process only
                cmd = ["powershell", "-Command", "Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force"]
                subprocess.run(cmd, capture_output=True, text=True, check=True)
                self.execution_policy_set = True
                logger.info("PowerShell execution policy set to Bypass for current process")
            except Exception as e:
                logger.warning(f"Could not set PowerShell execution policy: {e}")
    
    def execute_command(self, command: str, timeout: int = 30, return_json: bool = False) -> Dict[str, Any]:
        """Execute a PowerShell command and return results"""
        self._ensure_execution_policy()
        
        try:
            # Prepare the command
            if return_json:
                # Wrap command to return JSON output
                wrapped_command = f"$result = {command}; $result | ConvertTo-Json -Depth 10"
            else:
                wrapped_command = command
            
            # Execute PowerShell command
            cmd = ["powershell", "-Command", wrapped_command]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False  # Don't raise on non-zero exit
            )
            
            # Parse results
            success = result.returncode == 0
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()
            
            if return_json and success and stdout:
                try:
                    parsed_output = json.loads(stdout)
                    return {
                        "success": True,
                        "output": parsed_output,
                        "raw_output": stdout,
                        "error": None,
                        "exit_code": result.returncode
                    }
                except json.JSONDecodeError:
                    # Fall back to raw output if JSON parsing fails
                    pass
            
            return {
                "success": success,
                "output": stdout,
                "error": stderr if stderr else None,
                "exit_code": result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": None,
                "error": f"Command timed out after {timeout} seconds",
                "exit_code": -1
            }
        except Exception as e:
            return {
                "success": False,
                "output": None,
                "error": str(e),
                "exit_code": -1
            }

# Global executor instance
ps_executor = PowerShellExecutor()

# Core PowerShell Tools
def ps_execute(command: str, timeout: int = 30, return_json: bool = False, **kwargs) -> Dict[str, Any]:
    """Execute arbitrary PowerShell command"""
    return ps_executor.execute_command(command, timeout, return_json)

def ps_get_processes(name: str = None, **kwargs) -> Dict[str, Any]:
    """Get running processes"""
    if name:
        command = f"Get-Process -Name '{name}' -ErrorAction SilentlyContinue"
    else:
        command = "Get-Process"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_get_services(name: str = None, status: str = None, **kwargs) -> Dict[str, Any]:
    """Get Windows services"""
    command = "Get-Service"
    
    if name:
        command += f" -Name '{name}'"
    
    if status:
        command += f" | Where-Object {{ $_.Status -eq '{status}' }}"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_get_eventlog(log_name: str = "Security", max_events: int = 100, 
                   event_id: int = None, after: str = None, **kwargs) -> Dict[str, Any]:
    """Get Windows event logs"""
    command = f"Get-WinEvent -LogName '{log_name}' -MaxEvents {max_events}"
    
    filters = []
    if event_id:
        filters.append(f"Id -eq {event_id}")
    if after:
        filters.append(f"TimeCreated -gt '{after}'")
    
    if filters:
        filter_block = " -and ".join(filters)
        command += f" | Where-Object {{ {filter_block} }}"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_get_network_connections(**kwargs) -> Dict[str, Any]:
    """Get active network connections"""
    command = "Get-NetTCPConnection | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, ProcessId"
    return ps_executor.execute_command(command, return_json=True)

def ps_get_scheduled_tasks(task_name: str = None, **kwargs) -> Dict[str, Any]:
    """Get scheduled tasks"""
    if task_name:
        command = f"Get-ScheduledTask -TaskName '{task_name}'"
    else:
        command = "Get-ScheduledTask"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_get_registry_value(path: str, name: str = None, **kwargs) -> Dict[str, Any]:
    """Get registry values"""
    if name:
        command = f"Get-ItemProperty -Path '{path}' -Name '{name}'"
    else:
        command = f"Get-ItemProperty -Path '{path}'"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_test_network_connection(computer_name: str, port: int, **kwargs) -> Dict[str, Any]:
    """Test network connectivity"""
    command = f"Test-NetConnection -ComputerName '{computer_name}' -Port {port}"
    return ps_executor.execute_command(command, return_json=True)

# Security-Specific Tools
def ps_get_security_events(event_ids: List[int] = None, hours_back: int = 24, **kwargs) -> Dict[str, Any]:
    """Get security-related events"""
    start_time = f"(Get-Date).AddHours(-{hours_back})"
    command = f"Get-WinEvent -FilterHashtable @{{LogName='Security'; StartTime={start_time}"
    
    if event_ids:
        ids_str = ",".join(map(str, event_ids))
        command += f"; ID={ids_str}"
    
    command += "}"
    return ps_executor.execute_command(command, return_json=True)

def ps_get_failed_logins(hours_back: int = 24, **kwargs) -> Dict[str, Any]:
    """Get failed login attempts"""
    return ps_get_security_events(event_ids=[4625], hours_back=hours_back)

def ps_get_successful_logins(hours_back: int = 24, **kwargs) -> Dict[str, Any]:
    """Get successful login events"""
    return ps_get_security_events(event_ids=[4624], hours_back=hours_back)

def ps_get_user_accounts(**kwargs) -> Dict[str, Any]:
    """Get local user accounts"""
    command = "Get-LocalUser | Select-Object Name, Enabled, LastLogon, PasswordLastSet"
    return ps_executor.execute_command(command, return_json=True)

def ps_get_firewall_rules(enabled_only: bool = True, **kwargs) -> Dict[str, Any]:
    """Get Windows Firewall rules"""
    command = "Get-NetFirewallRule"
    
    if enabled_only:
        command += " | Where-Object { $_.Enabled -eq 'True' }"
    
    return ps_executor.execute_command(command, return_json=True)

def ps_get_startup_programs(**kwargs) -> Dict[str, Any]:
    """Get startup programs"""
    command = """
    $startup = @()
    $startup += Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, Location
    $startup += Get-ItemProperty "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" | 
                Get-Member -MemberType NoteProperty | 
                ForEach-Object { [PSCustomObject]@{Name=$_.Name; Command=(Get-ItemProperty "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run").$($_.Name); Location="HKLM Run"} }
    $startup
    """
    return ps_executor.execute_command(command, return_json=True)

# File System Security Tools
def ps_get_file_permissions(path: str, **kwargs) -> Dict[str, Any]:
    """Get file/folder permissions"""
    command = f"Get-Acl -Path '{path}' | Select-Object -ExpandProperty Access"
    return ps_executor.execute_command(command, return_json=True)

def ps_find_files_by_extension(path: str, extension: str, recurse: bool = True, **kwargs) -> Dict[str, Any]:
    """Find files by extension"""
    recurse_flag = "-Recurse" if recurse else ""
    command = f"Get-ChildItem -Path '{path}' {recurse_flag} -Filter '*.{extension}' | Select-Object FullName, Length, LastWriteTime"
    return ps_executor.execute_command(command, return_json=True)

def ps_get_file_hashes(path: str, algorithm: str = "SHA256", **kwargs) -> Dict[str, Any]:
    """Get file hashes"""
    command = f"Get-FileHash -Path '{path}' -Algorithm {algorithm}"
    return ps_executor.execute_command(command, return_json=True)

# System Information Tools
def ps_get_system_info(**kwargs) -> Dict[str, Any]:
    """Get comprehensive system information"""
    command = """
    [PSCustomObject]@{
        ComputerName = $env:COMPUTERNAME
        OS = (Get-CimInstance Win32_OperatingSystem).Caption
        Version = (Get-CimInstance Win32_OperatingSystem).Version
        Architecture = (Get-CimInstance Win32_OperatingSystem).OSArchitecture
        TotalMemory = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)
        Domain = (Get-CimInstance Win32_ComputerSystem).Domain
        LastBootTime = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
        CurrentUser = $env:USERNAME
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
    }
    """
    return ps_executor.execute_command(command, return_json=True)

def ps_get_installed_software(**kwargs) -> Dict[str, Any]:
    """Get installed software"""
    command = """
    Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | 
    Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | 
    Where-Object { $_.DisplayName } | 
    Sort-Object DisplayName
    """
    return ps_executor.execute_command(command, return_json=True)

def ps_get_hotfixes(**kwargs) -> Dict[str, Any]:
    """Get installed Windows updates/hotfixes"""
    command = "Get-HotFix | Select-Object HotFixID, Description, InstalledBy, InstalledOn | Sort-Object InstalledOn -Descending"
    return ps_executor.execute_command(command, return_json=True)

# PowerShell Empire Integration Tools
def ps_empire_install_module(module_name: str, **kwargs) -> Dict[str, Any]:
    """Install PowerShell Empire module"""
    command = f"Install-Module -Name {module_name} -Force -Scope CurrentUser"
    return ps_executor.execute_command(command)

def ps_empire_list_modules(**kwargs) -> Dict[str, Any]:
    """List available Empire modules"""
    command = "Get-Module -ListAvailable | Where-Object { $_.Name -like '*Empire*' -or $_.Name -like '*PowerSploit*' }"
    return ps_executor.execute_command(command, return_json=True)

# Advanced Security Analysis
def ps_detect_suspicious_processes(**kwargs) -> Dict[str, Any]:
    """Detect potentially suspicious processes"""
    command = """
    Get-Process | Where-Object {
        $_.ProcessName -match '(cmd|powershell|wscript|cscript)' -and
        $_.CPU -gt 10
    } | Select-Object ProcessName, Id, CPU, WorkingSet, StartTime, Path
    """
    return ps_executor.execute_command(command, return_json=True)

def ps_check_persistence_locations(**kwargs) -> Dict[str, Any]:
    """Check common persistence locations"""
    command = """
    $locations = @()
    
    # Registry Run keys
    $runKeys = @(
        "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
        "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
        "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce",
        "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
    )
    
    foreach ($key in $runKeys) {
        if (Test-Path $key) {
            Get-ItemProperty $key | Get-Member -MemberType NoteProperty | 
            ForEach-Object { 
                $locations += [PSCustomObject]@{
                    Location = $key
                    Name = $_.Name
                    Value = (Get-ItemProperty $key).$($_.Name)
                    Type = "Registry"
                }
            }
        }
    }
    
    # Startup folder
    $startupPaths = @(
        "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup",
        "$env:ALLUSERSPROFILE\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
    )
    
    foreach ($path in $startupPaths) {
        if (Test-Path $path) {
            Get-ChildItem $path | ForEach-Object {
                $locations += [PSCustomObject]@{
                    Location = $path
                    Name = $_.Name
                    Value = $_.FullName
                    Type = "StartupFolder"
                }
            }
        }
    }
    
    $locations
    """
    return ps_executor.execute_command(command, return_json=True)

def ps_network_reconnaissance(**kwargs) -> Dict[str, Any]:
    """Perform basic network reconnaissance"""
    command = """
    [PSCustomObject]@{
        NetworkAdapters = Get-NetAdapter | Select-Object Name, InterfaceDescription, LinkSpeed, Status
        IPConfiguration = Get-NetIPConfiguration | Select-Object InterfaceAlias, IPv4Address, IPv6Address, DNSServer
        RoutingTable = Get-NetRoute | Select-Object DestinationPrefix, NextHop, InterfaceAlias, RouteMetric
        ActiveConnections = Get-NetTCPConnection | Group-Object State | Select-Object Name, Count
        ListeningPorts = Get-NetTCPConnection -State Listen | Select-Object LocalAddress, LocalPort, ProcessId
    }
    """
    return ps_executor.execute_command(command, return_json=True)

# Tool Registry
TOOL_REGISTRY = {
    "execute": ps_execute,
    "get_processes": ps_get_processes,
    "get_services": ps_get_services,
    "get_eventlog": ps_get_eventlog,
    "get_network_connections": ps_get_network_connections,
    "get_scheduled_tasks": ps_get_scheduled_tasks,
    "get_registry_value": ps_get_registry_value,
    "test_network_connection": ps_test_network_connection,
    "get_security_events": ps_get_security_events,
    "get_failed_logins": ps_get_failed_logins,
    "get_successful_logins": ps_get_successful_logins,
    "get_user_accounts": ps_get_user_accounts,
    "get_firewall_rules": ps_get_firewall_rules,
    "get_startup_programs": ps_get_startup_programs,
    "get_file_permissions": ps_get_file_permissions,
    "find_files_by_extension": ps_find_files_by_extension,
    "get_file_hashes": ps_get_file_hashes,
    "get_system_info": ps_get_system_info,
    "get_installed_software": ps_get_installed_software,
    "get_hotfixes": ps_get_hotfixes,
    "empire_install_module": ps_empire_install_module,
    "empire_list_modules": ps_empire_list_modules,
    "detect_suspicious_processes": ps_detect_suspicious_processes,
    "check_persistence_locations": ps_check_persistence_locations,
    "network_reconnaissance": ps_network_reconnaissance
}

print("✅ PowerShell cybersecurity tools loaded")