#!/usr/bin/env python3
"""
Auto Import All Tools from COMPONENT Directory
One import to rule them all!
"""

import sys
import os
import importlib.util
from pathlib import Path
import logging

logger = logging.getLogger("auto_import")

class ToolImporter:
    """Automatically import all tools from COMPONENT directory"""
    
    def __init__(self):
        self.tools = {}
        self.component_dir = Path(__file__).parent / "COMPONENT"
        
    def import_all_tools(self):
        """Import all tools and make them available as simple functions"""
        
        if not self.component_dir.exists():
            print(f"❌ COMPONENT directory not found: {self.component_dir}")
            return {}
        
        # Add COMPONENT to path
        if str(self.component_dir) not in sys.path:
            sys.path.insert(0, str(self.component_dir))
        
        # Find all Python files in COMPONENT
        tool_files = list(self.component_dir.glob("*.py"))
        print(f"🔍 Found {len(tool_files)} tool files in COMPONENT/")
        
        imported_tools = {}
        
        for py_file in tool_files:
            if py_file.name.startswith('__'):
                continue
                
            module_name = py_file.stem
            
            try:
                # Import the module
                spec = importlib.util.spec_from_file_location(module_name, py_file)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Get TOOL_REGISTRY if available
                if hasattr(module, 'TOOL_REGISTRY'):
                    registry = module.TOOL_REGISTRY
                    for tool_name, tool_func in registry.items():
                        # Clean up tool name
                        clean_name = tool_name.replace(':', '_')
                        imported_tools[clean_name] = tool_func
                        imported_tools[tool_name] = tool_func  # Keep original too
                
                # Also import any function with docstring (auto-discovery)
                for attr_name in dir(module):
                    if not attr_name.startswith('_'):
                        attr = getattr(module, attr_name)
                        if callable(attr) and hasattr(attr, '__doc__') and attr.__doc__:
                            imported_tools[f"{module_name}_{attr_name}"] = attr
                
                print(f"✅ Imported {module_name}")
                
            except Exception as e:
                print(f"❌ Failed to import {module_name}: {e}")
        
        self.tools = imported_tools
        print(f"🎉 Total tools available: {len(imported_tools)}")
        
        return imported_tools

# Global instance
_tool_importer = ToolImporter()
_tools = _tool_importer.import_all_tools()

# Make all tools available as globals
globals().update(_tools)

# Also create a simple function to call any tool
def call_tool(tool_name, **kwargs):
    """Call any tool by name"""
    if tool_name in _tools:
        return _tools[tool_name](**kwargs)
    else:
        available = [name for name in _tools.keys() if tool_name.lower() in name.lower()]
        return {"error": f"Tool '{tool_name}' not found. Similar: {available[:5]}"}

def list_tools():
    """List all available tools"""
    return sorted(list(_tools.keys()))

def get_tools_by_prefix(prefix):
    """Get tools starting with prefix"""
    return [name for name in _tools.keys() if name.startswith(prefix)]

# Print available tools on import
print(f"🔧 Available tool prefixes:")
prefixes = set()
for tool_name in _tools.keys():
    if '_' in tool_name:
        prefix = tool_name.split('_')[0]
        prefixes.add(prefix)
    elif ':' in tool_name:
        prefix = tool_name.split(':')[0] 
        prefixes.add(prefix)

for prefix in sorted(prefixes):
    count = len(get_tools_by_prefix(prefix))
    print(f"   {prefix}: {count} tools")

print(f"\n💡 Usage examples:")
print(f"   from auto_import_tools import *")
print(f"   result = browser_create(headless=True)")
print(f"   result = research_combined_search(query='AI safety')")
print(f"   result = call_tool('browser:navigate', url='https://example.com')")