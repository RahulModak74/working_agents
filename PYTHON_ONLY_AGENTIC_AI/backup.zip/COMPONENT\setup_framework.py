#!/usr/bin/env python3

import os
import sys
import subprocess
import json
import shutil
from pathlib import Path

def check_powershell():
    """Check if PowerShell is available"""
    try:
        result = subprocess.run(
            ["powershell", "-Command", "Write-Output 'PowerShell Available'"],
            capture_output=True, text=True, timeout=10
        )
        return result.returncode == 0
    except Exception:
        return False

def setup_directories():
    """Create necessary directories"""
    directories = [
        "agent_outputs",
        "logs", 
        "workflows",
        "tools",
        "data"
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")

def install_requirements():
    """Install Python requirements if requirements.txt exists"""
    if Path("requirements.txt").exists():
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
            print("✅ Python requirements installed")
        except subprocess.CalledProcessError:
            print("⚠️ Failed to install Python requirements")
    else:
        print("ℹ️ No requirements.txt found")

def setup_powershell_environment():
    """Configure PowerShell environment for the framework"""
    setup_script = """
    # Set execution policy for current user
    try {
        Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
        Write-Output "✅ PowerShell execution policy set to RemoteSigned"
    } catch {
        Write-Output "⚠️ Could not set execution policy: $($_.Exception.Message)"
    }

    # Check for useful modules
    $modules = @('ActiveDirectory', 'DnsClient', 'NetTCPIP', 'ScheduledTasks')
    $available = @()
    $missing = @()

    foreach ($module in $modules) {
        if (Get-Module -ListAvailable -Name $module) {
            $available += $module
        } else {
            $missing += $module
        }
    }

    Write-Output "✅ Available modules: $($available -join ', ')"
    if ($missing.Count -gt 0) {
        Write-Output "⚠️ Missing modules: $($missing -join ', ')"
    }

    # Check PowerShell version
    Write-Output "✅ PowerShell version: $($PSVersionTable.PSVersion)"

    # Test basic security commands
    try {
        $processes = Get-Process | Measure-Object
        Write-Output "✅ Security commands working - Found $($processes.Count) processes"
    } catch {
        Write-Output "⚠️ Security commands may not work properly"
    }
    """
    
    try:
        result = subprocess.run(
            ["powershell", "-Command", setup_script],
            capture_output=True, text=True, timeout=30
        )
        print(result.stdout)
        if result.stderr:
            print(f"Errors: {result.stderr}")
    except Exception as e:
        print(f"⚠️ PowerShell setup failed: {e}")

def create_sample_workflows():
    """Create sample workflow files"""
    workflows = {
        "quick_security_check.json": {
            "variables": {
                "hours_back": 4,
                "scan_type": "quick"
            },
            "steps": [
                {
                    "agent": "quick_security_scan",
                    "type": "agent",
                    "content": "Perform quick security check of the system. Look for failed logins, suspicious processes, and basic security posture.",
                    "tools": ["ps:get_failed_logins", "ps:detect_suspicious_processes", "ps:get_system_info"],
                    "output_format": {
                        "type": "json",
                        "schema": {
                            "security_status": "object",
                            "threats_found": "array",
                            "recommendations": "array"
                        }
                    }
                }
            ]
        },
        
        "network_security_audit.json": {
            "variables": {
                "scan_ports": "common",
                "check_firewall": True
            },
            "steps": [
                {
                    "agent": "network_audit",
                    "type": "agent", 
                    "content": "Audit network security configuration including firewall rules, open ports, and active connections.",
                    "tools": ["ps:get_network_connections", "ps:get_firewall_rules", "ps:network_reconnaissance"],
                    "output_format": {
                        "type": "markdown",
                        "sections": ["Network Overview", "Security Findings", "Recommendations"]
                    }
                }
            ]
        }
    }
    
    workflows_dir = Path("workflows")
    for filename, content in workflows.items():
        workflow_path = workflows_dir / filename
        with open(workflow_path, 'w', encoding='utf-8') as f:
            json.dump(content, f, indent=2)
        print(f"✅ Created sample workflow: {filename}")

def test_framework():
    """Test the framework setup"""
    print("\n🧪 Testing framework setup...")
    
    try:
        # Test tool discovery
        from tool_manager import tool_manager
        num_tools = tool_manager.discover_tools()
        print(f"✅ Discovered {num_tools} tools")
        
        # Test PowerShell tools
        if tool_manager.is_tool_available("ps:get_system_info"):
            result = tool_manager.execute_tool("ps:get_system_info")
            if result.get("success"):
                print("✅ PowerShell tools working")
            else:
                print(f"⚠️ PowerShell tools error: {result.get('error')}")
        else:
            print("⚠️ PowerShell tools not found")
        
        # Test Empire tools
        if tool_manager.is_tool_available("empire:check_installation"):
            result = tool_manager.execute_tool("empire:check_installation")
            if result.get("success"):
                print("✅ Empire tools available")
            else:
                print("ℹ️ Empire tools available but may need setup")
        else:
            print("ℹ️ Empire tools not loaded (this is normal)")
            
    except Exception as e:
        print(f"⚠️ Framework test failed: {e}")

def main():
    """Main setup function"""
    print("🚀 Setting up PowerShell Cybersecurity Framework...")
    
    # Check prerequisites
    if not check_powershell():
        print("❌ PowerShell not found! Please install PowerShell.")
        sys.exit(1)
    print("✅ PowerShell found")
    
    # Setup
    setup_directories()
    install_requirements()
    setup_powershell_environment()
    create_sample_workflows()
    
    # Test everything
    test_framework()
    
    print("\n🎉 Framework setup complete!")
    print("\n📖 Usage Examples:")
    print("  # Quick security check")
    print("  python enhanced_agent_runner.py --workflow workflows/quick_security_check.json")
    print("\n  # Network security audit")
    print("  python enhanced_agent_runner.py --workflow workflows/network_security_audit.json")
    print("\n  # Interactive mode")
    print("  python enhanced_agent_runner.py")
    print("\n  # Full cybersecurity assessment")
    print("  python enhanced_agent_runner.py --workflow cybersec_workflow.json")
    print("\n  # Red team assessment (with Empire)")
    print("  python enhanced_agent_runner.py --workflow empire_workflow.json")

if __name__ == "__main__":
    main()