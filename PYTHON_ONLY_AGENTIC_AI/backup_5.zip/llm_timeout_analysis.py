#!/usr/bin/env python3
"""
Quick fix for LLM timeout issues in smart_auto_download_workflow.py
"""

import asyncio
import aiohttp
import json
from pathlib import Path

async def test_llm_connection():
    """Test if the LLM endpoint is responding"""
    
    from config import CONFIG
    
    print("🔍 Testing LLM connection...")
    print(f"   Model: {CONFIG['default_model']}")
    print(f"   Endpoint: {CONFIG['endpoint']}")
    
    # Simple test message
    test_payload = {
        "model": CONFIG['default_model'],
        "messages": [{"role": "user", "content": "Hello, respond with just 'OK'"}],
        "temperature": 0.1,
        "max_tokens": 10
    }
    
    headers = {"Content-Type": "application/json"}
    if CONFIG.get("api_key"):
        headers["Authorization"] = f"Bearer {CONFIG['api_key']}"
    
    try:
        timeout = aiohttp.ClientTimeout(total=30)  # 30 second timeout
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(CONFIG["endpoint"], json=test_payload, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    content = (data.get('content', '') or 
                             data.get('choices', [{}])[0].get('message', {}).get('content', ''))
                    print(f"✅ LLM responding: '{content.strip()}'")
                    return True
                else:
                    print(f"❌ LLM error: HTTP {response.status}")
                    error_text = await response.text()
                    print(f"   Error: {error_text[:200]}")
                    return False
                    
    except asyncio.TimeoutError:
        print("❌ LLM timeout: No response within 30 seconds")
        return False
    except Exception as e:
        print(f"❌ LLM connection failed: {str(e)}")
        return False

def create_simplified_prompt():
    """Create a much simpler requirement analysis prompt"""
    
    return """
Analyze this use case and suggest tools:

USE CASE: Cryptocurrency Portfolio Analysis with Social Media Sentiment

Suggest 2-3 GitHub repos, 2-3 PyPI packages for this task.

Respond with simple JSON:
{
  "github_repos": [
    {"repo": "ccxt/ccxt", "purpose": "crypto APIs", "priority": "high"}
  ],
  "pypi_packages": [
    {"package": "tweepy", "purpose": "Twitter API", "priority": "high"}
  ],
  "reasoning": "Basic crypto and social media tools needed"
}
"""

async def test_simplified_llm_call():
    """Test LLM with simplified prompt"""
    
    from llm_powered_solution import LLMAgent
    
    print("\n🧪 Testing simplified LLM call...")
    
    try:
        analyzer = LLMAgent("TestAnalyst", "You provide simple, concise responses.")
        
        # Set a timeout for the LLM call
        response = await asyncio.wait_for(
            analyzer.call_llm(create_simplified_prompt()),
            timeout=60.0  # 60 second timeout
        )
        
        print(f"✅ LLM responded ({len(response)} chars)")
        print(f"   Preview: {response[:100]}...")
        
        # Try to parse JSON
        import re
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                print(f"✅ JSON parsed successfully")
                print(f"   GitHub repos: {len(parsed.get('github_repos', []))}")
                print(f"   PyPI packages: {len(parsed.get('pypi_packages', []))}")
                return True
            except json.JSONDecodeError:
                print("⚠️ JSON parsing failed")
                return False
        else:
            print("⚠️ No JSON found in response")
            return False
            
    except asyncio.TimeoutError:
        print("❌ LLM call timed out after 60 seconds")
        return False
    except Exception as e:
        print(f"❌ LLM call failed: {str(e)}")
        return False

def create_timeout_wrapper():
    """Create a timeout wrapper for the LLM call in the workflow"""
    
    wrapper_code = '''
async def call_llm_with_timeout(self, prompt, timeout_seconds=120):
    """Call LLM with timeout protection"""
    try:
        return await asyncio.wait_for(
            self.call_llm(prompt),
            timeout=timeout_seconds
        )
    except asyncio.TimeoutError:
        return f"ERROR: LLM call timed out after {timeout_seconds} seconds. Using fallback response."
    except Exception as e:
        return f"ERROR: LLM call failed: {str(e)}. Using fallback response."
'''
    
    return wrapper_code

def create_fallback_requirements():
    """Create fallback requirements if LLM fails"""
    
    fallback = {
        "github_repos": [
            {"repo": "ccxt/ccxt", "purpose": "Cryptocurrency exchange APIs", "priority": "high"},
            {"repo": "twintproject/twint", "purpose": "Twitter scraping", "priority": "high"}
        ],
        "pypi_packages": [
            {"package": "tweepy", "purpose": "Twitter API client", "priority": "high"},
            {"package": "pandas", "purpose": "Data analysis", "priority": "high"},
            {"package": "requests", "purpose": "HTTP requests", "priority": "high"}
        ],
        "docker_images": [
            {"image": "redis:alpine", "purpose": "Caching and data storage", "priority": "medium"}
        ],
        "reasoning": "Fallback selection of essential crypto and social media tools"
    }
    
    return fallback

async def fix_workflow_llm_timeout():
    """Main fix function"""
    
    print("🚀 LLM TIMEOUT DIAGNOSTIC & FIX")
    print("=" * 50)
    
    # Step 1: Test basic LLM connection
    llm_works = await test_llm_connection()
    
    if not llm_works:
        print("\n💡 SOLUTIONS:")
        print("1. Start Ollama: ollama serve")
        print("2. Pull model: ollama pull qwen2.5:7b")
        print("3. Test model: ollama run qwen2.5:7b")
        print("4. Or switch to OpenRouter in config.py")
        return False
    
    # Step 2: Test with simplified prompt
    simple_works = await test_simplified_llm_call()
    
    if simple_works:
        print("\n✅ LLM works with simple prompts")
        print("💡 SOLUTION: Use shorter prompts or add timeouts")
        
        # Create fixed version of stage_1 method
        print("\n🔧 Creating simplified stage_1 method...")
        
        fixed_stage_1 = '''
async def stage_1_llm_analyzes_requirements(self):
    """Stage 1: Simplified LLM requirement analysis with timeout"""
    self.log("🧠 STAGE 1: LLM Requirement Analysis (Simplified)")
    print("=" * 60)
    
    # Simplified prompt
    requirement_analysis_prompt = f"""
Analyze this use case: {self.use_case}

Suggest tools in this JSON format:
{{
  "github_repos": [
    {{"repo": "ccxt/ccxt", "purpose": "crypto APIs", "priority": "high"}}
  ],
  "pypi_packages": [
    {{"package": "tweepy", "purpose": "Twitter API", "priority": "high"}}
  ],
  "reasoning": "Brief explanation"
}}
"""
    
    try:
        # Call LLM with timeout
        llm_analysis = await asyncio.wait_for(
            self.tool_analyst.call_llm(requirement_analysis_prompt),
            timeout=60.0  # 60 second timeout
        )
        self.log("✅ LLM completed requirement analysis")
        
        # Parse response (same as before)
        # ... rest of parsing logic
        
    except asyncio.TimeoutError:
        self.log("⚠️ LLM timed out, using fallback requirements")
        # Use fallback requirements
        fallback_requirements = {
            "github_repos": [
                {"repo": "ccxt/ccxt", "purpose": "Crypto APIs", "priority": "high"}
            ],
            "pypi_packages": [
                {"package": "tweepy", "purpose": "Twitter API", "priority": "high"},
                {"package": "pandas", "purpose": "Data analysis", "priority": "high"}
            ],
            "reasoning": "Fallback selection due to LLM timeout"
        }
        self.results["llm_requirements"] = fallback_requirements
        return fallback_requirements
    
    except Exception as e:
        self.log(f"❌ LLM error: {e}, using fallback")
        # Same fallback as timeout
'''
        
        print("📁 Save this as a replacement for stage_1_llm_analyzes_requirements method")
        
        return True
    else:
        print("\n❌ LLM not working properly")
        return False

# Emergency bypass function
def create_bypass_workflow():
    """Create a version that bypasses LLM calls entirely"""
    
    bypass_code = '''
# Emergency bypass - replace stage_1 method with this:

async def stage_1_llm_analyzes_requirements(self):
    """Stage 1: Hardcoded requirements (LLM bypass)"""
    self.log("🧠 STAGE 1: Using Hardcoded Requirements (LLM Bypass)")
    print("=" * 60)
    
    # Hardcoded requirements for crypto use case
    parsed_requirements = {
        "github_repos": [
            {"repo": "ccxt/ccxt", "purpose": "Cryptocurrency exchange APIs", "priority": "high"},
            {"repo": "twintproject/twint", "purpose": "Twitter scraping without API", "priority": "high"}
        ],
        "pypi_packages": [
            {"package": "tweepy", "purpose": "Twitter API client", "priority": "high"},
            {"package": "pandas", "purpose": "Data analysis and manipulation", "priority": "high"},
            {"package": "requests", "purpose": "HTTP requests for APIs", "priority": "high"}
        ],
        "docker_images": [
            {"image": "redis:alpine", "purpose": "Fast data caching", "priority": "medium"}
        ],
        "reasoning": "Essential tools for cryptocurrency analysis with social media sentiment"
    }
    
    self.results["llm_requirements"] = parsed_requirements
    self.log("✅ Using hardcoded requirements (LLM bypass)")
    
    # Display requirements
    print(f"\\n🎯 Hardcoded Requirements:")
    print(f"\\n📦 GitHub Repos: {len(parsed_requirements.get('github_repos', []))}")
    for repo in parsed_requirements.get('github_repos', []):
        print(f"   🔗 {repo.get('repo')}: {repo.get('purpose')} [{repo.get('priority')}]")
    
    print(f"\\n🐍 PyPI Packages: {len(parsed_requirements.get('pypi_packages', []))}")
    for pkg in parsed_requirements.get('pypi_packages', []):
        print(f"   📦 {pkg.get('package')}: {pkg.get('purpose')} [{pkg.get('priority')}]")
    
    return parsed_requirements
'''
    
    return bypass_code

if __name__ == "__main__":
    print("🚨 EMERGENCY LLM TIMEOUT FIX")
    print("=" * 40)
    
    # Run the diagnostic
    result = asyncio.run(fix_workflow_llm_timeout())
    
    if not result:
        print("\n🆘 EMERGENCY BYPASS:")
        print("Replace stage_1_llm_analyzes_requirements method with:")
        print(create_bypass_workflow())
        
        print("\n⚡ QUICK FIX:")
        print("1. Kill the current process (Ctrl+C)")
        print("2. Edit smart_auto_download_workflow.py")  
        print("3. Replace stage_1 method with bypass version")
        print("4. Re-run the workflow")
    
    print("\n💡 LONG-TERM SOLUTIONS:")
    print("1. Use OpenRouter API instead of local Ollama")
    print("2. Reduce prompt complexity")
    print("3. Add proper timeouts to all LLM calls")
    print("4. Implement fallback responses")