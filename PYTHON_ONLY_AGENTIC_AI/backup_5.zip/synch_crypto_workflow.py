#!/usr/bin/env python3
"""
Simple Cryptocurrency Analysis using Direct Tools
No cognitive workflow dependencies - pure tool usage
"""

from auto_import_tools import *
import json
import time

def analyze_crypto_simple():
    """Simple crypto analysis using available tools directly"""
    
    print("🚀 Starting Simple Cryptocurrency Analysis...")
    
    results = {
        "analysis_type": "cryptocurrency_market_research",
        "timestamp": time.time(),
        "steps": []
    }
    
    # Step 1: Research cryptocurrency trends
    print("\n📊 Step 1: Researching cryptocurrency market trends...")
    try:
        crypto_research = research_combined_search(
            query="cryptocurrency market trends 2024 analysis", 
            num_results=8
        )
        
        if "error" not in crypto_research:
            search_results = crypto_research.get("search_results", [])
            print(f"✅ Found {len(search_results)} research sources")
            
            results["steps"].append({
                "step": "market_research",
                "status": "success", 
                "sources_found": len(search_results),
                "data": crypto_research
            })
            
            # Show some results
            for i, result in enumerate(search_results[:3]):
                print(f"   📰 {i+1}. {result.get('title', 'No title')[:80]}...")
        else:
            print(f"❌ Research failed: {crypto_research['error']}")
            results["steps"].append({
                "step": "market_research",
                "status": "error",
                "error": crypto_research["error"]
            })
            
    except Exception as e:
        print(f"❌ Research error: {e}")
        results["steps"].append({
            "step": "market_research", 
            "status": "error",
            "error": str(e)
        })
    
    # Step 2: Analyze specific cryptocurrencies
    print("\n🪙 Step 2: Analyzing major cryptocurrencies...")
    crypto_symbols = ["Bitcoin", "Ethereum", "Solana", "Cardano"]
    
    for crypto in crypto_symbols:
        try:
            crypto_analysis = research_combined_search(
                query=f"{crypto} price analysis investment 2024",
                num_results=3
            )
            
            if "error" not in crypto_analysis:
                sources = len(crypto_analysis.get("search_results", []))
                print(f"   ✅ {crypto}: {sources} sources analyzed")
                
                results["steps"].append({
                    "step": f"analyze_{crypto.lower()}",
                    "status": "success",
                    "crypto": crypto,
                    "sources": sources,
                    "data": crypto_analysis
                })
            else:
                print(f"   ❌ {crypto}: analysis failed")
                results["steps"].append({
                    "step": f"analyze_{crypto.lower()}",
                    "status": "error", 
                    "crypto": crypto,
                    "error": crypto_analysis["error"]
                })
                
        except Exception as e:
            print(f"   ❌ {crypto}: error - {e}")
            results["steps"].append({
                "step": f"analyze_{crypto.lower()}",
                "status": "error",
                "crypto": crypto, 
                "error": str(e)
            })
    
    # Step 3: Analyze trading strategies
    print("\n📈 Step 3: Researching trading strategies...")
    try:
        strategy_research = research_combined_search(
            query="cryptocurrency trading strategies risk management 2024",
            num_results=5
        )
        
        if "error" not in strategy_research:
            sources = len(strategy_research.get("search_results", []))
            print(f"✅ Trading strategies: {sources} sources found")
            
            results["steps"].append({
                "step": "trading_strategies",
                "status": "success",
                "sources": sources, 
                "data": strategy_research
            })
        else:
            print(f"❌ Strategy research failed: {strategy_research['error']}")
            results["steps"].append({
                "step": "trading_strategies",
                "status": "error",
                "error": strategy_research["error"]
            })
            
    except Exception as e:
        print(f"❌ Strategy research error: {e}")
        results["steps"].append({
            "step": "trading_strategies",
            "status": "error", 
            "error": str(e)
        })
    
    # Step 4: Use ML tools for analysis (if available)
    print("\n🤖 Step 4: ML-based analysis...")
    try:
        # Check if we have data to analyze
        successful_steps = [s for s in results["steps"] if s["status"] == "success"]
        
        if len(successful_steps) >= 2:
            print("✅ Sufficient data collected for ML analysis")
            
            # Try to use ML tools
            try:
                # Get available ML algorithms
                ml_algorithms = ml_get_available_algorithms()
                print(f"   🔧 Available ML algorithms: {len(ml_algorithms.get('algorithms', []))}")
                
                results["steps"].append({
                    "step": "ml_analysis_prep",
                    "status": "success",
                    "available_algorithms": ml_algorithms
                })
                
            except Exception as ml_e:
                print(f"   ⚠️ ML tools not fully available: {ml_e}")
                results["steps"].append({
                    "step": "ml_analysis_prep",
                    "status": "partial",
                    "note": "ML tools available but data preparation needed"
                })
        else:
            print("⚠️ Insufficient data for ML analysis")
            results["steps"].append({
                "step": "ml_analysis_prep",
                "status": "skipped",
                "reason": "insufficient_data"
            })
            
    except Exception as e:
        print(f"❌ ML analysis error: {e}")
        results["steps"].append({
            "step": "ml_analysis_prep",
            "status": "error",
            "error": str(e)
        })
    
    # Step 5: Generate summary analysis
    print("\n📋 Step 5: Generating analysis summary...")
    try:
        # Collect all successful research data
        all_sources = []
        total_sources = 0
        
        for step in results["steps"]:
            if step["status"] == "success" and "data" in step:
                search_results = step["data"].get("search_results", [])
                all_sources.extend(search_results)
                total_sources += len(search_results)
        
        # Generate summary using research tools
        if all_sources:
            combined_content = " ".join([
                result.get("content", result.get("snippet", ""))
                for result in all_sources[:10]  # Limit to first 10 sources
            ])
            
            if combined_content:
                summary_analysis = research_analyze_content(
                    content=combined_content,
                    max_length=2000
                )
                
                if "error" not in summary_analysis:
                    print("✅ Summary analysis generated")
                    results["steps"].append({
                        "step": "summary_analysis",
                        "status": "success",
                        "total_sources_analyzed": total_sources,
                        "analysis": summary_analysis
                    })
                else:
                    print(f"❌ Summary analysis failed: {summary_analysis['error']}")
            else:
                print("⚠️ No content available for summary")
        else:
            print("⚠️ No sources available for summary")
            
    except Exception as e:
        print(f"❌ Summary generation error: {e}")
        results["steps"].append({
            "step": "summary_analysis",
            "status": "error",
            "error": str(e)
        })
    
    # Calculate success metrics
    successful_steps = [s for s in results["steps"] if s["status"] == "success"]
    total_steps = len(results["steps"])
    success_rate = (len(successful_steps) / total_steps * 100) if total_steps > 0 else 0
    
    results["summary"] = {
        "total_steps": total_steps,
        "successful_steps": len(successful_steps),
        "success_rate": success_rate,
        "analysis_completed": success_rate >= 60  # 60% success threshold
    }
    
    return results

def create_simple_recommendations(analysis_results):
    """Create simple investment recommendations based on analysis"""
    
    print("\n💡 Generating Investment Recommendations...")
    
    successful_steps = [s for s in analysis_results["steps"] if s["status"] == "success"]
    
    recommendations = {
        "overall_sentiment": "neutral",
        "risk_level": "medium",
        "recommended_actions": [],
        "risk_factors": [],
        "opportunities": []
    }
    
    # Analyze based on successful research
    if len(successful_steps) >= 3:
        recommendations["overall_sentiment"] = "positive"
        recommendations["recommended_actions"].append("Conduct deeper fundamental analysis")
        recommendations["opportunities"].append("Market research indicates active trading opportunities")
        
        # Check if we analyzed multiple cryptocurrencies
        crypto_analyses = [s for s in successful_steps if "crypto" in s.get("step", "")]
        if len(crypto_analyses) >= 2:
            recommendations["recommended_actions"].append("Diversify across analyzed cryptocurrencies")
            recommendations["opportunities"].append("Multiple cryptocurrencies show research activity")
    
    elif len(successful_steps) >= 1:
        recommendations["overall_sentiment"] = "cautious"
        recommendations["risk_level"] = "high"
        recommendations["recommended_actions"].append("Gather more market data before investing")
        recommendations["risk_factors"].append("Limited research data available")
    
    else:
        recommendations["overall_sentiment"] = "bearish"
        recommendations["risk_level"] = "very high"
        recommendations["recommended_actions"].append("Avoid investment until better data available")
        recommendations["risk_factors"].append("Insufficient research data for informed decision")
    
    # Add general recommendations
    recommendations["recommended_actions"].extend([
        "Monitor market volatility closely",
        "Set clear stop-loss limits",
        "Only invest what you can afford to lose"
    ])
    
    recommendations["risk_factors"].extend([
        "Cryptocurrency markets are highly volatile",
        "Regulatory changes can impact prices significantly",
        "Market sentiment can change rapidly"
    ])
    
    return recommendations

def main():
    """Main execution function"""
    print("🚀 Simple Cryptocurrency Analysis Tool")
    print("=" * 60)
    
    try:
        # Run the analysis
        analysis_results = analyze_crypto_simple()
        
        # Generate recommendations
        recommendations = create_simple_recommendations(analysis_results)
        
        # Combine results
        final_results = {
            "analysis": analysis_results,
            "recommendations": recommendations,
            "generated_at": time.time()
        }
        
        # Display summary
        print(f"\n📊 Analysis Complete!")
        summary = analysis_results["summary"]
        print(f"   ✅ Success Rate: {summary['success_rate']:.1f}%")
        print(f"   📈 Steps Completed: {summary['successful_steps']}/{summary['total_steps']}")
        print(f"   🎯 Analysis Status: {'✅ Complete' if summary['analysis_completed'] else '⚠️ Partial'}")
        
        print(f"\n💡 Investment Recommendations:")
        print(f"   📊 Sentiment: {recommendations['overall_sentiment'].upper()}")
        print(f"   ⚠️ Risk Level: {recommendations['risk_level'].upper()}")
        print(f"   📋 Actions: {len(recommendations['recommended_actions'])} recommendations")
        
        # Save results
        output_file = "simple_crypto_analysis.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(final_results, f, indent=2, default=str)
        
        print(f"\n📁 Complete results saved to: {output_file}")
        
        # Display top recommendations
        print(f"\n🎯 Top Recommendations:")
        for i, action in enumerate(recommendations['recommended_actions'][:3], 1):
            print(f"   {i}. {action}")
        
        return final_results
        
    except Exception as e:
        print(f"\n💥 Fatal error: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    main()