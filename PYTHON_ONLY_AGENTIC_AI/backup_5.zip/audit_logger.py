#!/usr/bin/env python3
"""
Enterprise Audit Logger
SOX and ISO 27001 Compliant Audit Trail System
"""

import os
import json
import sqlite3
import hashlib
import gzip
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path
import threading
from queue import Queue
import time

class AuditLogger:
    """Enterprise-grade audit logging for compliance"""
    
    def __init__(self, audit_db_path: str = "audit_trail.db"):
        self.audit_db_path = audit_db_path
        self.log_queue = Queue()
        self.worker_thread = None
        self.running = False
        
        # Compliance settings
        self.retention_days = int(os.environ.get('AUDIT_RETENTION_DAYS', '2555'))  # 7 years default
        self.encryption_enabled = os.environ.get('AUDIT_ENCRYPTION', 'true').lower() == 'true'
        self.real_time_alerts = os.environ.get('AUDIT_REAL_TIME_ALERTS', 'true').lower() == 'true'
        
        # Initialize database
        self._init_database()
        
        # Start background worker
        self._start_worker()
    
    def _init_database(self):
        """Initialize audit database with compliance schema"""
        with sqlite3.connect(self.audit_db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    user_id TEXT,
                    user_email TEXT,
                    session_id TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    resource TEXT,
                    action TEXT,
                    outcome TEXT NOT NULL,
                    risk_level TEXT DEFAULT 'low',
                    details TEXT,
                    hash_integrity TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.execute('''
                CREATE TABLE IF NOT EXISTS compliance_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    report_type TEXT NOT NULL,
                    period_start TEXT NOT NULL,
                    period_end TEXT NOT NULL,
                    total_events INTEGER,
                    security_events INTEGER,
                    failed_logins INTEGER,
                    privilege_escalations INTEGER,
                    data_access_events INTEGER,
                    report_data TEXT,
                    generated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.execute('''
                CREATE TABLE IF NOT EXISTS alert_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rule_name TEXT NOT NULL,
                    event_pattern TEXT NOT NULL,
                    threshold_count INTEGER DEFAULT 1,
                    time_window_minutes INTEGER DEFAULT 60,
                    severity TEXT DEFAULT 'medium',
                    enabled INTEGER DEFAULT 1,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for performance
            conn.execute('CREATE INDEX IF NOT EXISTS idx_timestamp ON audit_events(timestamp)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_user_id ON audit_events(user_id)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_event_type ON audit_events(event_type)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_outcome ON audit_events(outcome)')
            
            # Insert default alert rules
            self._insert_default_alert_rules(conn)
    
    def _insert_default_alert_rules(self, conn):
        """Insert default compliance alert rules"""
        default_rules = [
            ("Multiple Failed Logins", "failed_login", 5, 15, "high"),
            ("Privilege Escalation", "privilege_escalation", 1, 60, "critical"),
            ("Unusual Data Access", "data_access", 50, 60, "medium"),
            ("Admin Function Access", "admin_function", 10, 60, "medium"),
            ("API Key Misuse", "api_key_failed", 3, 30, "high"),
            ("Bulk Data Export", "data_export", 5, 30, "high"),
            ("Configuration Changes", "config_change", 1, 60, "medium"),
            ("User Creation/Deletion", "user_management", 1, 60, "medium")
        ]
        
        for rule_name, pattern, threshold, window, severity in default_rules:
            conn.execute('''
                INSERT OR IGNORE INTO alert_rules 
                (rule_name, event_pattern, threshold_count, time_window_minutes, severity)
                VALUES (?, ?, ?, ?, ?)
            ''', (rule_name, pattern, threshold, window, severity))
    
    def _start_worker(self):
        """Start background worker for async logging"""
        self.running = True
        self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker_thread.start()
    
    def _worker_loop(self):
        """Background worker to process audit logs"""
        while self.running:
            try:
                if not self.log_queue.empty():
                    event = self.log_queue.get(timeout=1)
                    self._write_audit_event(event)
                    self.log_queue.task_done()
                else:
                    time.sleep(0.1)
            except Exception as e:
                print(f"Audit worker error: {e}")
    
    def log_event(self, event_type: str, user_id: str = None, user_email: str = None,
                  session_id: str = None, ip_address: str = None, user_agent: str = None,
                  resource: str = None, action: str = None, outcome: str = "success",
                  risk_level: str = "low", details: Dict[str, Any] = None):
        """Log audit event (async)"""
        
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "user_id": user_id,
            "user_email": user_email,
            "session_id": session_id,
            "ip_address": ip_address or "unknown",
            "user_agent": user_agent or "unknown",
            "resource": resource,
            "action": action,
            "outcome": outcome,
            "risk_level": risk_level,
            "details": json.dumps(details) if details else None
        }
        
        # Add integrity hash
        event["hash_integrity"] = self._calculate_hash(event)
        
        # Queue for async processing
        self.log_queue.put(event)
        
        # Real-time alert checking (if enabled)
        if self.real_time_alerts:
            self._check_alert_rules(event)
    
    def _write_audit_event(self, event: Dict[str, Any]):
        """Write audit event to database"""
        try:
            with sqlite3.connect(self.audit_db_path) as conn:
                conn.execute('''
                    INSERT INTO audit_events 
                    (timestamp, event_type, user_id, user_email, session_id, 
                     ip_address, user_agent, resource, action, outcome, 
                     risk_level, details, hash_integrity)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    event["timestamp"], event["event_type"], event["user_id"],
                    event["user_email"], event["session_id"], event["ip_address"],
                    event["user_agent"], event["resource"], event["action"],
                    event["outcome"], event["risk_level"], event["details"],
                    event["hash_integrity"]
                ))
        except Exception as e:
            # Fallback to file logging if database fails
            self._fallback_file_log(event, str(e))
    
    def _fallback_file_log(self, event: Dict[str, Any], error: str):
        """Fallback to file logging if database unavailable"""
        fallback_file = f"audit_fallback_{datetime.now().strftime('%Y%m%d')}.log"
        with open(fallback_file, 'a') as f:
            f.write(f"DB_ERROR: {error}\n")
            f.write(f"EVENT: {json.dumps(event)}\n")
    
    def _calculate_hash(self, event: Dict[str, Any]) -> str:
        """Calculate integrity hash for tamper detection"""
        # Remove hash field if present
        event_copy = {k: v for k, v in event.items() if k != "hash_integrity"}
        
        # Create deterministic string
        event_str = json.dumps(event_copy, sort_keys=True)
        
        # Add secret salt for integrity
        salt = os.environ.get('AUDIT_SALT', 'default_salt_change_in_production')
        salted_str = f"{event_str}{salt}"
        
        return hashlib.sha256(salted_str.encode()).hexdigest()
    
    def verify_integrity(self, event_id: int) -> bool:
        """Verify audit event integrity"""
        with sqlite3.connect(self.audit_db_path) as conn:
            cursor = conn.execute('SELECT * FROM audit_events WHERE id = ?', (event_id,))
            row = cursor.fetchone()
            
            if not row:
                return False
            
            # Reconstruct event
            columns = [desc[0] for desc in cursor.description]
            event = dict(zip(columns, row))
            
            stored_hash = event.pop("hash_integrity")
            event.pop("id")  # Remove auto-increment ID
            event.pop("created_at")  # Remove auto timestamp
            
            calculated_hash = self._calculate_hash(event)
            return stored_hash == calculated_hash
    
    def _check_alert_rules(self, event: Dict[str, Any]):
        """Check if event triggers any alert rules"""
        with sqlite3.connect(self.audit_db_path) as conn:
            cursor = conn.execute('SELECT * FROM alert_rules WHERE enabled = 1')
            rules = cursor.fetchall()
            
            for rule in rules:
                rule_id, rule_name, pattern, threshold, window_minutes, severity, enabled, created_at = rule
                
                # Check if event matches pattern
                if pattern in event["event_type"] or (
                    event["outcome"] == "failure" and pattern == "failed_login" and 
                    event["event_type"] in ["login", "authentication"]
                ):
                    # Count recent events matching this pattern
                    window_start = (datetime.utcnow() - timedelta(minutes=window_minutes)).isoformat()
                    
                    count_cursor = conn.execute('''
                        SELECT COUNT(*) FROM audit_events 
                        WHERE event_type LIKE ? AND timestamp >= ?
                    ''', (f"%{pattern}%", window_start))
                    
                    count = count_cursor.fetchone()[0]
                    
                    if count >= threshold:
                        self._trigger_alert(rule_name, event, count, threshold, severity)
    
    def _trigger_alert(self, rule_name: str, event: Dict[str, Any], 
                      count: int, threshold: int, severity: str):
        """Trigger security alert"""
        alert = {
            "timestamp": datetime.utcnow().isoformat(),
            "rule_name": rule_name,
            "severity": severity,
            "event_count": count,
            "threshold": threshold,
            "triggering_event": event,
            "message": f"Alert: {rule_name} - {count} events exceeded threshold of {threshold}"
        }
        
        # Log the alert itself
        self.log_event(
            event_type="security_alert",
            user_id=event.get("user_id"),
            resource="security_monitoring",
            action="alert_triggered",
            outcome="success",
            risk_level=severity,
            details=alert
        )
        
        # Send to monitoring system (implement based on your needs)
        self._send_alert_notification(alert)
    
    def _send_alert_notification(self, alert: Dict[str, Any]):
        """Send alert notification (email, Slack, etc.)"""
        # Implement notification logic here
        print(f"🚨 SECURITY ALERT: {alert['message']}")
        
        # Example: Send to webhook
        webhook_url = os.environ.get('SECURITY_WEBHOOK_URL')
        if webhook_url:
            try:
                import requests
                requests.post(webhook_url, json=alert, timeout=5)
            except Exception as e:
                print(f"Failed to send alert notification: {e}")
    
    def search_events(self, start_date: str = None, end_date: str = None,
                     user_id: str = None, event_type: str = None,
                     outcome: str = None, risk_level: str = None,
                     limit: int = 1000) -> List[Dict[str, Any]]:
        """Search audit events with filters"""
        
        query = "SELECT * FROM audit_events WHERE 1=1"
        params = []
        
        if start_date:
            query += " AND timestamp >= ?"
            params.append(start_date)
        
        if end_date:
            query += " AND timestamp <= ?"
            params.append(end_date)
        
        if user_id:
            query += " AND user_id = ?"
            params.append(user_id)
        
        if event_type:
            query += " AND event_type LIKE ?"
            params.append(f"%{event_type}%")
        
        if outcome:
            query += " AND outcome = ?"
            params.append(outcome)
        
        if risk_level:
            query += " AND risk_level = ?"
            params.append(risk_level)
        
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        with sqlite3.connect(self.audit_db_path) as conn:
            cursor = conn.execute(query, params)
            columns = [desc[0] for desc in cursor.description]
            
            events = []
            for row in cursor.fetchall():
                event = dict(zip(columns, row))
                if event["details"]:
                    try:
                        event["details"] = json.loads(event["details"])
                    except:
                        pass
                events.append(event)
            
            return events
    
    def generate_compliance_report(self, report_type: str = "sox", 
                                 start_date: str = None, 
                                 end_date: str = None) -> Dict[str, Any]:
        """Generate compliance report (SOX, ISO 27001, etc.)"""
        
        if not start_date:
            start_date = (datetime.utcnow() - timedelta(days=30)).isoformat()
        if not end_date:
            end_date = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.audit_db_path) as conn:
            # Total events
            total_events = conn.execute('''
                SELECT COUNT(*) FROM audit_events 
                WHERE timestamp BETWEEN ? AND ?
            ''', (start_date, end_date)).fetchone()[0]
            
            # Security events
            security_events = conn.execute('''
                SELECT COUNT(*) FROM audit_events 
                WHERE timestamp BETWEEN ? AND ? 
                AND (risk_level IN ('high', 'critical') OR event_type LIKE '%security%')
            ''', (start_date, end_date)).fetchone()[0]
            
            # Failed logins
            failed_logins = conn.execute('''
                SELECT COUNT(*) FROM audit_events 
                WHERE timestamp BETWEEN ? AND ? 
                AND event_type LIKE '%login%' AND outcome = 'failure'
            ''', (start_date, end_date)).fetchone()[0]
            
            # Privilege escalations
            privilege_escalations = conn.execute('''
                SELECT COUNT(*) FROM audit_events 
                WHERE timestamp BETWEEN ? AND ? 
                AND event_type LIKE '%privilege%'
            ''', (start_date, end_date)).fetchone()[0]
            
            # Data access events
            data_access_events = conn.execute('''
                SELECT COUNT(*) FROM audit_events 
                WHERE timestamp BETWEEN ? AND ? 
                AND (resource LIKE '%data%' OR action LIKE '%export%' OR action LIKE '%download%')
            ''', (start_date, end_date)).fetchone()[0]
            
            # Top users by activity
            top_users = conn.execute('''
                SELECT user_email, COUNT(*) as event_count 
                FROM audit_events 
                WHERE timestamp BETWEEN ? AND ? AND user_email IS NOT NULL
                GROUP BY user_email 
                ORDER BY event_count DESC 
                LIMIT 10
            ''', (start_date, end_date)).fetchall()
            
            # Risk distribution
            risk_distribution = conn.execute('''
                SELECT risk_level, COUNT(*) as count 
                FROM audit_events 
                WHERE timestamp BETWEEN ? AND ?
                GROUP BY risk_level
            ''', (start_date, end_date)).fetchall()
            
            # Event timeline
            daily_events = conn.execute('''
                SELECT DATE(timestamp) as date, COUNT(*) as count
                FROM audit_events 
                WHERE timestamp BETWEEN ? AND ?
                GROUP BY DATE(timestamp)
                ORDER BY date
            ''', (start_date, end_date)).fetchall()
        
        report_data = {
            "report_metadata": {
                "report_type": report_type,
                "period_start": start_date,
                "period_end": end_date,
                "generated_at": datetime.utcnow().isoformat(),
                "compliance_standards": ["SOX", "ISO 27001", "GDPR"] if report_type == "comprehensive" else [report_type.upper()]
            },
            "summary": {
                "total_events": total_events,
                "security_events": security_events,
                "failed_logins": failed_logins,
                "privilege_escalations": privilege_escalations,
                "data_access_events": data_access_events,
                "security_incidents": security_events + failed_logins + privilege_escalations
            },
            "user_activity": {
                "top_users": [{"email": email, "event_count": count} for email, count in top_users],
                "unique_users": len(top_users)
            },
            "risk_analysis": {
                "risk_distribution": [{"level": level, "count": count} for level, count in risk_distribution],
                "high_risk_percentage": round((sum(count for level, count in risk_distribution if level in ['high', 'critical']) / total_events * 100), 2) if total_events > 0 else 0
            },
            "timeline": {
                "daily_events": [{"date": date, "count": count} for date, count in daily_events]
            },
            "compliance_status": self._assess_compliance_status(total_events, security_events, failed_logins)
        }
        
        # Store report in database
        with sqlite3.connect(self.audit_db_path) as conn:
            conn.execute('''
                INSERT INTO compliance_reports 
                (report_type, period_start, period_end, total_events, 
                 security_events, failed_logins, privilege_escalations, 
                 data_access_events, report_data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                report_type, start_date, end_date, total_events,
                security_events, failed_logins, privilege_escalations,
                data_access_events, json.dumps(report_data)
            ))
        
        return report_data
    
    def _assess_compliance_status(self, total_events: int, security_events: int, 
                                 failed_logins: int) -> Dict[str, Any]:
        """Assess compliance status based on metrics"""
        status = "compliant"
        issues = []
        recommendations = []
        
        # Check security event ratio
        if total_events > 0:
            security_ratio = (security_events / total_events) * 100
            if security_ratio > 10:
                status = "attention_required"
                issues.append(f"High security event ratio: {security_ratio:.1f}%")
                recommendations.append("Review security policies and user training")
        
        # Check failed login attempts
        if failed_logins > 50:
            status = "attention_required"
            issues.append(f"High number of failed logins: {failed_logins}")
            recommendations.append("Implement stronger authentication controls")
        
        # Check for critical gaps
        if total_events == 0:
            status = "non_compliant"
            issues.append("No audit events found - audit logging may be disabled")
            recommendations.append("Verify audit logging is properly configured")
        
        return {
            "status": status,
            "issues": issues,
            "recommendations": recommendations,
            "last_assessment": datetime.utcnow().isoformat()
        }
    
    def export_audit_data(self, start_date: str, end_date: str, 
                         format: str = "json") -> str:
        """Export audit data for external compliance systems"""
        
        events = self.search_events(start_date=start_date, end_date=end_date, limit=10000)
        
        export_data = {
            "export_metadata": {
                "start_date": start_date,
                "end_date": end_date,
                "total_events": len(events),
                "exported_at": datetime.utcnow().isoformat(),
                "format": format
            },
            "events": events
        }
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if format.lower() == "json":
            filename = f"audit_export_{timestamp}.json"
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
        
        elif format.lower() == "csv":
            filename = f"audit_export_{timestamp}.csv"
            import csv
            with open(filename, 'w', newline='') as f:
                if events:
                    writer = csv.DictWriter(f, fieldnames=events[0].keys())
                    writer.writeheader()
                    writer.writerows(events)
        
        # Compress if large
        if os.path.getsize(filename) > 10 * 1024 * 1024:  # > 10MB
            with open(filename, 'rb') as f_in:
                with gzip.open(f"{filename}.gz", 'wb') as f_out:
                    f_out.writelines(f_in)
            os.remove(filename)
            filename = f"{filename}.gz"
        
        # Log the export
        self.log_event(
            event_type="audit_export",
            resource="audit_data",
            action="export",
            outcome="success",
            risk_level="medium",
            details={
                "filename": filename,
                "format": format,
                "event_count": len(events),
                "date_range": {"start": start_date, "end": end_date}
            }
        )
        
        return filename
    
    def cleanup_old_records(self):
        """Clean up old audit records based on retention policy"""
        cutoff_date = (datetime.utcnow() - timedelta(days=self.retention_days)).isoformat()
        
        with sqlite3.connect(self.audit_db_path) as conn:
            # Archive old records before deletion (optional)
            archive_file = f"audit_archive_{datetime.now().strftime('%Y%m%d')}.json"
            
            cursor = conn.execute('SELECT * FROM audit_events WHERE timestamp < ?', (cutoff_date,))
            old_records = cursor.fetchall()
            
            if old_records:
                columns = [desc[0] for desc in cursor.description]
                archive_data = [dict(zip(columns, row)) for row in old_records]
                
                with open(archive_file, 'w') as f:
                    json.dump(archive_data, f, default=str)
                
                # Delete old records
                result = conn.execute('DELETE FROM audit_events WHERE timestamp < ?', (cutoff_date,))
                deleted_count = result.rowcount
                
                self.log_event(
                    event_type="audit_cleanup",
                    resource="audit_database",
                    action="cleanup",
                    outcome="success",
                    details={
                        "deleted_records": deleted_count,
                        "cutoff_date": cutoff_date,
                        "archive_file": archive_file
                    }
                )
                
                return {
                    "deleted_records": deleted_count,
                    "archive_file": archive_file,
                    "cutoff_date": cutoff_date
                }
        
        return {"deleted_records": 0, "message": "No old records to clean up"}
    
    def get_user_activity_summary(self, user_id: str, days: int = 30) -> Dict[str, Any]:
        """Get detailed user activity summary"""
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        events = self.search_events(
            start_date=start_date,
            user_id=user_id,
            limit=1000
        )
        
        if not events:
            return {"user_id": user_id, "activity": "no_activity", "events": []}
        
        # Analyze activity patterns
        event_types = {}
        risk_levels = {}
        daily_activity = {}
        
        for event in events:
            # Count by event type
            event_type = event["event_type"]
            event_types[event_type] = event_types.get(event_type, 0) + 1
            
            # Count by risk level
            risk_level = event["risk_level"]
            risk_levels[risk_level] = risk_levels.get(risk_level, 0) + 1
            
            # Count by day
            day = event["timestamp"][:10]  # YYYY-MM-DD
            daily_activity[day] = daily_activity.get(day, 0) + 1
        
        return {
            "user_id": user_id,
            "period_days": days,
            "total_events": len(events),
            "event_types": event_types,
            "risk_levels": risk_levels,
            "daily_activity": daily_activity,
            "most_active_day": max(daily_activity.items(), key=lambda x: x[1]) if daily_activity else None,
            "security_events": len([e for e in events if e["risk_level"] in ["high", "critical"]]),
            "failed_actions": len([e for e in events if e["outcome"] == "failure"])
        }
    
    def shutdown(self):
        """Gracefully shutdown audit logger"""
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        
        # Process any remaining items in queue
        while not self.log_queue.empty():
            try:
                event = self.log_queue.get_nowait()
                self._write_audit_event(event)
            except:
                break

# Global audit logger instance
audit_logger = AuditLogger()
