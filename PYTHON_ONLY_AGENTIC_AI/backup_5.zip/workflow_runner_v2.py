#!/usr/bin/env python3
import json
import sys
import argparse
from pathlib import Path
from tool_manager import tool_manager
#Allows data inputs 
class WorkflowRunner:
    def __init__(self, data_files=None):
        self.state = {}
        self.results = {}
        self.data_files = data_files or []
        
    def run(self, workflow_file):
        with open(workflow_file) as f:
            workflow = json.load(f)
        
        # Add data files to state
        for i, data_file in enumerate(self.data_files):
            self.state[f"data_file_{i+1}"] = data_file
        
        for step in workflow:
            if step.get("type") == "state":
                self._handle_state(step)
            else:
                self._execute_step(step)
        
        return self.results
    
    def _handle_state(self, step):
        if step["operation"] == "set_variable":
            self.state[step["variable_name"]] = step["value"]
    
    def _execute_step(self, step):
        agent_id = step["agent"]
        
        # Get data from previous agents
        input_data = {}
        for source in step.get("readFrom", []):
            if source in self.results:
                input_data[source] = self.results[source]
        
        # Execute tools
        tool_results = {}
        for tool_spec in step.get("tools", []):
            if isinstance(tool_spec, str):
                tool_id = tool_spec
                params = step.get("parameters", {})
            else:
                tool_id = tool_spec["tool"]
                params = tool_spec.get("parameters", {})
            
            # Replace template variables
            params = self._replace_templates(params)
            
            result = tool_manager.execute_tool(tool_id, **params)
            tool_results[tool_id] = result
        
        self.results[agent_id] = {
            "input_data": input_data,
            "tool_results": tool_results,
            "metadata": {
                "content": step.get("content"),
                "output_format": step.get("output_format")
            }
        }
    
    def _replace_templates(self, obj):
        if isinstance(obj, str):
            for var, val in self.state.items():
                obj = obj.replace(f"{{{{{var}}}}}", str(val))
            return obj
        elif isinstance(obj, dict):
            return {k: self._replace_templates(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._replace_templates(item) for item in obj]
        return obj

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow", required=True, help="JSON workflow file")
    parser.add_argument("--data", nargs="*", default=[], help="Up to 3 CSV data files")
    
    args = parser.parse_args()
    
    if len(args.data) > 3:
        print("Error: Maximum 3 data files allowed")
        sys.exit(1)
    
    runner = WorkflowRunner(args.data)
    results = runner.run(args.workflow)
    
    output_file = Path(args.workflow).stem + "_results.json"
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"Results saved to {output_file}")

if __name__ == "__main__":
    main()