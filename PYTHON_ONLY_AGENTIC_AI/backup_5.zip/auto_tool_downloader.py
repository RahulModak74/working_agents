#!/usr/bin/env python3
"""
Auto Tool Downloader & Registry
Downloads and auto-registers tools from GitHub, Docker, PyPI based on LLM requirements
"""

import os
import sys
import json
import requests
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Dict, Any, List
import logging

from tool_manager import tool_manager
from config import CONFIG
from git_tool_handler import GitToolHandler

logger = logging.getLogger("auto_tool_downloader")

class AutoToolDownloader:
    """Automatically download and register tools based on requirements"""
    
    def __init__(self):
        self.component_dir = Path(__file__).parent / "COMPONENT"
        self.component_dir.mkdir(exist_ok=True)
        
        # Initialize Git handler for GitHub downloads
        self.git_handler = GitToolHandler(self.component_dir)
        
        self.tool_sources = {
            "github": "https://api.github.com",
            "pypi": "https://pypi.org/pypi",
            "docker": "https://hub.docker.com/v2"
        }
        self.downloaded_tools = {}
    
    async def auto_download_for_requirement(self, requirement: str) -> Dict[str, Any]:
        """LLM analyzes requirement and auto-downloads needed tools"""
        
        # Use LLM to analyze what tools are needed
        from llm_powered_solution import LLMAgent
        
        analyzer = LLMAgent("ToolAnalyzer", 
            "You are a tool requirement analyzer. Given a user requirement, "
            "identify what specific tools/libraries would be needed and suggest "
            "GitHub repositories, PyPI packages, or Docker images to download.")
        
        analysis_prompt = f"""
Requirement: {requirement}

Analyze what tools would be needed and suggest specific sources:

1. GitHub repositories (for custom tools/adapters)
2. PyPI packages (for Python libraries) 
3. Docker containers (for complex services)

Format response as JSON:
{{
  "github_repos": ["user/repo", "user2/repo2"],
  "pypi_packages": ["package1", "package2"], 
  "docker_images": ["image1", "image2"],
  "reasoning": "why these tools are needed"
}}
"""
        
        analysis = await analyzer.call_llm(analysis_prompt)
        
        # Parse LLM response
        try:
            import re
            json_match = re.search(r'\{.*\}', analysis, re.DOTALL)
            if json_match:
                suggestions = json.loads(json_match.group())
            else:
                suggestions = {"github_repos": [], "pypi_packages": [], "docker_images": []}
        except:
            suggestions = {"github_repos": [], "pypi_packages": [], "docker_images": []}
        
        # Download suggested tools
        download_results = {}
        
        # Download GitHub repos
        for repo in suggestions.get("github_repos", []):
            result = await self.download_github_tool(repo)
            download_results[f"github_{repo}"] = result
        
        # Install PyPI packages
        for package in suggestions.get("pypi_packages", []):
            result = await self.install_pypi_tool(package)
            download_results[f"pypi_{package}"] = result
        
        # Pull Docker images
        for image in suggestions.get("docker_images", []):
            result = await self.setup_docker_tool(image)
            download_results[f"docker_{image}"] = result
        
        # Re-discover tools after downloads
        new_tool_count = tool_manager.discover_tools()
        
        return {
            "requirement": requirement,
            "llm_analysis": analysis,
            "suggestions": suggestions,
            "download_results": download_results,
            "new_tool_count": new_tool_count,
            "available_tools": tool_manager.get_all_tools()
        }
    
    async def download_github_tool(self, repo: str) -> Dict[str, Any]:
        """Download and integrate a GitHub repository as tools"""
        
        try:
            logger.info(f"Starting download of GitHub repo: {repo}")
            
            # Use the new GitToolHandler for robust downloading
            result = self.git_handler.download_github_repo(repo)
            
            if result.get("status") == "success":
                logger.info(f"Successfully downloaded {repo} - {result.get('files_copied_count', 0)} files copied")
                
                return {
                    "status": "success",
                    "repo": repo,
                    "files_copied": [f["destination"] for f in result.get("copied_files", [])],
                    "total_python_files": result.get("total_python_files", 0),
                    "method": result.get("method", "unknown"),
                    "files_copied_count": result.get("files_copied_count", 0),
                    "details": result.get("copied_files", [])
                }
            else:
                error_msg = result.get("error", f"Could not download {repo}")
                logger.error(f"Failed to download {repo}: {error_msg}")
                return {"error": error_msg}
                
        except Exception as e:
            error_msg = f"Exception during download of {repo}: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
    
    def get_github_repo_info(self, repo: str) -> Dict[str, Any]:
        """Get information about a GitHub repository before downloading"""
        return self.git_handler.get_repo_info(repo)
    
    async def install_pypi_tool(self, package: str) -> Dict[str, Any]:
        """Install PyPI package and create adapter"""
        
        try:
            logger.info(f"Installing PyPI package: {package}")
            
            # Install package
            result = subprocess.run([
                sys.executable, "-m", "pip", "install", package, "--user"
            ], capture_output=True, text=True, timeout=300)
            
            if result.returncode != 0:
                error_msg = f"Failed to install {package}: {result.stderr}"
                logger.error(error_msg)
                return {"error": error_msg}
            
            # Create comprehensive adapter file
            adapter_content = self._generate_pypi_adapter(package)
            
            adapter_path = self.component_dir / f"{package}_adapter.py"
            with open(adapter_path, 'w', encoding='utf-8') as f:
                f.write(adapter_content)
            
            logger.info(f"Successfully installed {package} and created adapter")
            
            return {
                "status": "success",
                "package": package,
                "adapter_created": str(adapter_path),
                "installation_output": result.stdout
            }
            
        except subprocess.TimeoutExpired:
            return {"error": f"Installation of {package} timed out"}
        except Exception as e:
            error_msg = f"Failed to install {package}: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
    
    def _generate_pypi_adapter(self, package: str) -> str:
        """Generate a comprehensive adapter for a PyPI package"""
        
        # Clean package name for Python identifiers
        clean_name = package.replace("-", "_").replace(".", "_")
        
        adapter_content = f'''#!/usr/bin/env python3
"""
Auto-generated adapter for {package}
Generated by AutoToolDownloader
"""

TOOL_NAMESPACE = "{clean_name}"

# Import handling with fallback
try:
    import {package.replace("-", "_")}
    PACKAGE_AVAILABLE = True
    PACKAGE_MODULE = {package.replace("-", "_")}
except ImportError:
    try:
        import {package}
        PACKAGE_AVAILABLE = True
        PACKAGE_MODULE = {package}
    except ImportError:
        PACKAGE_AVAILABLE = False
        PACKAGE_MODULE = None

TOOL_REGISTRY = {{}}

if PACKAGE_AVAILABLE:
    def {clean_name}_info(**kwargs):
        """Get information about {package}"""
        try:
            version = "unknown"
            if hasattr(PACKAGE_MODULE, "__version__"):
                version = PACKAGE_MODULE.__version__
            elif hasattr(PACKAGE_MODULE, "version"):
                version = PACKAGE_MODULE.version
            elif hasattr(PACKAGE_MODULE, "VERSION"):
                version = PACKAGE_MODULE.VERSION
            
            return {{
                "package": "{package}",
                "version": version,
                "available": True,
                "module": str(PACKAGE_MODULE),
                "module_file": getattr(PACKAGE_MODULE, "__file__", "unknown")
            }}
        except Exception as e:
            return {{"error": str(e), "package": "{package}"}}
    
    def {clean_name}_help(**kwargs):
        """Get help information for {package}"""
        try:
            if hasattr(PACKAGE_MODULE, "__doc__") and PACKAGE_MODULE.__doc__:
                return {{
                    "package": "{package}",
                    "documentation": PACKAGE_MODULE.__doc__[:500],
                    "help_available": True
                }}
            else:
                return {{
                    "package": "{package}",
                    "documentation": "No documentation available",
                    "help_available": False
                }}
        except Exception as e:
            return {{"error": str(e), "package": "{package}"}}
    
    def {clean_name}_list_functions(**kwargs):
        """List available functions in {package}"""
        try:
            import inspect
            functions = []
            for name, obj in inspect.getmembers(PACKAGE_MODULE):
                if (not name.startswith('_') and 
                    callable(obj) and 
                    hasattr(obj, '__doc__')):
                    functions.append({{
                        "name": name,
                        "doc": (obj.__doc__ or "")[:100],
                        "callable": True
                    }})
            
            return {{
                "package": "{package}",
                "functions": functions[:20],  # Limit to first 20
                "total_functions": len(functions)
            }}
        except Exception as e:
            return {{"error": str(e), "package": "{package}"}}
    
    # Register basic tools
    TOOL_REGISTRY["{clean_name}_info"] = {clean_name}_info
    TOOL_REGISTRY["{clean_name}_help"] = {clean_name}_help
    TOOL_REGISTRY["{clean_name}_list_functions"] = {clean_name}_list_functions

# Auto-discover and register callable functions (with safety limits)
if PACKAGE_AVAILABLE:
    import inspect
    try:
        discovered_count = 0
        for name, obj in inspect.getmembers(PACKAGE_MODULE):
            if (not name.startswith('_') and 
                callable(obj) and 
                hasattr(obj, '__doc__') and 
                obj.__doc__ and
                discovered_count < 100):  # Safety limit
                
                # Create a safe wrapper function
                def create_wrapper(func_name, func_obj):
                    def wrapper(**kwargs):
                        try:
                            # Basic parameter handling
                            import inspect
                            sig = inspect.signature(func_obj)
                            filtered_kwargs = {{k: v for k, v in kwargs.items() 
                                             if k in sig.parameters}}
                            
                            result = func_obj(**filtered_kwargs)
                            return {{
                                "function": func_name,
                                "result": result,
                                "success": True
                            }}
                        except Exception as e:
                            return {{
                                "function": func_name,
                                "error": str(e),
                                "success": False
                            }}
                    return wrapper
                
                TOOL_REGISTRY[f"{clean_name}_{{name}}"] = create_wrapper(name, obj)
                discovered_count += 1
    except Exception as e:
        # If auto-discovery fails, just continue with basic tools
        pass

# Fallback tools when package is not available
else:
    def {clean_name}_not_available(**kwargs):
        """Indicates that {package} is not available"""
        return {{
            "package": "{package}",
            "available": False,
            "error": "Package not installed or import failed"
        }}
    
    TOOL_REGISTRY["{clean_name}_info"] = {clean_name}_not_available
'''
        
        return adapter_content
    
    async def setup_docker_tool(self, image: str) -> Dict[str, Any]:
        """Setup Docker image as a tool service"""
        
        try:
            logger.info(f"Setting up Docker image: {image}")
            
            # Check if Docker is available
            docker_check = subprocess.run([
                "docker", "--version"
            ], capture_output=True, text=True)
            
            if docker_check.returncode != 0:
                return {"error": "Docker is not available on this system"}
            
            # Pull Docker image
            result = subprocess.run([
                "docker", "pull", image
            ], capture_output=True, text=True, timeout=300)
            
            if result.returncode != 0:
                error_msg = f"Failed to pull {image}: {result.stderr}"
                logger.error(error_msg)
                return {"error": error_msg}
            
            # Create Docker adapter
            adapter_content = self._generate_docker_adapter(image)
            
            adapter_name = f"docker_{image.replace('/', '_').replace(':', '_')}_adapter.py"
            adapter_path = self.component_dir / adapter_name
            
            with open(adapter_path, 'w', encoding='utf-8') as f:
                f.write(adapter_content)
            
            logger.info(f"Successfully set up Docker image {image}")
            
            return {
                "status": "success",
                "image": image,
                "adapter_created": str(adapter_path),
                "pull_output": result.stdout
            }
            
        except subprocess.TimeoutExpired:
            return {"error": f"Docker pull of {image} timed out"}
        except Exception as e:
            error_msg = f"Failed to setup Docker tool {image}: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
    
    def _generate_docker_adapter(self, image: str) -> str:
        """Generate a comprehensive adapter for a Docker image"""
        
        clean_name = image.replace('/', '_').replace(':', '_').replace('-', '_')
        
        adapter_content = f'''#!/usr/bin/env python3
"""
Auto-generated Docker adapter for {image}
Generated by AutoToolDownloader
"""

TOOL_NAMESPACE = "docker_{clean_name}"

import subprocess
import json
import tempfile
import os

def docker_run_{clean_name}(command="", volume_mounts=None, environment=None, **kwargs):
    """Run command in {image} container"""
    try:
        cmd = ["docker", "run", "--rm"]
        
        # Add volume mounts if provided
        if volume_mounts:
            for mount in volume_mounts:
                cmd.extend(["-v", mount])
        
        # Add environment variables if provided
        if environment:
            for key, value in environment.items():
                cmd.extend(["-e", f"{{key}}={{value}}"])
        
        # Add the image
        cmd.append("{image}")
        
        # Add command if provided
        if command:
            if isinstance(command, str):
                cmd.extend(command.split())
            elif isinstance(command, list):
                cmd.extend(command)
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        return {{
            "status": "success" if result.returncode == 0 else "error",
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
            "command": " ".join(cmd)
        }}
    except subprocess.TimeoutExpired:
        return {{"error": "Command timed out", "image": "{image}"}}
    except Exception as e:
        return {{"error": str(e), "image": "{image}"}}

def docker_status_{clean_name}(**kwargs):
    """Check if {image} is available"""
    try:
        result = subprocess.run([
            "docker", "images", "{image}", "--format", "json"
        ], capture_output=True, text=True)
        
        available = result.returncode == 0 and result.stdout.strip()
        
        image_info = {{}}
        if available and result.stdout.strip():
            try:
                image_info = json.loads(result.stdout.strip())
            except:
                pass
        
        return {{
            "available": available,
            "image": "{image}",
            "info": image_info
        }}
    except Exception as e:
        return {{"error": str(e), "image": "{image}"}}

def docker_inspect_{clean_name}(**kwargs):
    """Inspect {image} container configuration"""
    try:
        result = subprocess.run([
            "docker", "inspect", "{image}"
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            try:
                inspect_data = json.loads(result.stdout)
                return {{
                    "success": True,
                    "image": "{image}",
                    "inspection": inspect_data[0] if inspect_data else {{}}
                }}
            except json.JSONDecodeError:
                return {{"error": "Failed to parse inspect output", "image": "{image}"}}
        else:
            return {{"error": result.stderr, "image": "{image}"}}
            
    except Exception as e:
        return {{"error": str(e), "image": "{image}"}}

def docker_exec_{clean_name}(command, working_dir=None, **kwargs):
    """Execute command in a temporary {image} container"""
    try:
        cmd = ["docker", "run", "--rm", "-i"]
        
        if working_dir:
            cmd.extend(["-w", working_dir])
        
        cmd.extend(["{image}", "sh", "-c", command])
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        return {{
            "status": "success" if result.returncode == 0 else "error",
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
            "command": command
        }}
    except Exception as e:
        return {{"error": str(e), "image": "{image}"}}

TOOL_REGISTRY = {{
    "run": docker_run_{clean_name},
    "status": docker_status_{clean_name},
    "inspect": docker_inspect_{clean_name},
    "exec": docker_exec_{clean_name}
}}
'''
        
        return adapter_content
    
    async def search_and_download_tools(self, search_query: str) -> Dict[str, Any]:
        """Search GitHub/PyPI and download relevant tools"""
        
        # Search GitHub
        github_results = await self._search_github(search_query)
        
        # Search PyPI  
        pypi_results = await self._search_pypi(search_query)
        
        # Let LLM decide what to download
        from llm_powered_solution import LLMAgent
        
        selector = LLMAgent("ToolSelector",
            "You select the best tools to download based on search results. "
            "Choose 2-3 most relevant and high-quality options.")
        
        selection_prompt = f"""
Search query: {search_query}

GitHub results: {json.dumps(github_results[:5], indent=2)}
PyPI results: {json.dumps(pypi_results[:5], indent=2)}

Select the 2-3 best tools to download. Format as JSON:
{{
  "selected_github": ["user/repo1", "user/repo2"],
  "selected_pypi": ["package1", "package2"],
  "reasoning": "why these are the best choices"
}}
"""
        
        selection = await selector.call_llm(selection_prompt)
        
        # Parse and download selected tools
        try:
            import re
            json_match = re.search(r'\{.*\}', selection, re.DOTALL)
            if json_match:
                selected = json.loads(json_match.group())
            else:
                selected = {"selected_github": [], "selected_pypi": []}
        except:
            selected = {"selected_github": [], "selected_pypi": []}
        
        # Download selected tools
        download_results = {}
        
        for repo in selected.get("selected_github", []):
            result = await self.download_github_tool(repo)
            download_results[f"github_{repo}"] = result
        
        for package in selected.get("selected_pypi", []):
            result = await self.install_pypi_tool(package)
            download_results[f"pypi_{package}"] = result
        
        return {
            "search_query": search_query,
            "github_results": github_results,
            "pypi_results": pypi_results,
            "llm_selection": selection,
            "download_results": download_results
        }
    
    async def _search_github(self, query: str) -> List[Dict]:
        """Search GitHub repositories"""
        try:
            url = f"https://api.github.com/search/repositories"
            params = {
                "q": f"{query} language:python",
                "sort": "stars",
                "order": "desc",
                "per_page": 10
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return [{
                    "name": item["full_name"],
                    "description": item.get("description", ""),
                    "stars": item["stargazers_count"],
                    "url": item["html_url"],
                    "language": item.get("language", ""),
                    "updated_at": item.get("updated_at", "")
                } for item in data.get("items", [])]
        except Exception as e:
            logger.error(f"GitHub search failed: {e}")
        
        return []
    
    async def _search_pypi(self, query: str) -> List[Dict]:
        """Search PyPI packages"""
        try:
            # Use PyPI's JSON API for search
            url = f"https://pypi.org/search/"
            params = {"q": query}
            
            # For now, return some reasonable suggestions based on common patterns
            # In a real implementation, you'd parse PyPI search results
            suggestions = [
                {"name": f"{query}", "description": f"Main {query} package"},
                {"name": f"python-{query}", "description": f"Python {query} library"},
                {"name": f"{query}-py", "description": f"Python {query} implementation"},
                {"name": f"{query}kit", "description": f"{query} toolkit"},
                {"name": f"py{query}", "description": f"Python {query} bindings"}
            ]
            
            return suggestions[:5]
        except Exception as e:
            logger.error(f"PyPI search failed: {e}")
        
        return []

# Global instance
auto_downloader = AutoToolDownloader()

# Tool registry functions
def auto_download_for_requirement(requirement: str, **kwargs) -> Dict[str, Any]:
    """Auto-download tools based on requirement"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Create new event loop for nested call
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, auto_downloader.auto_download_for_requirement(requirement))
                return future.result()
        else:
            return asyncio.run(auto_downloader.auto_download_for_requirement(requirement))
    except RuntimeError:
        return asyncio.run(auto_downloader.auto_download_for_requirement(requirement))

def search_and_download_tools(search_query: str, **kwargs) -> Dict[str, Any]:
    """Search and download tools"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, auto_downloader.search_and_download_tools(search_query))
                return future.result()
        else:
            return asyncio.run(auto_downloader.search_and_download_tools(search_query))
    except RuntimeError:
        return asyncio.run(auto_downloader.search_and_download_tools(search_query))

def download_github_tool(repo: str, **kwargs) -> Dict[str, Any]:
    """Download specific GitHub repo as tool"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, auto_downloader.download_github_tool(repo))
                return future.result()
        else:
            return asyncio.run(auto_downloader.download_github_tool(repo))
    except RuntimeError:
        return asyncio.run(auto_downloader.download_github_tool(repo))

def install_pypi_tool(package: str, **kwargs) -> Dict[str, Any]:
    """Install PyPI package as tool"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, auto_downloader.install_pypi_tool(package))
                return future.result()
        else:
            return asyncio.run(auto_downloader.install_pypi_tool(package))
    except RuntimeError:
        return asyncio.run(auto_downloader.install_pypi_tool(package))

def get_github_repo_info(repo: str, **kwargs) -> Dict[str, Any]:
    """Get information about a GitHub repository"""
    return auto_downloader.get_github_repo_info(repo)

# Register auto-download tools
TOOL_REGISTRY = {
    "auto_download": auto_download_for_requirement,
    "search_download": search_and_download_tools,
    "github_download": download_github_tool,
    "pypi_install": install_pypi_tool,
    "github_info": get_github_repo_info
}

TOOL_NAMESPACE = "autotools"