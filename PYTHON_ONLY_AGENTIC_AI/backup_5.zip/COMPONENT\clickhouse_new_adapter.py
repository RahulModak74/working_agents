#!/usr/bin/env python3

import os
import subprocess
import json
import tempfile
import logging
from typing import Dict, Any, List, Optional
import time

logger = logging.getLogger("clickhouse_ssh_tools")

# Set tool namespace for discovery
TOOL_NAMESPACE = "clickhouse_ssh"

class ClickHouseSSHManager:
    """ClickHouse SSH connection and query management using built-in SSH"""
    
    def __init__(self):
        self.connected = False
        self.connection_info = {}
        
    def _execute_ssh_command(self, host: str, username: str, key_path: str, 
                           command: str, port: int = 22) -> Dict[str, Any]:
        """Execute SSH command using system SSH client"""
        try:
            # Build SSH command
            ssh_cmd = [
                "ssh",
                "-i", key_path,
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "ConnectTimeout=30",
                "-p", str(port),
                f"{username}@{host}",
                command
            ]
            
            # Execute command
            result = subprocess.run(
                ssh_cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "command": command
            }
            
        except subprocess.TimeoutExpired:
            return {"error": "SSH command timed out"}
        except Exception as e:
            return {"error": f"SSH execution failed: {str(e)}"}
    
    def _execute_clickhouse_query(self, host: str, username: str, key_path: str,
                                query: str, format: str = "TabSeparatedWithNames",
                                port: int = 22) -> Dict[str, Any]:
        """Execute ClickHouse query via SSH"""
        try:
            # Escape query for shell
            escaped_query = query.replace('"', '\\"')
            
            # Prepare ClickHouse command - updated for default user
            if username == "default":
                clickhouse_cmd = f'clickhouse-client --query="{escaped_query}" --format={format}'
            else:
                clickhouse_cmd = f'clickhouse-client --user={username} --query="{escaped_query}" --format={format}'
            
            # Execute via SSH
            result = self._execute_ssh_command(host, "root", key_path, clickhouse_cmd, port)
            
            if result.get("success"):
                return {
                    "success": True,
                    "output": result["stdout"],
                    "format": format,
                    "query": query,
                    "execution_time": time.time()
                }
            else:
                return {
                    "success": False,
                    "error": result.get("stderr", "Unknown error"),
                    "query": query,
                    "returncode": result.get("returncode", -1)
                }
                
        except Exception as e:
            return {"error": f"Query execution failed: {str(e)}"}
    
    def _parse_tabseparated_result(self, output: str) -> List[Dict[str, Any]]:
        """Parse TabSeparatedWithNames format to list of dictionaries"""
        if not output.strip():
            return []
        
        lines = output.strip().split('\n')
        if len(lines) < 2:
            return []
        
        # First line is headers
        headers = lines[0].split('\t')
        
        # Parse data rows
        rows = []
        for line in lines[1:]:
            values = line.split('\t')
            if len(values) == len(headers):
                row = dict(zip(headers, values))
                rows.append(row)
        
        return rows

# Global manager instance
ch_manager = ClickHouseSSHManager()

def clickhouse_ssh_connect(host: str, username: str = "default", key_path: str = None, 
                          port: int = 22, **kwargs) -> Dict[str, Any]:
    """Test connection to ClickHouse server via SSH"""
    
    if not key_path:
        # Try to find key in current directory and Downloads
        possible_keys = [
            "./new_do_bluebot_apr25",
            "./new_do_bluebot_apr25.pem",
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25"),
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25.pem"),
        ]
        
        for key in possible_keys:
            if os.path.exists(key):
                key_path = key
                break
    
    if not key_path:
        return {"error": "SSH key not found. Please ensure 'new_do_bluebot_apr25' is in current directory or Downloads folder."}
    
    # Test connection with simple query
    test_result = ch_manager._execute_clickhouse_query(
        host, username, key_path, "SELECT 1", "TabSeparatedWithNames", port
    )
    
    if test_result.get("success"):
        ch_manager.connected = True
        ch_manager.connection_info = {
            "host": host,
            "username": username,
            "port": port,
            "key_path": key_path
        }
        return {
            "success": True,
            "message": "Connected to ClickHouse server",
            "connection_info": ch_manager.connection_info
        }
    else:
        return {
            "error": f"Failed to connect: {test_result.get('error')}",
            "details": test_result
        }

def clickhouse_ssh_execute_query(query: str, host: str = "139.59.90.156", 
                                username: str = "default", key_path: str = None,
                                format: str = "TabSeparatedWithNames", 
                                parse_result: bool = True, port: int = 22, **kwargs) -> Dict[str, Any]:
    """Execute ClickHouse query and return results"""
    
    if not key_path:
        # Try to find key
        possible_keys = [
            "./new_do_bluebot_apr25",
            "./new_do_bluebot_apr25.pem",
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25"),
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25.pem"),
        ]
        
        for key in possible_keys:
            if os.path.exists(key):
                key_path = key
                break
    
    if not key_path:
        return {"error": "SSH key not found"}
    
    result = ch_manager._execute_clickhouse_query(host, username, key_path, query, format, port)
    
    if result.get("success") and parse_result and format == "TabSeparatedWithNames":
        try:
            parsed_rows = ch_manager._parse_tabseparated_result(result["output"])
            result["rows"] = parsed_rows
            result["row_count"] = len(parsed_rows)
        except Exception as e:
            result["parse_error"] = str(e)
    
    return result

def clickhouse_ssh_export_to_csv(query: str, output_file: str, host: str = "139.59.90.156", 
                                username: str = "default", key_path: str = None, 
                                port: int = 22, **kwargs) -> Dict[str, Any]:
    """Execute query and export results to CSV file"""
    
    if not key_path:
        # Try to find key
        possible_keys = [
            "./new_do_bluebot_apr25",
            "./new_do_bluebot_apr25.pem",
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25"),
            os.path.join(os.path.expanduser("~"), "Downloads", "new_do_bluebot_apr25.pem"),
        ]
        
        for key in possible_keys:
            if os.path.exists(key):
                key_path = key
                break
    
    if not key_path:
        return {"error": "SSH key not found"}
    
    # Execute query with CSV format
    result = ch_manager._execute_clickhouse_query(host, username, key_path, query, "CSV", port)
    
    if result.get("success"):
        try:
            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else ".", exist_ok=True)
            
            # Write CSV data to file
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(result["output"])
            
            file_size = os.path.getsize(output_file)
            
            # Also parse the data for display
            csv_lines = result["output"].strip().split('\n')
            row_count = len(csv_lines) - 1  # Subtract header
            
            return {
                "success": True,
                "output_file": output_file,
                "file_size": file_size,
                "row_count": row_count,
                "query": query,
                "message": f"✅ {row_count} rows exported to {output_file}",
                "csv_preview": csv_lines[:6] if len(csv_lines) > 1 else ["No data"]  # Show first 5 rows + header
            }
        except Exception as e:
            return {"error": f"Failed to write CSV file: {str(e)}"}
    else:
        return result

def clickhouse_ssh_get_tracking_sample(host: str = "139.59.90.156", limit: int = 5, 
                                      username: str = "default", **kwargs) -> Dict[str, Any]:
    """Get sample data from tracking10 table (corrected name)"""
    
    query = f"SELECT * FROM tracking10 LIMIT {limit}"
    return clickhouse_ssh_execute_query(query, host, username, **kwargs)

def clickhouse_ssh_show_tables(host: str = "139.59.90.156", username: str = "default", 
                              **kwargs) -> Dict[str, Any]:
    """Show all tables"""
    
    query = "SHOW TABLES"
    return clickhouse_ssh_execute_query(query, host, username, **kwargs)

def clickhouse_ssh_get_table_info(table_name: str = "tracking10", 
                                 host: str = "139.59.90.156", 
                                 username: str = "default", **kwargs) -> Dict[str, Any]:
    """Get table structure and sample data"""
    
    # Get table description
    desc_query = f"DESCRIBE TABLE {table_name}"
    desc_result = clickhouse_ssh_execute_query(desc_query, host, username, **kwargs)
    
    # Get row count
    count_query = f"SELECT COUNT(*) as total_rows FROM {table_name}"
    count_result = clickhouse_ssh_execute_query(count_query, host, username, **kwargs)
    
    # Get sample data
    sample_query = f"SELECT * FROM {table_name} LIMIT 3"
    sample_result = clickhouse_ssh_execute_query(sample_query, host, username, **kwargs)
    
    return {
        "table_name": table_name,
        "description": desc_result,
        "row_count": count_result,
        "sample_data": sample_result
    }

def clickhouse_ssh_display_data(data_dict: Dict[str, Any], title: str = "Data Display") -> Dict[str, Any]:
    """Display data in a readable format"""
    
    print(f"\n" + "="*60)
    print(f"📊 {title}")
    print("="*60)
    
    if isinstance(data_dict, dict) and "rows" in data_dict and data_dict.get("success"):
        rows = data_dict["rows"]
        if rows:
            print(f"📈 Found {len(rows)} rows:")
            
            # Display each row
            for i, row in enumerate(rows, 1):
                print(f"\n🔸 Row {i}:")
                for key, value in row.items():
                    print(f"   {key}: {value}")
            
            return {
                "success": True,
                "message": f"Displayed {len(rows)} rows",
                "row_count": len(rows)
            }
        else:
            print("📭 No data rows found")
            return {"success": True, "message": "No data to display", "row_count": 0}
    else:
        print(f"❌ Error displaying data: {data_dict.get('error', 'Unknown error')}")
        return {"error": "Failed to display data", "details": data_dict}

# Tool Registry - these are the functions that will be discovered
TOOL_REGISTRY = {
    "connect": clickhouse_ssh_connect,
    "execute_query": clickhouse_ssh_execute_query,
    "export_to_csv": clickhouse_ssh_export_to_csv,
    "get_tracking_sample": clickhouse_ssh_get_tracking_sample,
    "show_tables": clickhouse_ssh_show_tables,
    "get_table_info": clickhouse_ssh_get_table_info,
    "display_data": clickhouse_ssh_display_data
}

# Test function
def test_connection():
    """Test the ClickHouse connection with correct table name"""
    print("Testing ClickHouse SSH connection...")
    
    # Test connection
    result = clickhouse_ssh_connect("139.59.90.156", "default")
    if result.get("success"):
        print("✅ Connection successful")
        
        # Test with correct table name
        query_result = clickhouse_ssh_execute_query("SELECT * FROM tracking10 LIMIT 2")
        if query_result.get("success"):
            print(f"✅ Query successful: {query_result.get('row_count', 0)} rows retrieved")
            
            # Display data
            clickhouse_ssh_display_data(query_result, "tracking10 Sample Data")
        else:
            print(f"❌ Query failed: {query_result.get('error')}")
    else:
        print(f"❌ Connection failed: {result.get('error')}")

if __name__ == "__main__":
    test_connection()

print("✅ Enhanced ClickHouse SSH tools loaded successfully")