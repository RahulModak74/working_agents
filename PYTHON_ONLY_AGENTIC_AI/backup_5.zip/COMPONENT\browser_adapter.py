#!/usr/bin/env python3

import os
import sys
import json
import time
import logging
import requests
import re
from typing import Dict, Any, List, Optional
from datetime import datetime
from urllib.parse import urljoin, urlparse

# IMPORTANT: Add tool namespace for tool_manager discovery
TOOL_NAMESPACE = "browser"

# Set up logging
logger = logging.getLogger("browser_adapter")

# Try to import BeautifulSoup
try:
    from bs4 import BeautifulSoup
    BEAUTIFULSOUP_AVAILABLE = True
    logger.info("✅ BeautifulSoup successfully imported")
except ImportError:
    BEAUTIFULSOUP_AVAILABLE = False
    logger.warning("❌ BeautifulSoup not available. Install with 'pip install beautifulsoup4'")

class SimpleBrowserSession:
    """Simple browser session using requests + BeautifulSoup"""
    
    def __init__(self, session_id: str = "default"):
        self.session_id = session_id
        self.session = requests.Session()
        self.current_url = None
        self.current_soup = None
        self.history = []
        
        # Set realistic headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })

class SimpleBrowserManager:
    """Browser manager using simple HTTP requests"""
    
    def __init__(self):
        self.sessions = {}
        self.default_timeout = 30
        
    def create_browser(self, browser_id: str = None, browser_type: str = "simple", 
                      headless: bool = True) -> Dict[str, Any]:
        """Create a new browser session"""
        if browser_id is None:
            browser_id = "default"
        
        try:
            session = SimpleBrowserSession(browser_id)
            self.sessions[browser_id] = session
            
            logger.info(f"✅ Browser created: {browser_id}")
            
            return {
                "status": "success", 
                "browser_id": browser_id, 
                "type": "simple_http",
                "message": f"Simple browser session created: {browser_id}"
            }
            
        except Exception as e:
            logger.error(f"❌ Error creating browser: {str(e)}")
            return {"error": f"Failed to create browser: {str(e)}"}
    
    def navigate(self, url: str, browser_id: str = None, wait_until: str = "load") -> Dict[str, Any]:
        """Navigate to a URL"""
        if browser_id is None:
            browser_id = "default"
            
        # Create browser if it doesn't exist
        if browser_id not in self.sessions:
            result = self.create_browser(browser_id)
            if "error" in result:
                return result
        
        session_obj = self.sessions.get(browser_id)
        if not session_obj:
            return {"error": f"No session found for browser {browser_id}"}
        
        # Fix URL if needed
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        try:
            start_time = time.time()
            response = session_obj.session.get(url, timeout=self.default_timeout)
            response.raise_for_status()
            end_time = time.time()
            
            # Store current state
            session_obj.current_url = response.url
            session_obj.history.append(response.url)
            
            # Parse with BeautifulSoup if available
            if BEAUTIFULSOUP_AVAILABLE:
                session_obj.current_soup = BeautifulSoup(response.content, 'html.parser')
                page_title = session_obj.current_soup.title.string.strip() if session_obj.current_soup.title else "No Title"
            else:
                session_obj.current_soup = None
                # Try to extract title from raw HTML
                title_match = re.search(r'<title[^>]*>([^<]+)</title>', response.text, re.IGNORECASE)
                page_title = title_match.group(1).strip() if title_match else "No Title"
            
            logger.info(f"✅ Navigated to: {response.url}")
            
            return {
                "status": "success",
                "url": response.url,
                "title": page_title,
                "status_code": response.status_code,
                "navigation_time_seconds": round(end_time - start_time, 2)
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Navigation error: {str(e)}")
            return {"error": f"Failed to navigate to {url}: {str(e)}"}
        except Exception as e:
            logger.error(f"❌ Unexpected error: {str(e)}")
            return {"error": f"Unexpected error: {str(e)}"}
    
    def get_page_content(self, browser_id: str = None, content_type: str = "text") -> Dict[str, Any]:
        """Get page content"""
        if browser_id is None:
            browser_id = "default"
            
        session_obj = self.sessions.get(browser_id)
        if not session_obj:
            return {"error": f"No session found for browser {browser_id}"}
        
        if not session_obj.current_url:
            return {"error": "No page loaded. Navigate to a URL first."}
        
        try:
            # Get fresh content
            response = session_obj.session.get(session_obj.current_url, timeout=self.default_timeout)
            response.raise_for_status()
            
            if content_type.lower() == "html":
                content = response.text
            else:
                # Extract clean text
                if BEAUTIFULSOUP_AVAILABLE:
                    soup = BeautifulSoup(response.content, 'html.parser')
                    
                    # Remove unwanted elements
                    for element in soup(["script", "style", "nav", "header", "footer", "aside"]):
                        element.decompose()
                    
                    # Try to get main content
                    main_content = (soup.find('main') or 
                                  soup.find('article') or 
                                  soup.find('div', {'id': 'content'}) or 
                                  soup.find('div', {'class': 'content'}) or 
                                  soup.body)
                    
                    if main_content:
                        content = main_content.get_text(separator=' ', strip=True)
                    else:
                        content = soup.get_text(separator=' ', strip=True)
                    
                    # Clean up text
                    content = re.sub(r'\s+', ' ', content).strip()
                else:
                    # Fallback: try to extract text from HTML
                    content = re.sub(r'<[^>]+>', ' ', response.text)
                    content = re.sub(r'\s+', ' ', content).strip()
            
            metadata = {
                "url": session_obj.current_url,
                "content_length": len(content),
                "content_type": content_type,
                "timestamp": datetime.now().isoformat()
            }
            
            return {
                "status": "success",
                "content": content,
                "metadata": metadata
            }
            
        except Exception as e:
            logger.error(f"❌ Content extraction error: {str(e)}")
            return {"error": f"Failed to get page content: {str(e)}"}
    
    def close_browser(self, browser_id: str = None) -> Dict[str, Any]:
        """Close browser session"""
        if browser_id is None:
            browser_id = "default"
        
        try:
            if browser_id in self.sessions:
                session_obj = self.sessions[browser_id]
                session_obj.session.close()
                del self.sessions[browser_id]
                
                logger.info(f"✅ Browser closed: {browser_id}")
                return {"status": "success", "message": f"Browser {browser_id} closed"}
            else:
                return {"error": f"Browser {browser_id} not found"}
                
        except Exception as e:
            logger.error(f"❌ Close error: {str(e)}")
            return {"error": f"Failed to close browser: {str(e)}"}

# Global browser manager
BROWSER_MANAGER = SimpleBrowserManager()

# Tool Registry Functions
def browser_create(browser_id: str = None, browser_type: str = "simple", headless: bool = True, **kwargs) -> Dict[str, Any]:
    """Create a new simple browser session"""
    return BROWSER_MANAGER.create_browser(browser_id, browser_type, headless)

def browser_navigate(url: str, browser_id: str = None, wait_until: str = "load", **kwargs) -> Dict[str, Any]:
    """Navigate to a URL"""
    return BROWSER_MANAGER.navigate(url, browser_id, wait_until)

def browser_get_content(browser_id: str = None, content_type: str = "text", **kwargs) -> Dict[str, Any]:
    """Get page content"""
    return BROWSER_MANAGER.get_page_content(browser_id, content_type)

def browser_close(browser_id: str = None, **kwargs) -> Dict[str, Any]:
    """Close browser"""
    return BROWSER_MANAGER.close_browser(browser_id)

def browser_stats(**kwargs) -> Dict[str, Any]:
    """Get browser statistics"""
    return {
        "active_sessions": len(BROWSER_MANAGER.sessions),
        "browser_type": "simple_http",
        "beautifulsoup_available": BEAUTIFULSOUP_AVAILABLE,
        "timestamp": datetime.now().isoformat()
    }

# Register tools
TOOL_REGISTRY = {
    "create": browser_create,
    "navigate": browser_navigate, 
    "get_content": browser_get_content,
    "close": browser_close,
    "stats": browser_stats
}

logger.info(f"✅ Simple browser tools registered: {list(TOOL_REGISTRY.keys())}")
