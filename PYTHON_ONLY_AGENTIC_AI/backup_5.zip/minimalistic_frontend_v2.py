#!/usr/bin/env python3

from sanic import Sanic, response
import json
import os
import uuid
import subprocess
import csv
import io
from datetime import datetime
from pathlib import Path
import time
import threading
import sys
if sys.platform.startswith('win'):
    os.environ['PYTHONIOENCODING'] = 'utf-8'

app = Sanic("MinimalWorkflowAPI")

# Directories
UPLOAD_DIR = "./uploads"
WORKFLOWS_DIR = "./workflows" 
RESULTS_DIR = "./results"

# Ensure directories exist
for dir_path in [UPLOAD_DIR, WORKFLOWS_DIR, RESULTS_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# Execution tracking
executions = {}

def monitor_execution(execution_id):
    """Monitor execution in background thread"""
    try:
        exec_info = executions[execution_id]
        process = exec_info.get("process")
        
        if process:
            print(f"⏳ Monitoring execution {execution_id}")
            print(f"📝 Command: {exec_info.get('command', 'Unknown')}")
            
            # Wait for process to complete
            stdout, stderr = process.communicate()
            
            print(f"✅ Process completed for {execution_id}")
            print(f"📤 Return code: {process.returncode}")
            print(f"📄 Stdout length: {len(stdout) if stdout else 0}")
            print(f"🚨 Stderr length: {len(stderr) if stderr else 0}")
            
            # Update execution info
            exec_info["status"] = "completed" if process.returncode == 0 else "failed"
            exec_info["end_time"] = datetime.now().isoformat()
            exec_info["return_code"] = process.returncode
            exec_info["stdout"] = stdout.decode() if stdout else ""
            exec_info["stderr"] = stderr.decode() if stderr else ""
            
            if process.returncode != 0:
                print(f"❌ Execution failed with return code {process.returncode}")
                print(f"🚨 Full Stderr:")
                print(stderr.decode() if stderr else 'No stderr')
                print(f"📤 Full Stdout:")
                print(stdout.decode() if stdout else 'No stdout')
            
            # Look for results file
            workflow_name = Path(exec_info["workflow_id"]).stem
            possible_results = [
                f"{workflow_name}_results.json",
                f"results_{workflow_name}.json",
                f"{exec_info['workflow_id']}_results.json",
                f"results.json",
                f"output.json"
            ]
            
            for results_file in possible_results:
                if os.path.exists(results_file):
                    exec_info["results_file"] = results_file
                    print(f"📄 Found results file: {results_file}")
                    break
            else:
                print(f"⚠️ No results file found. Checked: {possible_results}")
            
            # Remove process reference
            exec_info.pop("process", None)
            
    except Exception as e:
        print(f"❌ Error monitoring execution {execution_id}: {e}")
        exec_info["status"] = "failed"
        exec_info["error"] = str(e)

@app.route("/", methods=["GET"])
async def web_ui(request):
    """Serve minimal web interface"""
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>Agentic Workflow Runner</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }
        .section { background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 8px; }
        button { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #005a8b; }
        button:disabled { background: #ccc; cursor: not-allowed; }
        input[type="file"] { margin: 10px 0; }
        .results { background: #e8f4f8; padding: 15px; margin: 10px 0; border-radius: 4px; }
        .error { background: #ffebee; color: #c62828; }
        .success { background: #e8f5e8; color: #2e7d32; }
        .warning { background: #fff3cd; color: #856404; }
        pre { background: #f0f0f0; padding: 10px; overflow-x: auto; border-radius: 4px; }
        .spinner { display: inline-block; width: 16px; height: 16px; border: 2px solid #f3f3f3; border-top: 2px solid #007cba; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <h1>🤖 Agentic Workflow Runner</h1>
    
    <!-- Workflow Upload -->
    <div class="section">
        <h3>1. Upload Workflow</h3>
        <input type="file" id="workflowFile" accept=".json" />
        <button onclick="uploadWorkflow()">Upload JSON Workflow</button>
        <button id="convertBtn" onclick="convertToCSV()" style="display:none; margin-left: 10px; background: #28a745;">📊 Convert to CSV</button>
        <div id="workflowResult"></div>
    </div>
    
    <!-- Data Upload (Optional) -->
    <div class="section">
        <h3>2. Upload Data Files (Optional)</h3>
        <input type="file" id="dataFiles" multiple accept=".csv,.xlsx,.json" />
        <button onclick="uploadData()">Upload Data Files</button>
        <div id="dataResult"></div>
    </div>
    
    <!-- Execution -->
    <div class="section">
        <h3>3. Execute Workflow</h3>
        <button id="executeBtn" onclick="executeWorkflow()">▶️ Run Workflow</button>
        <button id="executeDataBtn" onclick="executeWithData()">▶️ Run with Data</button>
        <div id="executionResult"></div>
    </div>
    
    <!-- Results -->
    <div class="section">
        <h3>4. Results</h3>
        <button id="statusBtn" onclick="checkStatus()">🔄 Check Status</button>
        <button id="downloadBtn" onclick="downloadResults()">📥 Download Results</button>
        <div id="statusResult"></div>
    </div>

    <script>
        let currentWorkflowId = null;
        let currentDataFiles = [];
        let currentExecutionId = null;
        let statusInterval = null;

        function showResult(elementId, message, type = 'success') {
            const el = document.getElementById(elementId);
            const className = type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'success';
            el.innerHTML = `<div class="results ${className}">${message}</div>`;
        }

        function setButtonState(buttonId, enabled, text = null) {
            const btn = document.getElementById(buttonId);
            if (btn) {
                btn.disabled = !enabled;
                if (text) btn.textContent = text;
            }
        }

        function startStatusMonitoring() {
            if (statusInterval) clearInterval(statusInterval);
            statusInterval = setInterval(async () => {
                await checkStatus(false); // Silent check
            }, 2000);
        }

        function stopStatusMonitoring() {
            if (statusInterval) {
                clearInterval(statusInterval);
                statusInterval = null;
            }
        }

        async function uploadWorkflow() {
            const fileInput = document.getElementById('workflowFile');
            if (!fileInput.files[0]) {
                showResult('workflowResult', 'Please select a JSON workflow file', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('workflow', fileInput.files[0]);

            try {
                const response = await fetch('/upload-workflow', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (response.ok) {
                    currentWorkflowId = result.workflow_id;
                    document.getElementById('convertBtn').style.display = 'inline-block';
                    showResult('workflowResult', 
                        `✅ Workflow uploaded: ${result.steps} steps, ${result.agents.length} agents`);
                } else {
                    showResult('workflowResult', `❌ ${result.error}`, 'error');
                }
            } catch (error) {
                showResult('workflowResult', `❌ Upload failed: ${error.message}`, 'error');
            }
        }

        async function uploadData() {
            const fileInput = document.getElementById('dataFiles');
            if (!fileInput.files.length) {
                showResult('dataResult', 'Please select data files', 'error');
                return;
            }

            const formData = new FormData();
            Array.from(fileInput.files).forEach((file, index) => {
                formData.append(`data_${index}`, file);
            });

            try {
                const response = await fetch('/upload-data', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (response.ok) {
                    currentDataFiles = result.uploaded_files;
                    showResult('dataResult', 
                        `✅ Uploaded ${result.uploaded_files.length} data files`);
                } else {
                    showResult('dataResult', `❌ ${result.error}`, 'error');
                }
            } catch (error) {
                showResult('dataResult', `❌ Upload failed: ${error.message}`, 'error');
            }
        }

        async function executeWorkflow() {
            if (!currentWorkflowId) {
                showResult('executionResult', 'Please upload a workflow first', 'error');
                return;
            }

            setButtonState('executeBtn', false, '⏳ Starting...');
            setButtonState('executeDataBtn', false);

            try {
                const response = await fetch('/execute', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        workflow_id: currentWorkflowId,
                        use_data: false
                    })
                });
                const result = await response.json();
                
                if (response.ok) {
                    currentExecutionId = result.execution_id;
                    showResult('executionResult', 
                        `✅ Execution started: ${result.execution_id}<br><div class="spinner"></div> Running...`);
                    startStatusMonitoring();
                } else {
                    showResult('executionResult', `❌ ${result.error}`, 'error');
                    setButtonState('executeBtn', true, '▶️ Run Workflow');
                    setButtonState('executeDataBtn', true);
                }
            } catch (error) {
                showResult('executionResult', `❌ Execution failed: ${error.message}`, 'error');
                setButtonState('executeBtn', true, '▶️ Run Workflow');
                setButtonState('executeDataBtn', true);
            }
        }

        async function executeWithData() {
            if (!currentWorkflowId) {
                showResult('executionResult', 'Please upload a workflow first', 'error');
                return;
            }
            if (!currentDataFiles.length) {
                showResult('executionResult', 'Please upload data files first', 'error');
                return;
            }

            setButtonState('executeBtn', false);
            setButtonState('executeDataBtn', false, '⏳ Starting...');

            try {
                const response = await fetch('/execute', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        workflow_id: currentWorkflowId,
                        data_files: currentDataFiles,
                        use_data: true
                    })
                });
                const result = await response.json();
                
                if (response.ok) {
                    currentExecutionId = result.execution_id;
                    showResult('executionResult', 
                        `✅ Execution with data started: ${result.execution_id}<br><div class="spinner"></div> Running...`);
                    startStatusMonitoring();
                } else {
                    showResult('executionResult', `❌ ${result.error}`, 'error');
                    setButtonState('executeBtn', true);
                    setButtonState('executeDataBtn', true, '▶️ Run with Data');
                }
            } catch (error) {
                showResult('executionResult', `❌ Execution failed: ${error.message}`, 'error');
                setButtonState('executeBtn', true);
                setButtonState('executeDataBtn', true, '▶️ Run with Data');
            }
        }

        async function checkStatus(showMessage = true) {
            if (!currentExecutionId) {
                if (showMessage) showResult('statusResult', 'No execution in progress', 'error');
                return;
            }

            try {
                const response = await fetch(`/status/${currentExecutionId}`);
                const result = await response.json();
                
                if (response.ok) {
                    const statusMessage = `Status: ${result.status}<br>
                         Started: ${result.start_time}<br>
                         ${result.end_time ? `Ended: ${result.end_time}<br>` : ''}
                         ${result.results_file ? '✅ Results ready' : '⏳ Running...'}`;
                    
                    if (showMessage) showResult('statusResult', statusMessage);
                    
                    // Update execution status display
                    if (result.status === 'completed') {
                        stopStatusMonitoring();
                        showResult('executionResult', 
                            `✅ Execution completed: ${currentExecutionId}<br>📄 Results available for download`);
                        setButtonState('executeBtn', true, '▶️ Run Workflow');
                        setButtonState('executeDataBtn', true, '▶️ Run with Data');
                        setButtonState('downloadBtn', true);
                    } else if (result.status === 'failed') {
                        stopStatusMonitoring();
                        showResult('executionResult', 
                            `❌ Execution failed: ${currentExecutionId}<br>${result.error || 'Check logs for details'}`, 'error');
                        setButtonState('executeBtn', true, '▶️ Run Workflow');
                        setButtonState('executeDataBtn', true, '▶️ Run with Data');
                    }
                } else {
                    if (showMessage) showResult('statusResult', `❌ ${result.error}`, 'error');
                }
            } catch (error) {
                if (showMessage) showResult('statusResult', `❌ Status check failed: ${error.message}`, 'error');
            }
        }

        async function downloadResults() {
            if (!currentExecutionId) {
                showResult('statusResult', 'No execution to download', 'error');
                return;
            }

            try {
                const response = await fetch(`/download/${currentExecutionId}`);
                if (response.ok) {
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `results_${currentExecutionId}.json`;
                    a.click();
                    window.URL.revokeObjectURL(url);
                    showResult('statusResult', '✅ Results downloaded');
                } else {
                    const result = await response.json();
                    showResult('statusResult', `❌ ${result.error}`, 'error');
                }
            } catch (error) {
                showResult('statusResult', `❌ Download failed: ${error.message}`, 'error');
            }
        }

        async function convertToCSV() {
            if (!currentWorkflowId) {
                showResult('workflowResult', 'No workflow to convert', 'error');
                return;
            }

            try {
                const response = await fetch(`/convert-to-csv/${currentWorkflowId}`);
                if (response.ok) {
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `workflow_${currentWorkflowId}.csv`;
                    a.click();
                    window.URL.revokeObjectURL(url);
                    
                    const originalText = document.getElementById('workflowResult').textContent;
                    const stepsText = originalText.split('agents')[0] + 'agents';
                    showResult('workflowResult', 
                        `${stepsText}<br>📊 CSV downloaded successfully!`);
                } else {
                    const result = await response.json();
                    showResult('workflowResult', `❌ Conversion failed: ${result.error}`, 'error');
                }
            } catch (error) {
                showResult('workflowResult', `❌ CSV conversion failed: ${error.message}`, 'error');
            }
        }

        // Clean up on page unload
        window.addEventListener('beforeunload', () => {
            stopStatusMonitoring();
        });
    </script>
</body>
</html>
    """
    return response.html(html)

@app.route("/upload-workflow", methods=["POST"])
async def upload_workflow(request):
    """Upload JSON workflow"""
    try:
        if 'workflow' not in request.files:
            return response.json({"error": "No workflow file"}, status=400)
        
        file = request.files['workflow'][0]
        workflow_id = str(uuid.uuid4())
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        
        with open(workflow_path, 'wb') as f:
            f.write(file.body)
        
        # Analyze workflow
        with open(workflow_path, 'r') as f:
            workflow_data = json.load(f)
        
        steps = workflow_data if isinstance(workflow_data, list) else workflow_data.get("steps", [])
        agents = [step.get("agent", "unknown") for step in steps if step.get("agent")]
        
        return response.json({
            "workflow_id": workflow_id,
            "steps": len(steps),
            "agents": list(set(agents))[:10],  # Remove duplicates and limit
            "filename": file.name
        })
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/convert-to-csv/<workflow_id>", methods=["GET"])
async def convert_to_csv(request, workflow_id):
    """Convert JSON workflow to CSV format"""
    try:
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        
        if not os.path.exists(workflow_path):
            return response.json({"error": "Workflow not found"}, status=404)
        
        with open(workflow_path, 'r') as f:
            workflow_data = json.load(f)
        
        # Handle both list and dict formats
        steps = workflow_data if isinstance(workflow_data, list) else workflow_data.get("steps", [])
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        if steps:
            # Get all possible keys from all steps
            all_keys = set()
            for step in steps:
                all_keys.update(step.keys())
            
            headers = sorted(list(all_keys))
            writer.writerow(headers)
            
            # Write data rows
            for step in steps:
                row = [step.get(key, '') for key in headers]
                writer.writerow(row)
        else:
            # Empty workflow
            writer.writerow(['step', 'agent', 'action', 'input', 'output'])
        
        csv_content = output.getvalue().encode('utf-8')
        output.close()
        
        return response.raw(
            csv_content,
            headers={
                "Content-Disposition": f"attachment; filename=workflow_{workflow_id}.csv",
                "Content-Type": "text/csv"
            }
        )
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/upload-data", methods=["POST"])
async def upload_data(request):
    """Upload data files"""
    try:
        uploaded_files = []
        for field_name, file_list in request.files.items():
            for file_obj in file_list:
                file_id = str(uuid.uuid4())
                file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file_obj.name}")
                
                with open(file_path, 'wb') as f:
                    f.write(file_obj.body)
                
                uploaded_files.append({
                    "file_id": file_id,
                    "original_name": file_obj.name,
                    "file_path": file_path
                })
        
        return response.json({"uploaded_files": uploaded_files})
        
    except Exception as e:
        return response.json({"error": str(e)}, status=500)

@app.route("/execute", methods=["POST"])
async def execute_workflow(request):
    """Execute workflow"""
    try:
        data = request.json
        workflow_id = data['workflow_id']
        use_data = data.get('use_data', False)
        data_files = data.get('data_files', [])
        
        workflow_path = os.path.join(WORKFLOWS_DIR, f"{workflow_id}.json")
        if not os.path.exists(workflow_path):
            return response.json({"error": "Workflow not found"}, status=404)
        
        execution_id = str(uuid.uuid4())
        
        # Prepare command with better error checking
        if use_data and data_files:
            # Use workflow_runner_v2.py with data
            runner_script = "workflow_runner_v2.py"
            cmd = ["python", runner_script, "--workflow", workflow_path]
            cmd.extend(["--data"] + [df["file_path"] for df in data_files[:3]])
        else:
            # Use workflow_runner_v1.py
            runner_script = "workflow_runner_v1.py"
            cmd = ["python", runner_script, workflow_path]
        
        # Check if runner script exists
        if not os.path.exists(runner_script):
            return response.json({
                "error": f"Runner script '{runner_script}' not found. Please ensure the script exists in the current directory."
            }, status=404)
        
        print(f"🚀 Executing command: {' '.join(cmd)}")
        print(f"📁 Working directory: {os.getcwd()}")
        print(f"📄 Workflow file exists: {os.path.exists(workflow_path)}")
        print(f"🐍 Runner script exists: {os.path.exists(runner_script)}")
        
        # Execute workflow
        process = subprocess.Popen(cmd, 
                                 stdout=subprocess.PIPE, 
                                 stderr=subprocess.PIPE,
                                 cwd=".")
        
        executions[execution_id] = {
            "status": "running",
            "workflow_id": workflow_id,
            "start_time": datetime.now().isoformat(),
            "process": process,
            "use_data": use_data,
            "command": ' '.join(cmd),
            "runner_script": runner_script
        }
        
        # Start monitoring in background thread
        thread = threading.Thread(target=monitor_execution, args=(execution_id,))
        thread.daemon = True
        thread.start()
        
        return response.json({
            "execution_id": execution_id,
            "status": "started",
            "command": ' '.join(cmd)
        })
        
    except Exception as e:
        print(f"❌ Execution error: {str(e)}")
        return response.json({"error": str(e)}, status=500)

@app.route("/status/<execution_id>", methods=["GET"])
async def get_status(request, execution_id):
    """Get execution status"""
    if execution_id not in executions:
        return response.json({"error": "Execution not found"}, status=404)
    
    exec_info = executions[execution_id]
    
    return response.json({
        "execution_id": execution_id,
        "status": exec_info["status"],
        "start_time": exec_info["start_time"],
        "end_time": exec_info.get("end_time"),
        "results_file": exec_info.get("results_file"),
        "error": exec_info.get("error"),
        "return_code": exec_info.get("return_code"),
        "command": exec_info.get("command"),
        "runner_script": exec_info.get("runner_script"),
        "stdout": exec_info.get("stdout", "")[:5000],  # Increased for full debugging
        "stderr": exec_info.get("stderr", "")[:5000]
    })

@app.route("/download/<execution_id>", methods=["GET"])
async def download_results(request, execution_id):
    """Download results file"""
    if execution_id not in executions:
        return response.json({"error": "Execution not found"}, status=404)
    
    exec_info = executions[execution_id]
    results_file = exec_info.get("results_file")
    
    if not results_file:
        # Try to find results file
        workflow_name = exec_info["workflow_id"]
        possible_files = [
            f"{workflow_name}_results.json",
            f"results_{workflow_name}.json",
            f"{execution_id}_results.json"
        ]
        
        for filename in possible_files:
            if os.path.exists(filename):
                results_file = filename
                break
    
    if results_file and os.path.exists(results_file):
        try:
            with open(results_file, 'rb') as f:
                file_content = f.read()
            return response.raw(file_content, 
                              headers={"Content-Disposition": f"attachment; filename={os.path.basename(results_file)}"},
                              content_type="application/json")
        except Exception as e:
            return response.json({"error": f"Failed to read results file: {str(e)}"}, status=500)
    else:
        return response.json({"error": "Results file not found"}, status=404)

if __name__ == "__main__":
    print("🚀 Minimal Workflow API Server")
    print("📋 Endpoints:")
    print("  GET  /                    - Web Interface")
    print("  POST /upload-workflow     - Upload JSON workflow")
    print("  GET  /convert-to-csv/<id> - Convert workflow to CSV")
    print("  POST /upload-data         - Upload data files")  
    print("  POST /execute             - Execute workflow")
    print("  GET  /status/<id>         - Check status")
    print("  GET  /download/<id>       - Download results")
    print("🌐 Access at: http://localhost:8000")
    
    app.run(host="0.0.0.0", port=8000, debug=True)