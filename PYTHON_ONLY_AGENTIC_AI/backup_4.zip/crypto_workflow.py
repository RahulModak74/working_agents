#!/usr/bin/env python3
"""
Cryptocurrency Analysis using Cognitive Planning + LLM
Fixed version with proper async handling
"""

import asyncio
from auto_import_tools import *
from llm_powered_solution import LLMAgent

async def analyze_crypto_with_cognition():
    """Main async function for crypto analysis"""
    
    print("🧠 Starting cognitive cryptocurrency analysis...")
    
    # Create an LLM agent that uses cognitive planning
    researcher = LLMAgent("CognitiveResearcher", 
        "You are an expert cryptocurrency researcher using advanced cognitive planning techniques.")
    
    print("🎯 Creating cognitive planning session...")
    
    # LLM decides which cognitive pattern to use
    cognitive_session = cognitive_create_session(
        "tree_of_thoughts", 
        problem_description="Analyze cryptocurrency market trends and investment opportunities"
    )
    
    if "error" in cognitive_session:
        print(f"❌ Error creating cognitive session: {cognitive_session['error']}")
        return
    
    print(f"✅ Cognitive session created: {cognitive_session['session_id']}")
    print(f"📋 Pattern: {cognitive_session['pattern']}")
    print(f"📖 Description: {cognitive_session['description']}")
    
    # Work through the cognitive workflow
    step_count = 0
    max_steps = 10  # Safety limit
    
    while step_count < max_steps:
        print(f"\n🔄 Getting next cognitive step ({step_count + 1})...")
        
        next_step = cognitive_get_next_step(cognitive_session["session_id"])
        
        if next_step["status"] == "completed":
            print("✅ Cognitive workflow completed!")
            break
        elif next_step["status"] == "dynamic_step":
            print(f"🎭 Dynamic step - need to select action")
            print(f"Available actions: {next_step['available_actions']}")
            
            # For demo, select first available action
            if next_step['available_actions']:
                selected_action = next_step['available_actions'][0]
                print(f"🎯 Selecting action: {selected_action}")
                
                action_result = cognitive_select_action(
                    cognitive_session["session_id"], 
                    selected_action
                )
                print(f"Action result: {action_result}")
            continue
            
        elif next_step["status"] == "ready":
            print(f"🤖 Processing step: {next_step['agent_name']}")
            
            # Get the step content
            step_details = next_step.get("step_details", {})
            step_content = step_details.get("content", "Analyze cryptocurrency market trends")
            
            print(f"📝 Step prompt: {step_content[:100]}...")
            
            # LLM processes the cognitive step
            try:
                result = await researcher.call_llm(step_content)
                print(f"✅ LLM response received ({len(result)} characters)")
                
                # Submit the result
                submission = cognitive_submit_result(
                    cognitive_session["session_id"], 
                    next_step["agent_name"], 
                    {"analysis": result, "step_content": step_content}
                )
                
                print(f"📤 Result submitted: {submission['message']}")
                
            except Exception as e:
                print(f"❌ Error in LLM processing: {e}")
                # Submit error result
                cognitive_submit_result(
                    cognitive_session["session_id"], 
                    next_step["agent_name"], 
                    {"error": str(e), "step_content": step_content}
                )
        else:
            print(f"⚠️ Unknown step status: {next_step['status']}")
            break
        
        step_count += 1
    
    # Get the complete cognitive analysis
    print("\n📊 Retrieving final cognitive analysis...")
    final_results = cognitive_get_results(cognitive_session["session_id"])
    
    if "error" in final_results:
        print(f"❌ Error getting results: {final_results['error']}")
        return
    
    print("✅ Cognitive analysis complete!")
    print(f"📈 Results from {len(final_results['results'])} cognitive agents")
    
    # Display summary of results
    print("\n🧠 Cognitive Analysis Summary:")
    for agent_name, result in final_results['results'].items():
        print(f"\n  🤖 {agent_name}:")
        if isinstance(result, dict):
            if "analysis" in result:
                analysis = result["analysis"]
                preview = analysis[:200] + "..." if len(analysis) > 200 else analysis
                print(f"     {preview}")
            elif "error" in result:
                print(f"     ❌ Error: {result['error']}")
            else:
                print(f"     📋 Keys: {list(result.keys())}")
        else:
            print(f"     📝 {str(result)[:100]}...")
    
    # Transform to research plan
    print("\n🔬 Transforming to research plan...")
    try:
        research_plan = cognitive_transform_for_research(
            cognitive_session["session_id"], 
            "cryptocurrency market analysis"
        )
        
        if "error" not in research_plan:
            print("✅ Research plan generated!")
            if "research_plan" in research_plan:
                plan = research_plan["research_plan"]
                print(f"🎯 Goal: {plan.get('goal', 'Not specified')}")
                print(f"❓ Key Questions: {len(plan.get('key_questions', []))}")
                print(f"📚 Subtopics: {len(plan.get('subtopics', []))}")
        else:
            print(f"⚠️ Research plan generation failed: {research_plan['error']}")
    
    except Exception as e:
        print(f"⚠️ Research plan transformation failed: {e}")
    
    # Execute basic research using the insights
    print("\n🔍 Executing research based on cognitive insights...")
    try:
        research_results = research_combined_search(
            "cryptocurrency market trends analysis", 
            num_results=5
        )
        
        if "error" not in research_results:
            search_results = research_results.get("search_results", [])
            print(f"✅ Research completed: {len(search_results)} sources found")
            
            # Show research summary
            for i, result in enumerate(search_results[:3]):
                print(f"  📰 Source {i+1}: {result.get('title', 'No title')}")
        else:
            print(f"⚠️ Research failed: {research_results['error']}")
    
    except Exception as e:
        print(f"⚠️ Research execution failed: {e}")
    
    return {
        "cognitive_analysis": final_results,
        "research_results": research_results if 'research_results' in locals() else None,
        "research_plan": research_plan if 'research_plan' in locals() else None
    }

def main():
    """Main entry point - handles existing event loops"""
    print("🚀 Cryptocurrency Cognitive Analysis Framework")
    print("=" * 60)
    
    try:
        # Check if event loop is already running
        try:
            loop = asyncio.get_running_loop()
            print("⚠️ Event loop already running, creating task...")
            # If we're in a running loop, create a task
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, analyze_crypto_with_cognition())
                result = future.result(timeout=300)  # 5 minute timeout
        except RuntimeError:
            # No event loop running, safe to use asyncio.run()
            print("✅ Creating new event loop...")
            result = asyncio.run(analyze_crypto_with_cognition())
        
        if result:
            print("\n🎉 Analysis completed successfully!")
            
            # Save results to file
            import json
            output_file = "crypto_cognitive_analysis.json"
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, default=str)
            
            print(f"📁 Results saved to: {output_file}")
        else:
            print("\n❌ Analysis failed!")
    
    except Exception as e:
        print(f"\n💥 Fatal error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()