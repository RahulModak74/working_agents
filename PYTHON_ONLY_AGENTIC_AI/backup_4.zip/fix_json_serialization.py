#!/usr/bin/env python3
"""
Quick fix for JSON serialization issue in smart_auto_download_workflow.py
"""

import json
from datetime import datetime
from pathlib import Path

def safe_json_serialize(obj):
    """Safely serialize objects to JSON, handling non-serializable types"""
    
    def convert_obj(item):
        """Convert problematic objects to serializable format"""
        
        # Handle common non-serializable types
        if hasattr(item, '__class__'):
            class_name = item.__class__.__name__
            
            # Exception objects
            if 'Error' in class_name or 'Exception' in class_name:
                return {
                    "type": "exception", 
                    "class": class_name,
                    "message": str(item)
                }
            
            # HTTP Response objects
            if hasattr(item, 'status_code') and hasattr(item, 'text'):
                return {
                    "type": "http_response",
                    "status_code": getattr(item, 'status_code', None),
                    "text": str(item)[:200] + "..." if len(str(item)) > 200 else str(item)
                }
            
            # Other complex objects
            if not isinstance(item, (str, int, float, bool, list, dict, type(None))):
                return {
                    "type": "object",
                    "class": class_name,
                    "repr": str(item)[:200] + "..." if len(str(item)) > 200 else str(item)
                }
        
        # Handle collections
        if isinstance(item, dict):
            return {k: convert_obj(v) for k, v in item.items()}
        elif isinstance(item, (list, tuple)):
            return [convert_obj(i) for i in item]
        
        # Return as-is for serializable types
        return item
    
    return json.dumps(convert_obj(obj), indent=2, default=str)

def fix_stage_5_llm_final_analysis(self, execution_results):
    """Fixed version of stage_5_llm_final_analysis method"""
    
    self.log("\n📊 STAGE 5: LLM Final Analysis")
    print("=" * 60)
    
    # Prepare execution summary for LLM with safe serialization
    execution_summary = {
        "use_case": self.use_case,
        "tools_downloaded": len(self.results.get("downloaded_tools", {})),
        "new_tools_added": len(self.results.get("new_tools", [])),
        "workflow_steps_executed": len(execution_results),
        "successful_steps": sum(1 for step in execution_results if step["success"]),
        "execution_results": self._sanitize_execution_results(execution_results[:3])  # First 3 for LLM analysis
    }
    
    # Create the prompt with safe JSON serialization
    try:
        serialized_summary = safe_json_serialize(execution_summary)
    except Exception as e:
        self.log(f"⚠️ JSON serialization still failing: {e}")
        # Fallback: create a simple summary
        serialized_summary = json.dumps({
            "use_case": self.use_case,
            "tools_downloaded": execution_summary["tools_downloaded"],
            "new_tools_added": execution_summary["new_tools_added"], 
            "workflow_steps_executed": execution_summary["workflow_steps_executed"],
            "successful_steps": execution_summary["successful_steps"],
            "note": "Detailed execution results omitted due to serialization complexity"
        }, indent=2)
    
    final_analysis_prompt = f"""
Analyze the results of this auto-download workflow execution:

{serialized_summary}

Provide insights on:
1. How well the auto-downloaded tools worked
2. What was accomplished vs. the original use case
3. Recommendations for improvement
4. Value of the auto-download approach
5. Next steps for better results

Format as JSON:
{{
  "effectiveness_score": "1-10",
  "auto_download_value": "assessment of auto-download approach",
  "accomplishments": ["what was achieved"],
  "limitations": ["what didn't work well"],
  "recommendations": ["specific improvements"],
  "next_steps": ["actionable next steps"]
}}
"""
    
    # Continue with the rest of the original method...
    # (The LLM call and parsing logic remains the same)

def add_sanitize_method_to_workflow():
    """Method to add to SmartAutoDownloadWorkflow class"""
    
    def _sanitize_execution_results(self, execution_results):
        """Sanitize execution results for JSON serialization"""
        
        sanitized = []
        
        for step in execution_results:
            sanitized_step = {
                "step": step.get("step"),
                "action": step.get("action"),
                "tools_attempted": step.get("tools_attempted", []),
                "success": step.get("success", False),
                "results": {}
            }
            
            # Sanitize tool results
            for tool_name, result in step.get("results", {}).items():
                if isinstance(result, dict):
                    sanitized_result = {}
                    for k, v in result.items():
                        # Convert non-serializable values
                        if hasattr(v, '__class__') and 'Error' in v.__class__.__name__:
                            sanitized_result[k] = {
                                "type": "exception",
                                "class": v.__class__.__name__,
                                "message": str(v)
                            }
                        else:
                            try:
                                json.dumps(v)  # Test if serializable
                                sanitized_result[k] = v
                            except TypeError:
                                sanitized_result[k] = str(v)
                    
                    sanitized_step["results"][tool_name] = sanitized_result
                else:
                    sanitized_step["results"][tool_name] = str(result)
            
            sanitized.append(sanitized_step)
        
        return sanitized
    
    return _sanitize_execution_results

# Quick patch script
def apply_quick_fix():
    """Apply the quick fix to smart_auto_download_workflow.py"""
    
    workflow_file = Path("smart_auto_download_workflow.py")
    
    if not workflow_file.exists():
        print("❌ smart_auto_download_workflow.py not found")
        return False
    
    print("🔧 Applying JSON serialization fix...")
    
    # Read the original file
    with open(workflow_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Add the sanitize method to the class
    sanitize_method = '''
    def _sanitize_execution_results(self, execution_results):
        """Sanitize execution results for JSON serialization"""
        
        sanitized = []
        
        for step in execution_results:
            sanitized_step = {
                "step": step.get("step"),
                "action": step.get("action"),
                "tools_attempted": step.get("tools_attempted", []),
                "success": step.get("success", False),
                "results": {}
            }
            
            # Sanitize tool results
            for tool_name, result in step.get("results", {}).items():
                if isinstance(result, dict):
                    sanitized_result = {}
                    for k, v in result.items():
                        # Convert non-serializable values
                        if hasattr(v, '__class__') and 'Error' in v.__class__.__name__:
                            sanitized_result[k] = {
                                "type": "exception",
                                "class": v.__class__.__name__,
                                "message": str(v)
                            }
                        else:
                            try:
                                json.dumps(v)  # Test if serializable
                                sanitized_result[k] = v
                            except TypeError:
                                sanitized_result[k] = str(v)
                    
                    sanitized_step["results"][tool_name] = sanitized_result
                else:
                    sanitized_step["results"][tool_name] = str(result)
            
            sanitized.append(sanitized_step)
        
        return sanitized
'''
    
    # Find where to insert the method (before the run_complete_workflow method)
    insertion_point = content.find("    async def run_complete_workflow(self):")
    
    if insertion_point == -1:
        print("❌ Could not find insertion point")
        return False
    
    # Insert the sanitize method
    new_content = (content[:insertion_point] + 
                   sanitize_method + "\n" + 
                   content[insertion_point:])
    
    # Fix the problematic line in stage_5_llm_final_analysis
    old_line = '"execution_results": execution_results[:3]  # First 3 for LLM analysis'
    new_line = '"execution_results": self._sanitize_execution_results(execution_results[:3])  # First 3 for LLM analysis'
    
    new_content = new_content.replace(old_line, new_line)
    
    # Backup original file
    backup_file = Path("smart_auto_download_workflow_backup.py")
    with open(backup_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Write the fixed file
    with open(workflow_file, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ JSON serialization fix applied!")
    print(f"📁 Original backed up to: {backup_file}")
    print("\n🚀 Now run: python smart_auto_download_workflow.py")
    
    return True

if __name__ == "__main__":
    apply_quick_fix()