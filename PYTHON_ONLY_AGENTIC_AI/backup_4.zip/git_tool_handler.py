#!/usr/bin/env python3
"""
Git Tool Handler
Handles GitHub repository cloning, Python file extraction, and tool integration
"""

import os
import sys
import subprocess
import tempfile
import shutil
import requests
import zipfile
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging
import re

logger = logging.getLogger("git_tool_handler")

class GitToolHandler:
    """Handle GitHub repository downloads and Python file extraction"""
    
    def __init__(self, component_dir: Path):
        self.component_dir = Path(component_dir)
        self.component_dir.mkdir(exist_ok=True)
        
        # Check if git is available
        self.git_available = self._check_git_available()
        
    def _check_git_available(self) -> bool:
        """Check if git command is available"""
        try:
            subprocess.run(["git", "--version"], 
                         capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            logger.warning("Git not available, will use download method")
            return False
    
    def download_github_repo(self, repo: str) -> Dict[str, Any]:
        """
        Download GitHub repository using multiple fallback methods
        
        Args:
            repo: GitHub repository in format "user/repository"
            
        Returns:
            Dict with download results and extracted Python files
        """
        
        # Validate repo format
        if not self._is_valid_repo_format(repo):
            return {"error": f"Invalid repository format: {repo}. Use 'user/repository'"}
        
        # Try multiple download methods
        methods = [
            ("git_clone", self._download_via_git_clone),
            ("zip_download", self._download_via_zip),
            ("api_download", self._download_via_github_api)
        ]
        
        for method_name, method_func in methods:
            logger.info(f"Trying {method_name} for {repo}")
            
            try:
                result = method_func(repo)
                if result.get("status") == "success":
                    logger.info(f"Successfully downloaded {repo} via {method_name}")
                    return result
                else:
                    logger.warning(f"{method_name} failed: {result.get('error', 'Unknown error')}")
            except Exception as e:
                logger.error(f"{method_name} exception: {str(e)}")
        
        return {"error": f"All download methods failed for {repo}"}
    
    def _download_via_git_clone(self, repo: str) -> Dict[str, Any]:
        """Download using git clone"""
        if not self.git_available:
            return {"error": "Git not available"}
        
        with tempfile.TemporaryDirectory() as temp_dir:
            clone_path = Path(temp_dir) / "repo"
            
            # Git clone command
            cmd = ["git", "clone", f"https://github.com/{repo}.git", str(clone_path)]
            
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                
                if result.returncode != 0:
                    return {"error": f"Git clone failed: {result.stderr}"}
                
                # Extract Python files
                extraction_result = self._extract_python_files(clone_path, repo)
                extraction_result["method"] = "git_clone"
                extraction_result["status"] = "success"
                
                return extraction_result
                
            except subprocess.TimeoutExpired:
                return {"error": "Git clone timed out"}
            except Exception as e:
                return {"error": f"Git clone exception: {str(e)}"}
    
    def _download_via_zip(self, repo: str) -> Dict[str, Any]:
        """Download using GitHub's ZIP archive"""
        
        # Try different branch names
        branches = ["main", "master", "develop"]
        
        for branch in branches:
            url = f"https://github.com/{repo}/archive/refs/heads/{branch}.zip"
            
            try:
                response = requests.get(url, timeout=30, stream=True)
                
                if response.status_code == 200:
                    return self._process_zip_download(response, repo, branch)
                
            except requests.RequestException as e:
                logger.warning(f"ZIP download failed for {repo}/{branch}: {str(e)}")
                continue
        
        return {"error": f"ZIP download failed for all branches: {branches}"}
    
    def _download_via_github_api(self, repo: str) -> Dict[str, Any]:
        """Download using GitHub API (for small repos)"""
        
        try:
            # Get repository info
            api_url = f"https://api.github.com/repos/{repo}"
            response = requests.get(api_url, timeout=10)
            
            if response.status_code != 200:
                return {"error": f"GitHub API failed: {response.status_code}"}
            
            repo_info = response.json()
            default_branch = repo_info.get("default_branch", "main")
            
            # Download ZIP using API info
            zip_url = f"https://github.com/{repo}/archive/refs/heads/{default_branch}.zip"
            zip_response = requests.get(zip_url, timeout=30, stream=True)
            
            if zip_response.status_code == 200:
                return self._process_zip_download(zip_response, repo, default_branch)
            else:
                return {"error": f"API ZIP download failed: {zip_response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"GitHub API download failed: {str(e)}"}
    
    def _process_zip_download(self, response: requests.Response, repo: str, branch: str) -> Dict[str, Any]:
        """Process downloaded ZIP file"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            zip_path = Path(temp_dir) / "repo.zip"
            
            # Save ZIP file
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Extract ZIP
            extract_path = Path(temp_dir) / "extracted"
            extract_path.mkdir()
            
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
            
            # Find the extracted repository folder
            extracted_folders = list(extract_path.iterdir())
            if not extracted_folders:
                return {"error": "No folders found in ZIP"}
            
            repo_folder = extracted_folders[0]  # Usually named like "repo-branch"
            
            # Extract Python files
            extraction_result = self._extract_python_files(repo_folder, repo)
            extraction_result["method"] = "zip_download"
            extraction_result["branch"] = branch
            extraction_result["status"] = "success"
            
            return extraction_result
    
    def _extract_python_files(self, repo_path: Path, repo: str) -> Dict[str, Any]:
        """Extract Python files from downloaded repository"""
        
        try:
            # Find all Python files
            python_files = list(repo_path.rglob("*.py"))
            
            if not python_files:
                return {"error": "No Python files found in repository"}
            
            # Filter and copy relevant Python files
            copied_files = []
            skipped_files = []
            
            for py_file in python_files:
                if self._should_copy_file(py_file):
                    dest_name = self._generate_destination_name(py_file, repo)
                    dest_path = self.component_dir / dest_name
                    
                    try:
                        # Copy file with error handling
                        shutil.copy2(py_file, dest_path)
                        copied_files.append({
                            "original": str(py_file.relative_to(repo_path)),
                            "destination": dest_name,
                            "size": py_file.stat().st_size
                        })
                    except Exception as e:
                        skipped_files.append({
                            "file": str(py_file.relative_to(repo_path)),
                            "error": str(e)
                        })
                else:
                    skipped_files.append({
                        "file": str(py_file.relative_to(repo_path)),
                        "reason": "not_tool_related"
                    })
            
            return {
                "repo": repo,
                "total_python_files": len(python_files),
                "copied_files": copied_files,
                "skipped_files": skipped_files,
                "files_copied_count": len(copied_files)
            }
            
        except Exception as e:
            return {"error": f"Python file extraction failed: {str(e)}"}
    
    def _should_copy_file(self, py_file: Path) -> bool:
        """Determine if a Python file should be copied"""
        
        # Skip test files
        if any(part in py_file.parts for part in ["test", "tests", "__pycache__"]):
            return False
        
        # Skip files that are too small (likely empty)
        try:
            if py_file.stat().st_size < 100:
                return False
        except:
            return False
        
        # Check file content for tool indicators
        return self._is_tool_file(py_file)
    
    def _is_tool_file(self, py_file: Path) -> bool:
        """Check if Python file looks like a tool"""
        try:
            with open(py_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Look for tool indicators
            tool_indicators = [
                "TOOL_REGISTRY",
                "TOOL_NAMESPACE",
                "def.*\\*\\*kwargs",  # Functions with **kwargs
                "adapter",
                "tool",
                "import.*requests",  # Common in API tools
                "import.*json",      # Common in data tools
                "class.*Tool",       # Tool classes
                "class.*API",        # API classes
                "def.*api",          # API functions
            ]
            
            # Check for indicators
            indicator_count = sum(1 for indicator in tool_indicators 
                                if re.search(indicator, content, re.IGNORECASE))
            
            # Also check for function definitions (basic utility)
            function_count = len(re.findall(r'^def\s+\w+', content, re.MULTILINE))
            
            # Consider it a tool file if it has tool indicators or multiple functions
            return indicator_count > 0 or function_count >= 2
            
        except Exception as e:
            logger.warning(f"Could not analyze file {py_file}: {e}")
            return False
    
    def _generate_destination_name(self, py_file: Path, repo: str) -> str:
        """Generate a unique destination filename"""
        
        # Clean repo name
        repo_clean = repo.replace("/", "_").replace("-", "_")
        
        # Get relative path from repo root
        file_parts = py_file.parts
        
        # Create a meaningful name
        if len(file_parts) > 1:
            # Include directory structure in name
            path_part = "_".join(file_parts[-2:]).replace("-", "_")
            dest_name = f"{repo_clean}_{path_part}"
        else:
            dest_name = f"{repo_clean}_{py_file.name}"
        
        # Ensure .py extension
        if not dest_name.endswith('.py'):
            dest_name += '.py'
        
        # Handle name conflicts
        counter = 1
        original_dest = dest_name
        while (self.component_dir / dest_name).exists():
            name_part = original_dest[:-3]  # Remove .py
            dest_name = f"{name_part}_{counter}.py"
            counter += 1
        
        return dest_name
    
    def _is_valid_repo_format(self, repo: str) -> bool:
        """Validate GitHub repository format"""
        pattern = r'^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$'
        return bool(re.match(pattern, repo))
    
    def get_repo_info(self, repo: str) -> Dict[str, Any]:
        """Get information about a GitHub repository"""
        
        if not self._is_valid_repo_format(repo):
            return {"error": "Invalid repository format"}
        
        try:
            api_url = f"https://api.github.com/repos/{repo}"
            response = requests.get(api_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "name": data["full_name"],
                    "description": data.get("description", ""),
                    "stars": data["stargazers_count"],
                    "forks": data["forks_count"],
                    "language": data.get("language", ""),
                    "default_branch": data.get("default_branch", "main"),
                    "size": data["size"],
                    "created_at": data["created_at"],
                    "updated_at": data["updated_at"],
                    "url": data["html_url"]
                }
            else:
                return {"error": f"Repository not found or API error: {response.status_code}"}
                
        except requests.RequestException as e:
            return {"error": f"Failed to get repository info: {str(e)}"}


# Test function
def test_git_handler():
    """Test the GitToolHandler with a simple repository"""
    
    # Create test component directory
    test_component_dir = Path("test_component")
    test_component_dir.mkdir(exist_ok=True)
    
    handler = GitToolHandler(test_component_dir)
    
    # Test with a simple Python repository
    test_repo = "requests/requests"  # Well-known repository
    
    print(f"Testing download of {test_repo}...")
    result = handler.download_github_repo(test_repo)
    
    print(f"Result: {result}")
    
    # Cleanup
    if test_component_dir.exists():
        shutil.rmtree(test_component_dir)


if __name__ == "__main__":
    test_git_handler()