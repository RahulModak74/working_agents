#!/usr/bin/env python3
"""
Direct Tool Usage - Simple Python Solution
No workflows, just import tools and solve problems directly!
"""

import sys
import os
from pathlib import Path

# Add COMPONENT directory to path
component_dir = Path(__file__).parent / "COMPONENT"
if component_dir.exists():
    sys.path.insert(0, str(component_dir))

# Import all tools directly
try:
    # Browser tools
    from browser_adapter import (
        browser_create, browser_navigate, browser_get_content,
        browser_find_elements, browser_click, browser_close
    )
    
    # Research tools  
    from research_adapter import (
        research_combined_search, research_analyze_content,
        research_generate_summary, research_fetch_content
    )
    
    # Citation tools
    from cite_adapter import cite_sources, cite_source
    
    # Vector DB tools
    from vector_db_adapter import (
        vector_db_search, vector_db_add, vector_db_batch_add
    )
    
    # ML tools
    from ml_adapter import (
        ml_train_model, ml_predict, ml_evaluate_model
    )
    
    # Planning tools
    from planning_adapter import (
        planning_create_plan, planning_chain_of_thought
    )
    
    # Memory tools
    from memory_adapter import (
        memory_create_system, memory_store_operation
    )
    
    print("✅ All tools imported successfully!")
    
except ImportError as e:
    print(f"⚠️ Some tools not available: {e}")

# SOLUTION 1: Options Trading Research
def research_options_trading_platforms():
    """Direct solution - research options trading platforms"""
    
    print("🔍 Researching options trading platforms...")
    
    # Step 1: Research with multiple queries
    queries = [
        "best options trading platforms 2024",
        "algorithmic options trading software",
        "options trading education platforms"
    ]
    
    all_results = []
    for query in queries:
        print(f"Searching: {query}")
        result = research_combined_search(query=query, num_results=5)
        if "error" not in result:
            all_results.extend(result.get("search_results", []))
    
    # Step 2: Analyze the content
    combined_content = " ".join([r.get("content", "") for r in all_results])
    analysis = research_analyze_content(content=combined_content, max_length=3000)
    
    # Step 3: Generate summary
    summary = research_generate_summary(
        results={"content": combined_content},
        query="options trading platforms comparison"
    )
    
    # Step 4: Create citations
    sources = [{"url": r.get("url"), "title": r.get("title")} for r in all_results if r.get("url")]
    citations = cite_sources(sources=sources, style="apa")
    
    return {
        "platforms_found": len(all_results),
        "analysis": analysis,
        "summary": summary,
        "citations": citations,
        "raw_results": all_results
    }

# SOLUTION 2: Automated Web Data Collection
def collect_financial_data_with_browser():
    """Direct solution - collect financial data using browser automation"""
    
    print("🌐 Collecting financial data with browser...")
    
    # Step 1: Create browser
    browser_result = browser_create(browser_id="finance", headless=True)
    if "error" in browser_result:
        return {"error": "Failed to create browser"}
    
    financial_data = []
    
    # Step 2: Visit multiple financial sites
    sites = [
        "https://finance.yahoo.com/quote/SPY/options",
        "https://www.cboe.com/tradeable_products/sp_500/spx_options/",
        "https://www.nasdaq.com/market-activity/options"
    ]
    
    for site in sites:
        print(f"Visiting: {site}")
        
        # Navigate
        nav = browser_navigate(url=site, browser_id="finance")
        if "error" in nav:
            continue
            
        # Get content
        content = browser_get_content(browser_id="finance", content_type="text")
        if "error" not in content:
            # Analyze the content
            analysis = research_analyze_content(content=content["content"][:2000])
            
            financial_data.append({
                "site": site,
                "title": nav.get("title", ""),
                "content_length": len(content["content"]),
                "analysis": analysis
            })
    
    # Step 3: Cleanup
    browser_close(browser_id="finance")
    
    return {
        "sites_visited": len(financial_data),
        "data_collected": financial_data,
        "total_content": sum(d["content_length"] for d in financial_data)
    }

# SOLUTION 3: ML-Powered Content Analysis
def analyze_content_with_ml():
    """Direct solution - use ML to analyze collected content"""
    
    print("🤖 Analyzing content with machine learning...")
    
    # Step 1: Collect research data
    research = research_combined_search(
        query="machine learning trading strategies", 
        num_results=10
    )
    
    if "error" in research:
        return {"error": "Research failed"}
    
    # Step 2: Prepare data for ML
    texts = []
    labels = []
    
    for result in research["search_results"]:
        content = result.get("content", "")
        if content:
            texts.append(content[:500])  # Truncate for demo
            # Simple labeling based on keywords
            if any(word in content.lower() for word in ["education", "learning", "course"]):
                labels.append("educational")
            elif any(word in content.lower() for word in ["algorithm", "quant", "technical"]):
                labels.append("technical")
            else:
                labels.append("general")
    
    # Step 3: Store in vector database for semantic search
    if texts:
        vector_result = vector_db_batch_add(
            collection="ml_analysis",
            texts=texts,
            metadatas=[{"label": label} for label in labels]
        )
        
        # Step 4: Semantic search
        if "error" not in vector_result:
            search_result = vector_db_search(
                collection="ml_analysis",
                query="educational trading strategies",
                top_k=5
            )
            
            return {
                "texts_processed": len(texts),
                "vector_storage": vector_result,
                "semantic_search": search_result,
                "label_distribution": {label: labels.count(label) for label in set(labels)}
            }
    
    return {"error": "No content to process"}

# SOLUTION 4: Complete Intelligence Pipeline
def complete_intelligence_pipeline(topic="options trading education"):
    """Complete solution combining all tools"""
    
    print(f"🎯 Running complete intelligence pipeline for: {topic}")
    
    results = {}
    
    # Phase 1: Research
    print("Phase 1: Research")
    research = research_combined_search(query=topic, num_results=15)
    results["research"] = research
    
    # Phase 2: Web collection
    print("Phase 2: Web data collection")
    if "error" not in research:
        # Get top URLs
        urls = [r["url"] for r in research["search_results"][:3] if r.get("url")]
        
        # Create browser and visit sites
        browser_create(browser_id="pipeline")
        web_data = []
        
        for url in urls:
            nav = browser_navigate(url=url, browser_id="pipeline")
            if "error" not in nav:
                content = browser_get_content(browser_id="pipeline")
                if "error" not in content:
                    web_data.append({
                        "url": url,
                        "title": nav["title"],
                        "content": content["content"][:1000]
                    })
        
        browser_close(browser_id="pipeline")
        results["web_collection"] = web_data
    
    # Phase 3: Analysis
    print("Phase 3: Content analysis")
    all_content = ""
    if "web_collection" in results:
        all_content = " ".join([d["content"] for d in results["web_collection"]])
    
    if all_content:
        analysis = research_analyze_content(content=all_content)
        summary = research_generate_summary(
            results={"content": all_content},
            query=topic
        )
        results["analysis"] = analysis
        results["summary"] = summary
    
    # Phase 4: Knowledge storage
    print("Phase 4: Knowledge storage")
    if all_content:
        vector_db_add(
            collection="intelligence_pipeline",
            text=all_content,
            metadata={"topic": topic, "timestamp": str(Path(__file__).stat().st_mtime)}
        )
    
    # Phase 5: Planning
    print("Phase 5: Strategic planning")
    plan = planning_create_plan(
        name=f"{topic}_strategy",
        goal=f"Develop comprehensive understanding of {topic}",
        subtasks=[
            "Market analysis",
            "Technology assessment", 
            "Educational framework design",
            "Implementation roadmap"
        ]
    )
    results["strategic_plan"] = plan
    
    return results

# Main execution
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Direct Tool Usage Solutions")
    parser.add_argument("--solution", 
                       choices=["research", "browser", "ml", "complete"],
                       default="complete",
                       help="Which solution to run")
    parser.add_argument("--topic", default="options trading education",
                       help="Topic for research (for complete solution)")
    
    args = parser.parse_args()
    
    print("🚀 Running direct tool solution...")
    
    if args.solution == "research":
        result = research_options_trading_platforms()
    elif args.solution == "browser":
        result = collect_financial_data_with_browser()
    elif args.solution == "ml":
        result = analyze_content_with_ml()
    else:
        result = complete_intelligence_pipeline(args.topic)
    
    # Save results
    import json
    output_file = f"{args.solution}_solution_results.json"
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2, default=str)
    
    print(f"✅ Solution completed!")
    print(f"📁 Results saved to: {output_file}")
    
    # Print summary
    if isinstance(result, dict) and "error" not in result:
        print(f"📊 Success! Processed data and generated insights.")
    else:
        print(f"❌ Some issues occurred: {result}")