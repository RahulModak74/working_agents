#!/usr/bin/env python3

import os
import sys
import json
import time
import logging
import requests
import urllib.parse
import re
import hashlib
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("research_adapter")

# IMPORTANT: Add tool namespace
TOOL_NAMESPACE = "research"

# Try to import BeautifulSoup for HTML parsing
try:
    from bs4 import BeautifulSoup
    BEAUTIFULSOUP_AVAILABLE = True
except ImportError:
    BEAUTIFULSOUP_AVAILABLE = False
    logger.warning("BeautifulSoup not available. Install with 'pip install beautifulsoup4' for better HTML parsing")

# Configuration
class ResearchConfig:
    def __init__(self):
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        self.cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "research_cache")
        self.cache_ttl = 86400  # 24 hours in seconds
        self.request_timeout = 15  # seconds
        self.max_results = 10
        self.serper_api_key = os.environ.get("SERPER_API_KEY", "")
        self.bing_api_key = os.environ.get("BING_API_KEY", "")
        self.search_engine = "duckduckgo"  # Default to free option
        
        # Create cache directory if it doesn't exist
        os.makedirs(self.cache_dir, exist_ok=True)

# Global configuration
RESEARCH_CONFIG = ResearchConfig()

class ResearchManager:
    def __init__(self, config=None):
        self.config = config or RESEARCH_CONFIG
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.config.user_agent})
    
    def search(self, query: str, num_results: int = 5) -> Dict[str, Any]:
        """Perform a web search using the configured search engine"""
        if self.config.serper_api_key and self.config.search_engine == "serper":
            return self._search_serper(query, num_results)
        elif self.config.bing_api_key and self.config.search_engine == "bing":
            return self._search_bing(query, num_results)
        else:
            return self._search_duckduckgo(query, num_results)
    
    def _search_duckduckgo(self, query: str, num_results: int) -> Dict[str, Any]:
        """Search using DuckDuckGo (no API key required) - FIXED"""
        # Check cache first
        cache_key = f"ddg_{hashlib.md5(query.encode()).hexdigest()}"
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            return cached_result
        
        try:
            # Use DuckDuckGo instant answer API (free)
            url = "https://api.duckduckgo.com/"
            params = {
                'q': query,
                'format': 'json',
                'no_html': '1',
                'skip_disambig': '1'
            }
            
            response = requests.get(url, params=params, timeout=self.config.request_timeout)
            response.raise_for_status()
            data = response.json()
            
            results = []
            
            # Try to get instant answer
            if data.get('Abstract'):
                results.append({
                    'title': data.get('AbstractText', 'DuckDuckGo Result'),
                    'link': data.get('AbstractURL', ''),
                    'snippet': data.get('Abstract', ''),
                    'source': 'DuckDuckGo Instant Answer',
                    'position': 1
                })
            
            # Get related topics
            if data.get('RelatedTopics'):
                for i, topic in enumerate(data.get('RelatedTopics', [])[:num_results-1]):
                    if isinstance(topic, dict) and topic.get('Text'):
                        results.append({
                            'title': topic.get('Text', '')[:100],
                            'link': topic.get('FirstURL', ''),
                            'snippet': topic.get('Text', ''),
                            'source': 'DuckDuckGo Related',
                            'position': i + 2
                        })
            
            # If no results, create a basic search result
            if not results:
                # Fallback: use simple web search approach
                search_url = f"https://duckduckgo.com/html/?q={urllib.parse.quote(query)}"
                try:
                    response = requests.get(search_url, headers={'User-Agent': self.config.user_agent}, timeout=10)
                    if BEAUTIFULSOUP_AVAILABLE and response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        search_results = soup.find_all('div', class_='result')[:num_results]
                        
                        for i, result_div in enumerate(search_results):
                            title_elem = result_div.find('a', class_='result__a')
                            snippet_elem = result_div.find('a', class_='result__snippet')
                            
                            if title_elem:
                                results.append({
                                    'title': title_elem.get_text(strip=True),
                                    'link': title_elem.get('href', ''),
                                    'snippet': snippet_elem.get_text(strip=True) if snippet_elem else '',
                                    'source': 'DuckDuckGo Search',
                                    'position': i + 1
                                })
                except:
                    pass
            
            # Final fallback
            if not results:
                results = [{
                    'title': f"Search results for: {query}",
                    'link': f"https://duckduckgo.com/?q={urllib.parse.quote(query)}",
                    'snippet': f"Search performed for '{query}'. Use fetch_content to get detailed information from specific URLs.",
                    'source': 'DuckDuckGo',
                    'position': 1
                }]
            
            result = {
                'status': 'success',
                'query': query,
                'num_results': len(results),
                'results': results
            }
            
            # Cache the result
            self._save_to_cache(cache_key, result)
            
            return result
        
        except Exception as e:
            logger.error(f"Error with DuckDuckGo search: {str(e)}")
            return {
                'status': 'error',
                'error': str(e),
                'query': query,
                'results': []
            }
    
    def _search_serper(self, query: str, num_results: int) -> Dict[str, Any]:
        """Search using Serper.dev API"""
        if not self.config.serper_api_key:
            return self._search_duckduckgo(query, num_results)
            
        cache_key = f"serper_{hashlib.md5(query.encode()).hexdigest()}"
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            return cached_result
        
        try:
            url = "https://google.serper.dev/search"
            headers = {
                'X-API-KEY': self.config.serper_api_key,
                'Content-Type': 'application/json'
            }
            payload = {
                'q': query,
                'num': min(num_results, self.config.max_results)
            }
            
            response = requests.post(url, headers=headers, json=payload, timeout=self.config.request_timeout)
            response.raise_for_status()
            data = response.json()
            
            results = []
            if 'organic' in data:
                for item in data['organic'][:num_results]:
                    results.append({
                        'title': item.get('title', ''),
                        'link': item.get('link', ''),
                        'snippet': item.get('snippet', ''),
                        'source': 'Google (via Serper.dev)',
                        'position': item.get('position', 0)
                    })
            
            result = {
                'status': 'success',
                'query': query,
                'num_results': len(results),
                'results': results
            }
            
            self._save_to_cache(cache_key, result)
            return result
        
        except Exception as e:
            logger.error(f"Error with Serper search: {str(e)}")
            return self._search_duckduckgo(query, num_results)  # Fallback
    
    def fetch_content(self, url: str, format: str = 'text') -> Dict[str, Any]:
        """Fetch and extract content from a URL - FIXED"""
        cache_key = f"content_{hashlib.md5(url.encode()).hexdigest()}"
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            if 'content' in cached_result and len(cached_result['content']) > 50000:
                cached_result['content'] = cached_result['content'][:50000] + '... [content truncated]'
            return cached_result
        
        try:
            # Fix URL if needed
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            headers = {'User-Agent': self.config.user_agent}
            response = requests.get(url, headers=headers, timeout=self.config.request_timeout)
            response.raise_for_status()
            
            content_type = response.headers.get('Content-Type', '')
            
            # Handle non-HTML content
            if 'text/html' not in content_type and 'application/xhtml+xml' not in content_type:
                return {
                    'status': 'success',
                    'url': url,
                    'title': os.path.basename(url),
                    'content_type': content_type,
                    'content': response.text[:50000] + ('...' if len(response.text) > 50000 else ''),
                    'content_format': 'text'
                }
            
            # Parse HTML content
            if BEAUTIFULSOUP_AVAILABLE:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Remove unwanted elements
                for script in soup(["script", "style", "iframe", "noscript", "nav", "header", "footer", "aside"]):
                    script.decompose()
                
                title = soup.title.string.strip() if soup.title else os.path.basename(url)
                
                if format == 'html':
                    # Return cleaned HTML
                    main_content = soup.find('main') or soup.find('article') or soup.find('div', {'id': 'content'}) or soup.body
                    content = str(main_content) if main_content else str(soup.body)
                    content_format = 'html'
                else:
                    # Extract clean text
                    main_content = soup.find('main') or soup.find('article') or soup.find('div', {'id': 'content'}) or soup.body
                    
                    if main_content:
                        text = main_content.get_text(separator=' ', strip=True)
                    else:
                        text = soup.get_text(separator=' ', strip=True)
                    
                    # Clean up text
                    text = re.sub(r'\s+', ' ', text).strip()
                    content = text
                    content_format = 'text'
                
                # Truncate if too long
                if len(content) > 50000:
                    content = content[:50000] + '... [content truncated]'
                
                result = {
                    'status': 'success',
                    'url': url,
                    'title': title,
                    'content': content,
                    'content_format': content_format,
                    'content_length': len(content)
                }
                
                self._save_to_cache(cache_key, result)
                return result
            else:
                # Fallback without BeautifulSoup
                return {
                    'status': 'success',
                    'url': url,
                    'title': url.split('/')[-1],
                    'content': response.text[:50000] + ('...' if len(response.text) > 50000 else ''),
                    'content_format': 'text',
                    'warning': 'BeautifulSoup not available for better parsing'
                }
                
        except Exception as e:
            logger.error(f"Error fetching content from {url}: {str(e)}")
            return {
                'status': 'error',
                'error': str(e),
                'url': url
            }
    
    def combined_search(self, query: str, depth: int = 1, num_results: int = 3) -> Dict[str, Any]:
        """Perform comprehensive search and fetch content - FIXED"""
        depth = min(max(depth, 1), 3)
        num_results = min(max(num_results, 1), 10)
        
        try:
            # Step 1: Search
            search_results = self.search(query, num_results)
            
            if search_results.get('status') == 'error':
                return search_results
            
            # Step 2: Fetch content from search results
            content_results = []
            
            for result in search_results.get('results', []):
                if 'link' in result and result['link']:
                    content = self.fetch_content(result['link'])
                    if content.get('status') == 'success' and 'content' in content:
                        content_results.append(content)
            
            # Step 3: Generate summary
            all_content = " ".join([c.get('content', '') for c in content_results])
            
            summary = {
                'query': query,
                'total_sources': len(content_results),
                'sources': [{'url': c.get('url'), 'title': c.get('title')} for c in content_results],
                'content_length': len(all_content),
                'key_points': self._extract_key_points(all_content)
            }
            
            return {
                'status': 'success',
                'query': query,
                'search_results': search_results.get('results', []),
                'content_results': content_results,
                'summary': summary,
                'research_depth': depth
            }
            
        except Exception as e:
            logger.error(f"Error in combined research: {str(e)}")
            return {
                'status': 'error',
                'error': str(e)
            }
    
    def _extract_key_points(self, content: str) -> List[str]:
        """Extract key points from content"""
        if not content:
            return []
        
        # Simple key point extraction
        sentences = re.split(r'[.!?]+', content)
        
        # Get sentences that might contain key information
        key_sentences = []
        keywords = ['important', 'key', 'main', 'primary', 'essential', 'significant', 'major']
        
        for sentence in sentences:
            sentence = sentence.strip()
            if (20 < len(sentence) < 200 and 
                any(keyword in sentence.lower() for keyword in keywords)):
                key_sentences.append(sentence)
        
        return key_sentences[:5]  # Return top 5
    
    def _get_from_cache(self, key: str) -> Optional[Dict[str, Any]]:
        """Retrieve from cache if not expired"""
        cache_file = os.path.join(self.config.cache_dir, f"{key}.json")
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                timestamp = data.get('_timestamp', 0)
                if time.time() - timestamp <= self.config.cache_ttl:
                    data.pop('_timestamp', None)
                    return data
            except Exception as e:
                logger.warning(f"Error reading cache: {e}")
        
        return None
    
    def _save_to_cache(self, key: str, data: Dict[str, Any]) -> bool:
        """Save to cache with timestamp"""
        cache_file = os.path.join(self.config.cache_dir, f"{key}.json")
        
        try:
            data_with_timestamp = data.copy()
            data_with_timestamp['_timestamp'] = time.time()
            
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data_with_timestamp, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            logger.warning(f"Error saving to cache: {e}")
            return False

# Global research manager
RESEARCH_MANAGER = ResearchManager()

# Tool Registry Functions - FIXED parameter handling
def research_search(query: str, num_results: int = 5, **kwargs) -> Dict[str, Any]:
    """Perform a web search using the configured search engine"""
    return RESEARCH_MANAGER.search(query, num_results)

def research_fetch_content(url: str, format: str = 'text', **kwargs) -> Dict[str, Any]:
    """Fetch and extract content from a URL"""
    return RESEARCH_MANAGER.fetch_content(url, format)

def research_combined_search(query: str, depth: int = 1, num_results: int = 3, **kwargs) -> Dict[str, Any]:
    """Perform comprehensive search and fetch content from top results"""
    return RESEARCH_MANAGER.combined_search(query, depth, num_results)

def research_analyze_content(content: str, max_length: int = 5000, **kwargs) -> Dict[str, Any]:
    """Analyze content and extract key information"""
    if not content:
        return {'status': 'error', 'error': 'No content provided'}
    
    # Truncate if needed
    if len(content) > max_length:
        content = content[:max_length] + '... [truncated]'
    
    # Basic analysis
    word_count = len(content.split())
    key_points = RESEARCH_MANAGER._extract_key_points(content)
    
    return {
        'status': 'success',
        'word_count': word_count,
        'key_points': key_points,
        'content_length': len(content)
    }

def research_stats(**kwargs) -> Dict[str, Any]:
    """Get research system statistics"""
    return {
        'search_engine': RESEARCH_CONFIG.search_engine,
        'cache_dir': RESEARCH_CONFIG.cache_dir,
        'beautifulsoup_available': BEAUTIFULSOUP_AVAILABLE,
        'serper_api_available': bool(RESEARCH_CONFIG.serper_api_key),
        'bing_api_available': bool(RESEARCH_CONFIG.bing_api_key),
        'timestamp': datetime.now().isoformat()
    }

# Register tools
TOOL_REGISTRY = {
    "search": research_search,
    "fetch_content": research_fetch_content,
    "combined_search": research_combined_search,
    "analyze_content": research_analyze_content,
    "stats": research_stats
}

logger.info(f"✅ Research tools registered: {list(TOOL_REGISTRY.keys())}")