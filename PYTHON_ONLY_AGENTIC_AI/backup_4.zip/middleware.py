#!/usr/bin/env python3
"""
Enterprise Security Middleware
Request authentication, rate limiting, and security controls
"""

import time
import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable
from functools import wraps
import re
from collections import defaultdict, deque

class SecurityMiddleware:
    """Enterprise security middleware for request processing"""
    
    def __init__(self):
        # Rate limiting
        self.rate_limits = defaultdict(lambda: deque())
        self.rate_limit_rules = {
            "default": {"requests": 100, "window": 3600},  # 100 requests per hour
            "auth": {"requests": 5, "window": 300},         # 5 auth attempts per 5 minutes
            "api": {"requests": 1000, "window": 3600},      # 1000 API calls per hour
            "admin": {"requests": 50, "window": 3600}       # 50 admin actions per hour
        }
        
        # Security settings
        self.blocked_ips = set()
        self.suspicious_patterns = [
            r"<script[^>]*>.*?</script>",  # XSS attempts
            r"union\s+select",             # SQL injection
            r"\.\.\/",                     # Path traversal
            r"exec\(",                     # Code execution
            r"eval\(",                     # Code evaluation
        ]
        
        # Session management
        self.active_sessions = {}
        self.session_timeout = 3600  # 1 hour
        
        # Failed attempt tracking
        self.failed_attempts = defaultdict(lambda: {"count": 0, "last_attempt": None})
        self.lockout_threshold = 5
        self.lockout_duration = 900  # 15 minutes
    
    def authenticate_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Authenticate incoming request"""
        
        # Extract request information
        ip_address = request_data.get("ip_address", "unknown")
        user_agent = request_data.get("user_agent", "")
        auth_token = request_data.get("auth_token")
        api_key = request_data.get("api_key")
        endpoint = request_data.get("endpoint", "/")
        
        # Check if IP is blocked
        if ip_address in self.blocked_ips:
            return {
                "authenticated": False,
                "error": "IP address blocked",
                "code": 403
            }
        
        # Check for account lockout
        if self._is_locked_out(ip_address):
            return {
                "authenticated": False,
                "error": "Account temporarily locked due to failed attempts",
                "code": 423
            }
        
        # Security pattern detection
        security_check = self._check_security_patterns(request_data)
        if not security_check["safe"]:
            self._record_failed_attempt(ip_address, "security_pattern")
            return {
                "authenticated": False,
                "error": f"Request blocked: {security_check['reason']}",
                "code": 400
            }
        
        # Authentication check
        auth_result = None
        
        if api_key:
            # API key authentication
            from enterprise.auth_handler import enterprise_auth
            auth_result = enterprise_auth.validate_api_key(api_key)
            
        elif auth_token:
            # Session token authentication
            from enterprise.auth_handler import enterprise_auth
            auth_result = enterprise_auth.validate_session(auth_token)
        
        else:
            # No authentication provided
            return {
                "authenticated": False,
                "error": "Authentication required",
                "code": 401
            }
        
        if not auth_result or not auth_result.get("valid"):
            self._record_failed_attempt(ip_address, "invalid_auth")
            return {
                "authenticated": False,
                "error": auth_result.get("error", "Invalid authentication"),
                "code": 401
            }
        
        # Rate limiting check
        rate_limit_check = self._check_rate_limit(ip_address, endpoint, auth_result)
        if not rate_limit_check["allowed"]:
            return {
                "authenticated": False,
                "error": rate_limit_check["error"],
                "code": 429
            }
        
        # Clear failed attempts on successful auth
        if ip_address in self.failed_attempts:
            del self.failed_attempts[ip_address]
        
        # Log successful authentication
        from enterprise.audit_logger import audit_logger
        audit_logger.log_event(
            event_type="request_authenticated",
            user_id=auth_result.get("user_id"),
            ip_address=ip_address,
            user_agent=user_agent,
            resource=endpoint,
            action="authenticate",
            outcome="success"
        )
        
        return {
            "authenticated": True,
            "user": auth_result.get("user"),
            "permissions": auth_result.get("permissions", []),
            "rate_limit_remaining": rate_limit_check.get("remaining", 0)
        }
    
    def _check_security_patterns(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Check for malicious patterns in request"""
        
        # Combine all request data for pattern checking
        request_str = json.dumps(request_data, default=str).lower()
        
        for pattern in self.suspicious_patterns:
            if re.search(pattern, request_str, re.IGNORECASE):
                return {
                    "safe": False,
                    "reason": f"Suspicious pattern detected: {pattern}"
                }
        
        # Check for unusual request size
        if len(request_str) > 1000000:  # 1MB limit
            return {
                "safe": False,
                "reason": "Request size too large"
            }
        
        return {"safe": True}
    
    def _check_rate_limit(self, ip_address: str, endpoint: str, 
                         auth_result: Dict[str, Any]) -> Dict[str, Any]:
        """Check rate limiting rules"""
        
        current_time = time.time()
        
        # Determine rate limit rule based on endpoint and user role
        rule_name = "default"
        
        if "/auth/" in endpoint:
            rule_name = "auth"
        elif "/api/" in endpoint:
            rule_name = "api"
        elif "/admin/" in endpoint:
            rule_name = "admin"
        
        # Get user role for more specific limits
        user_permissions = auth_result.get("permissions", [])
        if "*" in user_permissions or "super_admin" in str(user_permissions):
            # Super admins get higher limits
            rule = {"requests": self.rate_limit_rules[rule_name]["requests"] * 5, 
                   "window": self.rate_limit_rules[rule_name]["window"]}
        else:
            rule = self.rate_limit_rules[rule_name]
        
        # Create rate limit key
        rate_key = f"{ip_address}:{rule_name}"
        
        # Clean old entries
        window_start = current_time - rule["window"]
        while self.rate_limits[rate_key] and self.rate_limits[rate_key][0] < window_start:
            self.rate_limits[rate_key].popleft()
        
        # Check current count
        current_count = len(self.rate_limits[rate_key])
        
        if current_count >= rule["requests"]:
            return {
                "allowed": False,
                "error": f"Rate limit exceeded: {current_count}/{rule['requests']} requests per {rule['window']} seconds",
                "remaining": 0
            }
        
        # Add current request
        self.rate_limits[rate_key].append(current_time)
        
        return {
            "allowed": True,
            "remaining": rule["requests"] - current_count - 1
        }
    
    def _record_failed_attempt(self, ip_address: str, reason: str):
        """Record failed authentication attempt"""
        
        current_time = time.time()
        
        if ip_address in self.failed_attempts:
            self.failed_attempts[ip_address]["count"] += 1
        else:
            self.failed_attempts[ip_address]["count"] = 1
        
        self.failed_attempts[ip_address]["last_attempt"] = current_time
        
        # Check if we should block the IP
        if self.failed_attempts[ip_address]["count"] >= self.lockout_threshold:
            # Log security event
            from enterprise.audit_logger import audit_logger
            audit_logger.log_event(
                event_type="account_lockout",
                ip_address=ip_address,
                resource="authentication",
                action="lockout",
                outcome="success",
                risk_level="high",
                details={
                    "failed_attempts": self.failed_attempts[ip_address]["count"],
                    "reason": reason,
                    "lockout_duration": self.lockout_duration
                }
            )
    
    def _is_locked_out(self, ip_address: str) -> bool:
        """Check if IP address is locked out"""
        
        if ip_address not in self.failed_attempts:
            return False
        
        failed_data = self.failed_attempts[ip_address]
        
        if failed_data["count"] < self.lockout_threshold:
            return False
        
        # Check if lockout period has expired
        if failed_data["last_attempt"]:
            time_since_last = time.time() - failed_data["last_attempt"]
            if time_since_last > self.lockout_duration:
                # Clear failed attempts
                del self.failed_attempts[ip_address]
                return False
        
        return True
    
    def require_permission(self, permission: str):
        """Decorator to require specific permission for endpoint"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Get authentication context
                auth_context = kwargs.get("_auth_context")
                if not auth_context or not auth_context.get("authenticated"):
                    return {"error": "Authentication required", "code": 401}
                
                # Check permission
                user_permissions = auth_context.get("permissions", [])
                from enterprise.auth_handler import enterprise_auth
                
                if not enterprise_auth.check_permission(user_permissions, permission):
                    # Log permission denial
                    from enterprise.audit_logger import audit_logger
                    audit_logger.log_event(
                        event_type="permission_denied",
                        user_id=auth_context.get("user", {}).get("user_id"),
                        resource=func.__name__,
                        action="access_attempt",
                        outcome="failure",
                        risk_level="medium",
                        details={"required_permission": permission}
                    )
                    
                    return {"error": f"Permission denied: {permission}", "code": 403}
                
                # Log successful access
                from enterprise.audit_logger import audit_logger
                audit_logger.log_event(
                    event_type="function_access",
                    user_id=auth_context.get("user", {}).get("user_id"),
                    resource=func.__name__,
                    action="execute",
                    outcome="success",
                    details={"permission": permission}
                )
                
                return func(*args, **kwargs)
            return wrapper
        return decorator
    
    def secure_headers(self, response_headers: Dict[str, str]) -> Dict[str, str]:
        """Add security headers to response"""
        
        security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY", 
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
        }
        
        # Merge with existing headers
        response_headers.update(security_headers)
        return response_headers
    
    def validate_input(self, data: Dict[str, Any], schema: Dict[str, Any]) -> Dict[str, Any]:
        """Validate input data against schema"""
        
        errors = []
        validated_data = {}
        
        for field, rules in schema.items():
            value = data.get(field)
            
            # Required field check
            if rules.get("required", False) and value is None:
                errors.append(f"Field '{field}' is required")
                continue
            
            if value is not None:
                # Type validation
                expected_type = rules.get("type")
                if expected_type and not isinstance(value, expected_type):
                    errors.append(f"Field '{field}' must be of type {expected_type.__name__}")
                    continue
                
                # Length validation for strings
                if isinstance(value, str):
                    min_length = rules.get("min_length", 0)
                    max_length = rules.get("max_length", float('inf'))
                    
                    if len(value) < min_length:
                        errors.append(f"Field '{field}' must be at least {min_length} characters")
                        continue
                    
                    if len(value) > max_length:
                        errors.append(f"Field '{field}' must be no more than {max_length} characters")
                        continue
                
                # Pattern validation
                pattern = rules.get("pattern")
                if pattern and isinstance(value, str):
                    if not re.match(pattern, value):
                        errors.append(f"Field '{field}' does not match required pattern")
                        continue
                
                # Custom validator
                validator = rules.get("validator")
                if validator and callable(validator):
                    if not validator(value):
                        errors.append(f"Field '{field}' failed custom validation")
                        continue
                
                validated_data[field] = value
        
        if errors:
            return {"valid": False, "errors": errors}
        
        return {"valid": True, "data": validated_data}
    
    def sanitize_input(self, data: Any) -> Any:
        """Sanitize input data to prevent XSS and injection attacks"""
        
        if isinstance(data, str):
            # Remove potential XSS patterns
            data = re.sub(r'<script[^>]*>.*?</script>', '', data, flags=re.IGNORECASE | re.DOTALL)
            data = re.sub(r'javascript:', '', data, flags=re.IGNORECASE)
            data = re.sub(r'on\w+\s*=', '', data, flags=re.IGNORECASE)
            
            # Escape HTML entities
            data = data.replace('<', '&lt;').replace('