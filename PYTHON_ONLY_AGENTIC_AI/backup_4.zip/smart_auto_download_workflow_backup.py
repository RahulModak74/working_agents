#!/usr/bin/env python3
"""
Smart Auto-Download Workflow with LLM Intelligence
Use Case: Cryptocurrency Portfolio Analysis & Social Media Sentiment

This workflow demonstrates how LLM can intelligently decide what tools to download
based on requirements, then use those tools to solve complex problems.
"""

import sys
import json
import time
import asyncio
from datetime import datetime
from pathlib import Path

# Add framework to path
framework_dir = Path(__file__).parent
sys.path.insert(0, str(framework_dir))

from tool_manager import tool_manager
from llm_powered_solution import LLMAgent
from auto_tool_downloader import auto_downloader
from config import CONFIG

class SmartAutoDownloadWorkflow:
    """Workflow that intelligently downloads tools based on LLM analysis"""
    
    def __init__(self, use_case: str):
        self.use_case = use_case
        self.session_id = f"auto_download_{int(time.time())}"
        
        # LLM Agent for tool requirement analysis
        self.tool_analyst = LLMAgent(
            "ToolAnalyst",
            "You are an expert at analyzing requirements and identifying the best "
            "tools, libraries, and services needed to accomplish specific tasks. "
            "You recommend GitHub repositories, PyPI packages, and Docker containers."
        )
        
        # LLM Agent for workflow orchestration
        self.workflow_manager = LLMAgent(
            "WorkflowManager", 
            "You are a workflow orchestration expert. You design and execute "
            "multi-step processes using available tools effectively."
        )
        
        self.results = {
            "use_case": use_case,
            "session_id": self.session_id,
            "initial_tools": [],
            "downloaded_tools": {},
            "workflow_steps": [],
            "final_analysis": {},
            "execution_log": []
        }
        
        # Log initial tool count
        initial_tool_count = tool_manager.discover_tools()
        self.results["initial_tools"] = tool_manager.get_all_tools()
        self.log(f"Starting with {initial_tool_count} tools")
    
    def log(self, message: str):
        """Log workflow progress"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        print(log_entry)
        self.results["execution_log"].append(log_entry)
    
    async def stage_1_llm_analyzes_requirements(self):
        """Stage 1: LLM analyzes what tools are needed"""
        self.log("🧠 STAGE 1: LLM Requirement Analysis")
        print("=" * 60)
        
        requirement_analysis_prompt = f"""
Analyze this use case and determine what specific tools would be needed:

USE CASE: {self.use_case}

I need you to identify:

1. **GitHub Repositories** (for specialized tools/adapters):
   - Cryptocurrency APIs (e.g., CoinGecko, Binance)
   - Social media scrapers (Twitter, Reddit sentiment)
   - Technical analysis libraries
   - Portfolio management tools

2. **PyPI Packages** (for Python libraries):
   - Data analysis and visualization
   - Machine learning for sentiment analysis
   - Time series analysis for crypto prices
   - API clients for various services

3. **Docker Images** (for complex services):
   - Database services (Redis, InfluxDB for time series)
   - Real-time data processing
   - Web scraping infrastructure

For each recommendation, explain WHY it's needed for this specific use case.

Format your response as JSON:
{{
  "github_repos": [
    {{"repo": "user/repository", "purpose": "why needed", "priority": "high/medium/low"}},
  ],
  "pypi_packages": [
    {{"package": "package-name", "purpose": "why needed", "priority": "high/medium/low"}},
  ],
  "docker_images": [
    {{"image": "image:tag", "purpose": "why needed", "priority": "high/medium/low"}},
  ],
  "reasoning": "overall strategy and approach"
}}
"""
        
        llm_analysis = await self.tool_analyst.call_llm(requirement_analysis_prompt)
        self.log("✅ LLM completed requirement analysis")
        
        # Parse LLM response
        try:
            import re
            json_match = re.search(r'\{.*\}', llm_analysis, re.DOTALL)
            if json_match:
                parsed_requirements = json.loads(json_match.group())
                self.results["llm_requirements"] = parsed_requirements
                
                # Show LLM reasoning
                print(f"\n🎯 LLM Reasoning: {parsed_requirements.get('reasoning', 'Not provided')}")
                
                # Show recommendations
                print(f"\n📦 GitHub Repos: {len(parsed_requirements.get('github_repos', []))}")
                for repo in parsed_requirements.get('github_repos', [])[:3]:
                    print(f"   🔗 {repo.get('repo')}: {repo.get('purpose')} [{repo.get('priority')}]")
                
                print(f"\n🐍 PyPI Packages: {len(parsed_requirements.get('pypi_packages', []))}")
                for pkg in parsed_requirements.get('pypi_packages', [])[:3]:
                    print(f"   📦 {pkg.get('package')}: {pkg.get('purpose')} [{pkg.get('priority')}]")
                
                print(f"\n🐳 Docker Images: {len(parsed_requirements.get('docker_images', []))}")
                for img in parsed_requirements.get('docker_images', [])[:3]:
                    print(f"   🐳 {img.get('image')}: {img.get('purpose')} [{img.get('priority')}]")
                
                return parsed_requirements
            else:
                self.log("⚠️ Could not parse LLM JSON response")
                return {"error": "Failed to parse LLM requirements"}
                
        except Exception as e:
            self.log(f"❌ Error parsing LLM response: {e}")
            return {"error": str(e)}
    
    async def stage_2_intelligent_tool_download(self, requirements):
        """Stage 2: Intelligently download the most important tools"""
        self.log("\n🚀 STAGE 2: Intelligent Tool Download")
        print("=" * 60)
        
        if "error" in requirements:
            self.log("❌ Skipping download due to requirement analysis error")
            return {}
        
        download_results = {}
        
        # Download high-priority GitHub repos
        high_priority_repos = [
            repo for repo in requirements.get('github_repos', []) 
            if repo.get('priority') == 'high'
        ]
        
        self.log(f"📥 Downloading {len(high_priority_repos)} high-priority GitHub repos...")
        
        for repo_info in high_priority_repos[:2]:  # Limit to 2 for demo
            repo = repo_info.get('repo')
            if repo:
                self.log(f"   Downloading: {repo}")
                try:
                    result = await auto_downloader.download_github_tool(repo)
                    download_results[f"github_{repo.replace('/', '_')}"] = result
                    
                    if result.get("status") == "success":
                        self.log(f"   ✅ {repo}: {len(result.get('files_copied', []))} files")
                    else:
                        self.log(f"   ❌ {repo}: {result.get('error', 'Unknown error')}")
                        
                except Exception as e:
                    self.log(f"   ❌ {repo}: Exception - {e}")
                    download_results[f"github_{repo.replace('/', '_')}"] = {"error": str(e)}
        
        # Download high-priority PyPI packages
        high_priority_packages = [
            pkg for pkg in requirements.get('pypi_packages', []) 
            if pkg.get('priority') == 'high'
        ]
        
        self.log(f"📦 Installing {len(high_priority_packages)} high-priority PyPI packages...")
        
        for pkg_info in high_priority_packages[:3]:  # Limit to 3 for demo
            package = pkg_info.get('package')
            if package:
                self.log(f"   Installing: {package}")
                try:
                    result = await auto_downloader.install_pypi_tool(package)
                    download_results[f"pypi_{package}"] = result
                    
                    if result.get("status") == "success":
                        self.log(f"   ✅ {package}: Installed successfully")
                    else:
                        self.log(f"   ❌ {package}: {result.get('error', 'Unknown error')}")
                        
                except Exception as e:
                    self.log(f"   ❌ {package}: Exception - {e}")
                    download_results[f"pypi_{package}"] = {"error": str(e)}
        
        # Re-discover tools after downloads
        self.log("🔍 Re-discovering tools after downloads...")
        new_tool_count = tool_manager.discover_tools()
        updated_tools = tool_manager.get_all_tools()
        
        newly_added_tools = set(updated_tools) - set(self.results["initial_tools"])
        
        self.log(f"✅ Tool discovery complete: {new_tool_count} total tools")
        self.log(f"🆕 Added {len(newly_added_tools)} new tools")
        
        for tool in list(newly_added_tools)[:5]:  # Show first 5 new tools
            self.log(f"   + {tool}")
        
        self.results["downloaded_tools"] = download_results
        self.results["new_tools"] = list(newly_added_tools)
        
        return download_results
    
    async def stage_3_llm_designs_workflow(self):
        """Stage 3: LLM designs a workflow using available tools"""
        self.log("\n🎯 STAGE 3: LLM Workflow Design")
        print("=" * 60)
        
        # Get current available tools
        available_tools = tool_manager.get_all_tools()
        tools_by_category = tool_manager.list_tools_by_module()
        
        workflow_design_prompt = f"""
Design a comprehensive workflow to accomplish this use case: {self.use_case}

Available tools by category:
{json.dumps(tools_by_category, indent=2)}

Recently downloaded tools:
{self.results.get("new_tools", [])}

Design a step-by-step workflow that:
1. Uses the newly downloaded tools effectively
2. Combines them with existing framework tools
3. Accomplishes the use case comprehensively
4. Includes error handling and fallbacks

Format as JSON:
{{
  "workflow_steps": [
    {{
      "step": 1,
      "action": "what to do",
      "tools": ["tool1", "tool2"],
      "purpose": "why this step",
      "expected_output": "what we expect"
    }}
  ],
  "success_criteria": ["criteria1", "criteria2"],
  "fallback_plan": "what to do if tools fail"
}}
"""
        
        workflow_design = await self.workflow_manager.call_llm(workflow_design_prompt)
        self.log("✅ LLM completed workflow design")
        
        # Parse workflow design
        try:
            import re
            json_match = re.search(r'\{.*\}', workflow_design, re.DOTALL)
            if json_match:
                parsed_workflow = json.loads(json_match.group())
                self.results["workflow_design"] = parsed_workflow
                
                # Show workflow steps
                steps = parsed_workflow.get("workflow_steps", [])
                print(f"\n📋 LLM Designed {len(steps)} workflow steps:")
                for step in steps[:3]:  # Show first 3 steps
                    print(f"   {step.get('step')}. {step.get('action')}")
                    print(f"      Tools: {step.get('tools', [])}")
                    print(f"      Purpose: {step.get('purpose')}")
                
                return parsed_workflow
            else:
                self.log("⚠️ Could not parse workflow design")
                return {"error": "Failed to parse workflow design"}
                
        except Exception as e:
            self.log(f"❌ Error parsing workflow design: {e}")
            return {"error": str(e)}
    
    async def stage_4_execute_intelligent_workflow(self, workflow_design):
        """Stage 4: Execute the LLM-designed workflow"""
        self.log("\n⚡ STAGE 4: Execute Intelligent Workflow")
        print("=" * 60)
        
        if "error" in workflow_design:
            self.log("❌ Cannot execute workflow due to design errors")
            return {"error": "Workflow design failed"}
        
        execution_results = []
        steps = workflow_design.get("workflow_steps", [])
        
        for step_info in steps[:4]:  # Execute first 4 steps for demo
            step_num = step_info.get("step", 0)
            action = step_info.get("action", "")
            tools = step_info.get("tools", [])
            
            self.log(f"\n🔄 Executing Step {step_num}: {action}")
            
            step_result = {
                "step": step_num,
                "action": action,
                "tools_attempted": tools,
                "results": {},
                "success": False
            }
            
            # Try to execute tools for this step
            for tool in tools[:2]:  # Limit to 2 tools per step
                self.log(f"   🔧 Trying tool: {tool}")
                
                try:
                    # Smart tool execution based on tool type
                    if "research" in tool.lower():
                        # Research tool execution
                        result = tool_manager.execute_tool(
                            tool, 
                            query=f"cryptocurrency portfolio analysis {self.use_case}",
                            num_results=3
                        )
                    elif "browser" in tool.lower():
                        # Browser tool execution
                        if "create" in tool:
                            result = tool_manager.execute_tool(tool, browser_id="auto_workflow")
                        elif "navigate" in tool:
                            result = tool_manager.execute_tool(
                                tool, 
                                url="https://coinmarketcap.com/",
                                browser_id="auto_workflow"
                            )
                        else:
                            result = tool_manager.execute_tool(tool, browser_id="auto_workflow")
                    else:
                        # Generic tool execution
                        result = tool_manager.execute_tool(tool)
                    
                    step_result["results"][tool] = result
                    
                    if result and "error" not in result:
                        self.log(f"     ✅ {tool}: Success")
                        step_result["success"] = True
                    else:
                        self.log(f"     ❌ {tool}: {result.get('error', 'Unknown error')}")
                        
                except Exception as e:
                    self.log(f"     ❌ {tool}: Exception - {e}")
                    step_result["results"][tool] = {"error": str(e)}
            
            execution_results.append(step_result)
            
            # Brief pause between steps
            await asyncio.sleep(1)
        
        # Cleanup browser if used
        try:
            tool_manager.execute_tool("browser:close", browser_id="auto_workflow")
        except:
            pass
        
        self.results["workflow_execution"] = execution_results
        
        # Calculate success metrics
        successful_steps = sum(1 for step in execution_results if step["success"])
        success_rate = (successful_steps / len(execution_results) * 100) if execution_results else 0
        
        self.log(f"✅ Workflow execution complete: {successful_steps}/{len(execution_results)} steps successful ({success_rate:.1f}%)")
        
        return execution_results
    
    async def stage_5_llm_final_analysis(self, execution_results):
        """Stage 5: LLM analyzes results and provides insights"""
        self.log("\n📊 STAGE 5: LLM Final Analysis")
        print("=" * 60)
        
        # Prepare execution summary for LLM
        execution_summary = {
            "use_case": self.use_case,
            "tools_downloaded": len(self.results.get("downloaded_tools", {})),
            "new_tools_added": len(self.results.get("new_tools", [])),
            "workflow_steps_executed": len(execution_results),
            "successful_steps": sum(1 for step in execution_results if step["success"]),
            "execution_results": execution_results[:3]  # First 3 for LLM analysis
        }
        
        final_analysis_prompt = f"""
Analyze the results of this auto-download workflow execution:

{json.dumps(execution_summary, indent=2)}

Provide insights on:
1. How well the auto-downloaded tools worked
2. What was accomplished vs. the original use case
3. Recommendations for improvement
4. Value of the auto-download approach
5. Next steps for better results

Format as JSON:
{{
  "effectiveness_score": "1-10",
  "auto_download_value": "assessment of auto-download approach",
  "accomplishments": ["what was achieved"],
  "limitations": ["what didn't work well"],
  "recommendations": ["specific improvements"],
  "next_steps": ["actionable next steps"]
}}
"""
        
        final_analysis = await self.workflow_manager.call_llm(final_analysis_prompt)
        
        # Parse final analysis
        try:
            import re
            json_match = re.search(r'\{.*\}', final_analysis, re.DOTALL)
            if json_match:
                parsed_analysis = json.loads(json_match.group())
                self.results["final_analysis"] = parsed_analysis
                
                self.log("✅ LLM final analysis complete")
                
                # Show key insights
                print(f"\n🎯 Effectiveness Score: {parsed_analysis.get('effectiveness_score', 'N/A')}/10")
                print(f"💡 Auto-Download Value: {parsed_analysis.get('auto_download_value', 'Not assessed')}")
                
                accomplishments = parsed_analysis.get('accomplishments', [])
                if accomplishments:
                    print(f"\n✅ Accomplishments:")
                    for acc in accomplishments[:3]:
                        print(f"   • {acc}")
                
                recommendations = parsed_analysis.get('recommendations', [])
                if recommendations:
                    print(f"\n💡 Recommendations:")
                    for rec in recommendations[:3]:
                        print(f"   • {rec}")
                
                return parsed_analysis
            else:
                self.log("⚠️ Could not parse final analysis")
                return {"error": "Failed to parse analysis"}
                
        except Exception as e:
            self.log(f"❌ Error parsing final analysis: {e}")
            return {"error": str(e)}
    
    async def run_complete_workflow(self):
        """Execute the complete auto-download workflow"""
        self.log("🚀 SMART AUTO-DOWNLOAD WORKFLOW")
        print("=" * 80)
        print(f"Use Case: {self.use_case}")
        print(f"Session: {self.session_id}")
        print(f"LLM Model: {CONFIG['default_model']}")
        print("=" * 80)
        
        start_time = time.time()
        
        try:
            # Execute all stages
            requirements = await self.stage_1_llm_analyzes_requirements()
            download_results = await self.stage_2_intelligent_tool_download(requirements)
            workflow_design = await self.stage_3_llm_designs_workflow()
            execution_results = await self.stage_4_execute_intelligent_workflow(workflow_design)
            final_analysis = await self.stage_5_llm_final_analysis(execution_results)
            
            end_time = time.time()
            execution_time = end_time - start_time
            
            # Generate comprehensive report
            report = {
                "workflow_summary": {
                    "use_case": self.use_case,
                    "session_id": self.session_id,
                    "execution_time": execution_time,
                    "llm_model": CONFIG['default_model'],
                    "timestamp": datetime.now().isoformat()
                },
                "requirements_analysis": requirements,
                "download_results": download_results,
                "workflow_design": workflow_design,
                "execution_results": execution_results,
                "final_analysis": final_analysis,
                "tool_metrics": {
                    "initial_tools": len(self.results["initial_tools"]),
                    "final_tools": len(tool_manager.get_all_tools()),
                    "new_tools_added": len(self.results.get("new_tools", [])),
                    "download_success_rate": self._calculate_download_success_rate()
                },
                "execution_log": self.results["execution_log"]
            }
            
            # Save report
            report_file = f"smart_auto_download_report_{self.session_id}.json"
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            # Print summary
            print("\n" + "=" * 80)
            print("🎯 AUTO-DOWNLOAD WORKFLOW SUMMARY")
            print("=" * 80)
            
            metrics = report["tool_metrics"]
            print(f"📦 Tools: {metrics['initial_tools']} → {metrics['final_tools']} (+{metrics['new_tools_added']})")
            print(f"📥 Download Success: {metrics['download_success_rate']:.1f}%")
            print(f"⏱️ Execution Time: {execution_time:.1f} seconds")
            
            if isinstance(final_analysis, dict) and "effectiveness_score" in final_analysis:
                print(f"🎯 Effectiveness: {final_analysis['effectiveness_score']}/10")
            
            print(f"📁 Full Report: {report_file}")
            
            print(f"\n✅ Smart Auto-Download Workflow Completed!")
            return report, report_file
            
        except Exception as e:
            self.log(f"❌ Workflow failed: {str(e)}")
            import traceback
            traceback.print_exc()
            return None, None
    
    def _calculate_download_success_rate(self):
        """Calculate success rate of downloads"""
        total_downloads = len(self.results.get("downloaded_tools", {}))
        if total_downloads == 0:
            return 0.0
        
        successful_downloads = sum(
            1 for result in self.results["downloaded_tools"].values()
            if result.get("status") == "success"
        )
        
        return (successful_downloads / total_downloads) * 100

# Predefined use cases for easy testing
USE_CASES = {
    "crypto_sentiment": "Cryptocurrency Portfolio Analysis with Social Media Sentiment - Track crypto prices, analyze Twitter/Reddit sentiment, and optimize portfolio allocation based on social signals",
    
    "stock_trading": "Automated Stock Trading Bot - Real-time market data, technical indicators, news sentiment analysis, and automated trade execution with risk management",
    
    "ecommerce_analysis": "E-commerce Market Analysis - Scrape product data, analyze competitor pricing, track inventory levels, and generate market insights",
    
    "content_marketing": "Content Marketing Automation - Social media monitoring, content generation, SEO analysis, and automated posting across platforms",
    
    "financial_reporting": "Automated Financial Reporting - Extract data from multiple sources, generate charts/visualizations, and create executive dashboards"
}

def main():
    """Main execution function"""
    print("🚀 SMART AUTO-DOWNLOAD WORKFLOW DEMO")
    print("=" * 80)
    print("This workflow demonstrates LLM-powered tool downloading:")
    print("✅ LLM analyzes requirements and selects tools")
    print("✅ Auto-downloads GitHub repos, PyPI packages, Docker images") 
    print("✅ LLM designs workflow using new tools")
    print("✅ Executes intelligent multi-step process")
    print("✅ LLM analyzes results and provides insights")
    print("=" * 80)
    
    # Show available use cases
    print("\n📋 Available Use Cases:")
    for key, description in USE_CASES.items():
        print(f"   {key}: {description[:80]}...")
    
    # Get user choice
    choice = input(f"\nChoose use case (or 'custom'): ").strip().lower()
    
    if choice in USE_CASES:
        use_case = USE_CASES[choice]
    elif choice == 'custom':
        use_case = input("Enter your custom use case: ").strip()
    else:
        # Default to crypto sentiment analysis
        use_case = USE_CASES["crypto_sentiment"]
        print(f"Using default: {choice}")
    
    print(f"\n🎯 Selected Use Case: {use_case}")
    
    # Initialize and run workflow
    workflow = SmartAutoDownloadWorkflow(use_case)
    
    # Handle async execution
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(asyncio.run, workflow.run_complete_workflow())
                report, report_file = future.result()
        else:
            report, report_file = asyncio.run(workflow.run_complete_workflow())
    except RuntimeError:
        report, report_file = asyncio.run(workflow.run_complete_workflow())
    
    if report:
        print("\n💡 INFINITE CAPACITY DEMONSTRATED:")
        print("✅ LLM intelligently selected tools for the use case")
        print("✅ Auto-downloaded specialized tools from GitHub/PyPI")
        print("✅ Integrated new tools with existing framework")
        print("✅ Designed and executed custom workflow")
        print("✅ Provided intelligent analysis and recommendations")
        print("\n🚀 Your framework now has INFINITE tool capacity!")
        
        return report_file
    else:
        print("❌ Auto-download workflow failed")
        return None

if __name__ == "__main__":
    result = main()