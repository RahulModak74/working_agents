#!/usr/bin/env python3
"""
Final browser fix - remove conflicting files and ensure only the working version is used
"""

import os
import shutil
from pathlib import Path

def remove_conflicting_files():
    """Remove all conflicting browser adapter files"""
    print("🧹 Removing conflicting browser adapter files...")
    
    component_dir = Path(__file__).parent / "COMPONENT"
    
    # Files to remove (keep only browser_adapter.py)
    files_to_remove = [
        "browser_adapter_old_backup.py",
        "browser_adapter_playwright_backup.py", 
        "playwright_browser_adapter.py"
    ]
    
    for filename in files_to_remove:
        filepath = component_dir / filename
        if filepath.exists():
            filepath.unlink()
            print(f"✅ Removed: {filename}")
        else:
            print(f"⚪ Not found: {filename}")
    
    # Also remove any __pycache__ for these files
    pycache_dir = component_dir / "__pycache__"
    if pycache_dir.exists():
        for pyc_file in pycache_dir.glob("browser_adapter*.pyc"):
            pyc_file.unlink()
            print(f"✅ Removed cache: {pyc_file.name}")
        
        for pyc_file in pycache_dir.glob("playwright_browser_adapter*.pyc"):
            pyc_file.unlink()
            print(f"✅ Removed cache: {pyc_file.name}")

def verify_only_good_adapter():
    """Verify only the good adapter exists"""
    print("🔍 Verifying browser adapter...")
    
    component_dir = Path(__file__).parent / "COMPONENT"
    browser_adapter_path = component_dir / "browser_adapter.py"
    
    if not browser_adapter_path.exists():
        print("❌ browser_adapter.py not found!")
        return False
    
    # Check content
    with open(browser_adapter_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if 'SimpleBrowserManager' in content and 'simple_http' in content:
        print("✅ browser_adapter.py is the correct fixed version")
        return True
    else:
        print("❌ browser_adapter.py is not the fixed version!")
        return False

def test_clean_browser():
    """Test browser after cleanup"""
    print("🧪 Testing clean browser...")
    
    try:
        # Clear any cached modules
        import sys
        modules_to_clear = [k for k in sys.modules.keys() if 'browser' in k.lower() or 'tool_manager' in k]
        for module in modules_to_clear:
            del sys.modules[module]
            print(f"✅ Cleared module: {module}")
        
        # Clear __pycache__
        current_dir = Path(__file__).parent
        for pycache_dir in current_dir.rglob("__pycache__"):
            if pycache_dir.is_dir():
                shutil.rmtree(pycache_dir)
                print(f"✅ Cleared cache: {pycache_dir}")
        
        # Add paths
        component_dir = current_dir / "COMPONENT"
        sys.path.insert(0, str(component_dir))
        sys.path.insert(0, str(current_dir))
        
        print("1. Testing direct import...")
        import browser_adapter
        
        print("2. Testing browser creation...")
        result = browser_adapter.browser_create(browser_id="clean_test")
        if result.get("status") == "success":
            print("✅ Browser creation: SUCCESS")
            
            print("3. Testing navigation...")
            nav_result = browser_adapter.browser_navigate(url="https://httpbin.org/html", browser_id="clean_test")
            if nav_result.get("status") == "success":
                print("✅ Navigation: SUCCESS")
                
                print("4. Testing cleanup...")
                browser_adapter.browser_close(browser_id="clean_test")
                print("✅ Cleanup: SUCCESS")
                
                return True
        
        print(f"❌ Browser test failed: {result}")
        return False
        
    except Exception as e:
        print(f"❌ Clean browser test failed: {e}")
        return False

def test_with_fresh_tool_manager():
    """Test with completely fresh tool manager"""
    print("🧪 Testing with fresh tool manager...")
    
    try:
        # Clear all tool-related modules
        import sys
        modules_to_clear = [k for k in sys.modules.keys() if any(x in k.lower() for x in ['tool', 'browser', 'manager'])]
        for module in modules_to_clear:
            del sys.modules[module]
        
        print("1. Fresh import of tool_manager...")
        from tool_manager import tool_manager
        
        print("2. Complete tool manager reset...")
        tool_manager.tools.clear()
        tool_manager.imported_modules.clear()
        if hasattr(tool_manager, 'namespace_prefixes'):
            tool_manager.namespace_prefixes.clear()
        
        print("3. Rediscovering tools...")
        tool_count = tool_manager.discover_tools()
        print(f"   Discovered {tool_count} tools")
        
        print("4. Checking browser tools...")
        browser_tools = tool_manager.get_tools_by_prefix("browser")
        print(f"   Browser tools: {browser_tools}")
        
        print("5. Testing browser creation...")
        result = tool_manager.execute_tool("browser:create", browser_id="fresh_test")
        if result.get("status") == "success":
            print("✅ Tool manager browser creation: SUCCESS")
            
            print("6. Testing navigation...")
            nav_result = tool_manager.execute_tool("browser:navigate", 
                                                 url="https://httpbin.org/html", 
                                                 browser_id="fresh_test")
            if nav_result.get("status") == "success":
                print("✅ Tool manager navigation: SUCCESS")
                
                print("7. Testing cleanup...")
                tool_manager.execute_tool("browser:close", browser_id="fresh_test")
                print("✅ Tool manager cleanup: SUCCESS")
                
                return True
            else:
                print(f"❌ Navigation failed: {nav_result}")
        else:
            print(f"❌ Browser creation failed: {result}")
            # Print more details
            print(f"   Error details: {result.get('error', 'Unknown error')}")
        
        return False
        
    except Exception as e:
        print(f"❌ Fresh tool manager test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main fix function"""
    print("🚀 FINAL BROWSER FIX")
    print("=" * 50)
    
    # Step 1: Remove conflicting files
    remove_conflicting_files()
    
    # Step 2: Verify only good adapter exists
    if not verify_only_good_adapter():
        print("❌ Browser adapter verification failed!")
        return
    
    # Step 3: Test clean browser
    print("\n" + "=" * 50)
    print("TESTING CLEAN BROWSER")
    print("=" * 50)
    
    if test_clean_browser():
        print("✅ Clean browser test PASSED!")
        
        # Step 4: Test with fresh tool manager
        print("\n" + "=" * 50)
        print("TESTING WITH FRESH TOOL MANAGER")
        print("=" * 50)
        
        if test_with_fresh_tool_manager():
            print("\n🎉 FINAL FIX SUCCESS!")
            print("=" * 50)
            print("Your browser tools are now working!")
            print("\n💡 Now run your validation:")
            print("python quick_test_browser_research_adapter.py")
            print("\n🚀 Your framework is fully functional!")
        else:
            print("\n⚠️ Tool manager test failed")
            print("=" * 50)
            print("NUCLEAR OPTION: Restart Python completely")
            print("1. Close this terminal/command prompt")
            print("2. Open a new one")
            print("3. Navigate back to this directory")
            print("4. Run: python quick_test_browser_research_adapter.py")
    else:
        print("❌ Clean browser test failed")
        print("Something is still wrong with the browser adapter")

if __name__ == "__main__":
    main()