#!/usr/bin/env python3
"""
Enterprise Encryption Manager
Data encryption at rest and in transit for compliance
"""

import os
import json
import base64
import hashlib
import secrets
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from typing import Dict, Any, Optional, Tuple
import sqlite3
from datetime import datetime, timedelta

class EnterpriseEncryption:
    """Enterprise-grade encryption for data protection"""
    
    def __init__(self):
        self.key_db_path = "encryption_keys.db"
        self.master_key = self._get_or_create_master_key()
        self.encryption_keys = {}
        
        # Initialize key database
        self._init_key_database()
        
        # Load encryption keys
        self._load_encryption_keys()
    
    def _init_key_database(self):
        """Initialize encryption key database"""
        with sqlite3.connect(self.key_db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS encryption_keys (
                    key_id TEXT PRIMARY KEY,
                    key_purpose TEXT NOT NULL,
                    encrypted_key BLOB NOT NULL,
                    key_algorithm TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT,
                    rotation_count INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'active'
                )
            ''')
            
            conn.execute('''
                CREATE TABLE IF NOT EXISTS key_usage_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key_id TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    user_id TEXT,
                    timestamp TEXT NOT NULL,
                    success INTEGER NOT NULL
                )
            ''')
    
    def _get_or_create_master_key(self) -> bytes:
        """Get or create master encryption key"""
        master_key_file = "master.key"
        
        if os.path.exists(master_key_file):
            # Load existing master key
            with open(master_key_file, 'rb') as f:
                encrypted_master = f.read()
            
            # Derive key from environment variable or prompt
            password = os.environ.get('MASTER_KEY_PASSWORD')
            if not password:
                # In production, use HSM or secure key management
                password = "change_this_in_production_use_env_var"
            
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'enterprise_salt_change_in_prod',
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
            
            try:
                fernet = Fernet(key)
                master_key = fernet.decrypt(encrypted_master)
                return master_key
            except:
                raise ValueError("Invalid master key password")
        else:
            # Create new master key
            master_key = Fernet.generate_key()
            
            # Encrypt master key with password
            password = os.environ.get('MASTER_KEY_PASSWORD', "change_this_in_production_use_env_var")
            
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'enterprise_salt_change_in_prod',
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
            
            fernet = Fernet(key)
            encrypted_master = fernet.encrypt(master_key)
            
            # Save encrypted master key
            with open(master_key_file, 'wb') as f:
                f.write(encrypted_master)
            
            # Set restrictive permissions
            os.chmod(master_key_file, 0o600)
            
            return master_key
    
    def _load_encryption_keys(self):
        """Load encryption keys from database"""
        with sqlite3.connect(self.key_db_path) as conn:
            cursor = conn.execute('''
                SELECT key_id, key_purpose, encrypted_key, key_algorithm 
                FROM encryption_keys 
                WHERE status = 'active'
            ''')
            
            master_fernet = Fernet(self.master_key)
            
            for row in cursor.fetchall():
                key_id, purpose, encrypted_key, algorithm = row
                try:
                    decrypted_key = master_fernet.decrypt(encrypted_key)
                    self.encryption_keys[key_id] = {
                        "key": decrypted_key,
                        "purpose": purpose,
                        "algorithm": algorithm
                    }
                except Exception as e:
                    print(f"Failed to decrypt key {key_id}: {e}")
    
    def create_encryption_key(self, purpose: str, algorithm: str = "fernet", 
                            expires_days: Optional[int] = None) -> str:
        """Create new encryption key"""
        key_id = f"{purpose}_{secrets.token_hex(8)}"
        
        # Generate key based on algorithm
        if algorithm == "fernet":
            encryption_key = Fernet.generate_key()
        elif algorithm == "aes256":
            encryption_key = secrets.token_bytes(32)  # 256-bit key
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
        
        # Encrypt key with master key
        master_fernet = Fernet(self.master_key)
        encrypted_key = master_fernet.encrypt(encryption_key)
        
        # Calculate expiry
        expires_at = None
        if expires_days:
            expires_at = (datetime.utcnow() + timedelta(days=expires_days)).isoformat()
        
        # Store in database
        with sqlite3.connect(self.key_db_path) as conn:
            conn.execute('''
                INSERT INTO encryption_keys 
                (key_id, key_purpose, encrypted_key, key_algorithm, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (key_id, purpose, encrypted_key, algorithm, datetime.utcnow().isoformat(), expires_at))
        
        # Store in memory
        self.encryption_keys[key_id] = {
            "key": encryption_key,
            "purpose": purpose,
            "algorithm": algorithm
        }
        
        self._log_key_usage(key_id, "created", success=True)
        
        return key_id
    
    def encrypt_data(self, data: Any, key_id: str = None, purpose: str = "general") -> Dict[str, Any]:
        """Encrypt data with specified key"""
        
        # Get or create encryption key
        if key_id is None:
            # Find key by purpose or create new one
            key_id = self._find_key_by_purpose(purpose)
            if not key_id:
                key_id = self.create_encryption_key(purpose)
        
        if key_id not in self.encryption_keys:
            raise ValueError(f"Encryption key not found: {key_id}")
        
        key_info = self.encryption_keys[key_id]
        
        try:
            # Convert data to bytes
            if isinstance(data, str):
                data_bytes = data.encode('utf-8')
            elif isinstance(data, dict) or isinstance(data, list):
                data_bytes = json.dumps(data).encode('utf-8')
            else:
                data_bytes = str(data).encode('utf-8')
            
            # Encrypt based on algorithm
            if key_info["algorithm"] == "fernet":
                fernet = Fernet(key_info["key"])
                encrypted_data = fernet.encrypt(data_bytes)
                encrypted_b64 = base64.b64encode(encrypted_data).decode('utf-8')
            
            elif key_info["algorithm"] == "aes256":
                # AES-256-GCM encryption
                iv = secrets.token_bytes(16)
                cipher = Cipher(algorithms.AES(key_info["key"]), modes.GCM(iv))
                encryptor = cipher.encryptor()
                
                ciphertext = encryptor.update(data_bytes) + encryptor.finalize()
                
                # Combine IV + tag + ciphertext
                encrypted_data = iv + encryptor.tag + ciphertext
                encrypted_b64 = base64.b64encode(encrypted_data).decode('utf-8')
            
            else:
                raise ValueError(f"Unsupported algorithm: {key_info['algorithm']}")
            
            self._log_key_usage(key_id, "encrypt", success=True)
            
            return {
                "encrypted_data": encrypted_b64,
                "key_id": key_id,
                "algorithm": key_info["algorithm"],
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self._log_key_usage(key_id, "encrypt", success=False)
            raise Exception(f"Encryption failed: {str(e)}")
    
    def decrypt_data(self, encrypted_package: Dict[str, Any]) -> Any:
        """Decrypt data using encrypted package"""
        
        key_id = encrypted_package["key_id"]
        encrypted_b64 = encrypted_package["encrypted_data"]
        algorithm = encrypted_package["algorithm"]
        
        if key_id not in self.encryption_keys:
            raise ValueError(f"Decryption key not found: {key_id}")
        
        key_info = self.encryption_keys[key_id]
        
        try:
            encrypted_data = base64.b64decode(encrypted_b64.encode('utf-8'))
            
            # Decrypt based on algorithm
            if algorithm == "fernet":
                fernet = Fernet(key_info["key"])
                decrypted_bytes = fernet.decrypt(encrypted_data)
            
            elif algorithm == "aes256":
                # Extract IV, tag, and ciphertext
                iv = encrypted_data[:16]
                tag = encrypted_data[16:32]
                ciphertext = encrypted_data[32:]
                
                cipher = Cipher(algorithms.AES(key_info["key"]), modes.GCM(iv, tag))
                decryptor = cipher.decryptor()
                decrypted_bytes = decryptor.update(ciphertext) + decryptor.finalize()
            
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")
            
            # Try to parse as JSON, fallback to string
            try:
                decrypted_str = decrypted_bytes.decode('utf-8')
                return json.loads(decrypted_str)
            except json.JSONDecodeError:
                return decrypted_bytes.decode('utf-8')
            except UnicodeDecodeError:
                return decrypted_bytes
            
            self._log_key_usage(key_id, "decrypt", success=True)
            
        except Exception as e:
            self._log_key_usage(key_id, "decrypt", success=False)
            raise Exception(f"Decryption failed: {str(e)}")
    
    def _find_key_by_purpose(self, purpose: str) -> Optional[str]:
        """Find active key by purpose"""
        for key_id, key_info in self.encryption_keys.items():
            if key_info["purpose"] == purpose:
                return key_id
        return None
    
    def _log_key_usage(self, key_id: str, operation: str, user_id: str = None, success: bool = True):
        """Log key usage for audit"""
        with sqlite3.connect(self.key_db_path) as conn:
            conn.execute('''
                INSERT INTO key_usage_log (key_id, operation, user_id, timestamp, success)
                VALUES (?, ?, ?, ?, ?)
            ''', (key_id, operation, user_id, datetime.utcnow().isoformat(), int(success)))
    
    def rotate_key(self, key_id: str) -> str:
        """Rotate encryption key"""
        if key_id not in self.encryption_keys:
            raise ValueError(f"Key not found: {key_id}")
        
        old_key_info = self.encryption_keys[key_id]
        
        # Create new key with same purpose
        new_key_id = self.create_encryption_key(
            purpose=old_key_info["purpose"],
            algorithm=old_key_info["algorithm"]
        )
        
        # Mark old key as rotated
        with sqlite3.connect(self.key_db_path) as conn:
            conn.execute('''
                UPDATE encryption_keys 
                SET status = 'rotated', rotation_count = rotation_count + 1
                WHERE key_id = ?
            ''', (key_id,))
        
        # Remove from memory (but keep in database for historical decryption)
        del self.encryption_keys[key_id]
        
        self._log_key_usage(key_id, "rotated", success=True)
        self._log_key_usage(new_key_id, "rotation_created", success=True)
        
        return new_key_id
    
    def encrypt_file(self, file_path: str, key_id: str = None) -> str:
        """Encrypt entire file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Read file
        with open(file_path, 'rb') as f:
            file_data = f.read()
        
        # Encrypt data
        encrypted_package = self.encrypt_data(file_data, key_id, purpose="file_encryption")
        
        # Save encrypted file
        encrypted_file_path = f"{file_path}.encrypted"
        with open(encrypted_file_path, 'w') as f:
            json.dump(encrypted_package, f)
        
        return encrypted_file_path
    
    def decrypt_file(self, encrypted_file_path: str, output_path: str = None) -> str:
        """Decrypt entire file"""
        if not os.path.exists(encrypted_file_path):
            raise FileNotFoundError(f"Encrypted file not found: {encrypted_file_path}")
        
        # Read encrypted package
        with open(encrypted_file_path, 'r') as f:
            encrypted_package = json.load(f)
        
        # Decrypt data
        decrypted_data = self.decrypt_data(encrypted_package)
        
        # Determine output path
        if output_path is None:
            if encrypted_file_path.endswith('.encrypted'):
                output_path = encrypted_file_path[:-10]  # Remove .encrypted
            else:
                output_path = f"{encrypted_file_path}.decrypted"
        
        # Write decrypted data
        if isinstance(decrypted_data, bytes):
            with open(output_path, 'wb') as f:
                f.write(decrypted_data)
        else:
            with open(output_path, 'w') as f:
                if isinstance(decrypted_data, str):
                    f.write(decrypted_data)
                else:
                    json.dump(decrypted_data, f, indent=2)
        
        return output_path
    
    def encrypt_database_field(self, table_name: str, field_name: str, 
                              value: Any, record_id: str) -> Dict[str, Any]:
        """Encrypt specific database field"""
        purpose = f"db_{table_name}_{field_name}"
        key_id = self._find_key_by_purpose(purpose)
        
        if not key_id:
            key_id = self.create_encryption_key(purpose)
        
        encrypted_package = self.encrypt_data(value, key_id, purpose)
        
        # Add metadata for database encryption
        encrypted_package.update({
            "table_name": table_name,
            "field_name": field_name,
            "record_id": record_id,
            "encryption_version": "1.0"
        })
        
        return encrypted_package
    
    def decrypt_database_field(self, encrypted_field_data: Dict[str, Any]) -> Any:
        """Decrypt database field"""
        return self.decrypt_data(encrypted_field_data)
    
    def create_rsa_keypair(self, key_size: int = 2048) -> Tuple[str, str]:
        """Create RSA public/private key pair for asymmetric encryption"""
        
        # Generate private key
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size
        )
        
        # Get public key
        public_key = private_key.public_key()
        
        # Serialize keys
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        # Store keys securely
        key_id = f"rsa_{secrets.token_hex(8)}"
        
        # Encrypt private key with master key
        master_fernet = Fernet(self.master_key)
        encrypted_private_key = master_fernet.encrypt(private_pem)
        
        with sqlite3.connect(self.key_db_path) as conn:
            # Store private key
            conn.execute('''
                INSERT INTO encryption_keys 
                (key_id, key_purpose, encrypted_key, key_algorithm, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (f"{key_id}_private", "rsa_private", encrypted_private_key, "rsa", 
                  datetime.utcnow().isoformat()))
            
            # Store public key (not encrypted as it's meant to be public)
            conn.execute('''
                INSERT INTO encryption_keys 
                (key_id, key_purpose, encrypted_key, key_algorithm, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (f"{key_id}_public", "rsa_public", public_pem, "rsa", 
                  datetime.utcnow().isoformat()))
        
        return key_id, public_pem.decode('utf-8')
    
    def rsa_encrypt(self, data: str, public_key_pem: str) -> str:
        """Encrypt data with RSA public key"""
        public_key = serialization.load_pem_public_key(public_key_pem.encode('utf-8'))
        
        # RSA can only encrypt small amounts of data
        data_bytes = data.encode('utf-8')
        
        if len(data_bytes) > 190:  # RSA-2048 limit minus padding
            # For large data, use hybrid encryption (RSA + AES)
            # Generate random AES key
            aes_key = secrets.token_bytes(32)
            
            # Encrypt data with AES
            iv = secrets.token_bytes(16)
            cipher = Cipher(algorithms.AES(aes_key), modes.GCM(iv))
            encryptor = cipher.encryptor()
            ciphertext = encryptor.update(data_bytes) + encryptor.finalize()
            
            # Encrypt AES key with RSA
            encrypted_aes_key = public_key.encrypt(
                aes_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            # Combine encrypted key + IV + tag + ciphertext
            hybrid_data = {
                "encrypted_key": base64.b64encode(encrypted_aes_key).decode('utf-8'),
                "iv": base64.b64encode(iv).decode('utf-8'),
                "tag": base64.b64encode(encryptor.tag).decode('utf-8'),
                "ciphertext": base64.b64encode(ciphertext).decode('utf-8'),
                "method": "hybrid_rsa_aes"
            }
            
            return base64.b64encode(json.dumps(hybrid_data).encode('utf-8')).decode('utf-8')
        
        else:
            # Direct RSA encryption for small data
            encrypted = public_key.encrypt(
                data_bytes,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            return base64.b64encode(encrypted).decode('utf-8')
    
    def rsa_decrypt(self, encrypted_data: str, private_key_id: str) -> str:
        """Decrypt data with RSA private key"""
        
        # Get private key from database
        with sqlite3.connect(self.key_db_path) as conn:
            cursor = conn.execute('''
                SELECT encrypted_key FROM encryption_keys 
                WHERE key_id = ? AND key_algorithm = 'rsa'
            ''', (private_key_id,))
            
            result = cursor.fetchone()
            if not result:
                raise ValueError(f"RSA private key not found: {private_key_id}")
            
            # Decrypt private key
            master_fernet = Fernet(self.master_key)
            private_key_pem = master_fernet.decrypt(result[0])
        
        private_key = serialization.load_pem_private_key(private_key_pem, password=None)
        
        try:
            # Try to decode as hybrid encryption first
            decoded_data = base64.b64decode(encrypted_data.encode('utf-8'))
            hybrid_data = json.loads(decoded_data.decode('utf-8'))
            
            if hybrid_data.get("method") == "hybrid_rsa_aes":
                # Hybrid decryption
                encrypted_aes_key = base64.b64decode(hybrid_data["encrypted_key"].encode('utf-8'))
                iv = base64.b64decode(hybrid_data["iv"].encode('utf-8'))
                tag = base64.b64decode(hybrid_data["tag"].encode('utf-8'))
                ciphertext = base64.b64decode(hybrid_data["ciphertext"].encode('utf-8'))
                
                # Decrypt AES key with RSA
                aes_key = private_key.decrypt(
                    encrypted_aes_key,
                    padding.OAEP(
                        mgf=padding.MGF1(algorithm=hashes.SHA256()),
                        algorithm=hashes.SHA256(),
                        label=None
                    )
                )
                
                # Decrypt data with AES
                cipher = Cipher(algorithms.AES(aes_key), modes.GCM(iv, tag))
                decryptor = cipher.decryptor()
                decrypted_bytes = decryptor.update(ciphertext) + decryptor.finalize()
                
                return decrypted_bytes.decode('utf-8')
        
        except (json.JSONDecodeError, KeyError):
            # Direct RSA decryption
            encrypted_bytes = base64.b64decode(encrypted_data.encode('utf-8'))
            
            decrypted = private_key.decrypt(
                encrypted_bytes,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            return decrypted.decode('utf-8')
    
    def generate_data_hash(self, data: Any) -> str:
        """Generate secure hash for data integrity"""
        if isinstance(data, str):
            data_bytes = data.encode('utf-8')
        elif isinstance(data, dict) or isinstance(data, list):
            data_bytes = json.dumps(data, sort_keys=True).encode('utf-8')
        else:
            data_bytes = str(data).encode('utf-8')
        
        # Use SHA-256 for integrity checking
        return hashlib.sha256(data_bytes).hexdigest()
    
    def verify_data_integrity(self, data: Any, expected_hash: str) -> bool:
        """Verify data integrity using hash"""
        actual_hash = self.generate_data_hash(data)
        return actual_hash == expected_hash
    
    def secure_delete_key(self, key_id: str) -> bool:
        """Securely delete encryption key"""
        try:
            # Mark key as deleted in database
            with sqlite3.connect(self.key_db_path) as conn:
                conn.execute('''
                    UPDATE encryption_keys 
                    SET status = 'deleted', encrypted_key = NULL
                    WHERE key_id = ?
                ''', (key_id,))
            
            # Remove from memory
            if key_id in self.encryption_keys:
                # Overwrite key in memory (best effort)
                key_data = self.encryption_keys[key_id]["key"]
                if isinstance(key_data, bytes):
                    # Overwrite with random data
                    overwrite = secrets.token_bytes(len(key_data))
                    key_data = overwrite
                
                del self.encryption_keys[key_id]
            
            self._log_key_usage(key_id, "deleted", success=True)
            return True
            
        except Exception as e:
            self._log_key_usage(key_id, "deleted", success=False)
            return False
    
    def get_key_usage_stats(self, days: int = 30) -> Dict[str, Any]:
        """Get encryption key usage statistics"""
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        with sqlite3.connect(self.key_db_path) as conn:
            # Usage by operation
            cursor = conn.execute('''
                SELECT operation, COUNT(*) as count
                FROM key_usage_log 
                WHERE timestamp >= ?
                GROUP BY operation
            ''', (start_date,))
            
            operation_stats = dict(cursor.fetchall())
            
            # Usage by key
            cursor = conn.execute('''
                SELECT key_id, COUNT(*) as count
                FROM key_usage_log 
                WHERE timestamp >= ?
                GROUP BY key_id
                ORDER BY count DESC
                LIMIT 10
            ''', (start_date,))
            
            key_usage = [{"key_id": key_id, "count": count} for key_id, count in cursor.fetchall()]
            
            # Success rate
            cursor = conn.execute('''
                SELECT success, COUNT(*) as count
                FROM key_usage_log 
                WHERE timestamp >= ?
                GROUP BY success
            ''', (start_date,))
            
            success_stats = dict(cursor.fetchall())
            total_operations = sum(success_stats.values())
            success_rate = (success_stats.get(1, 0) / total_operations * 100) if total_operations > 0 else 0
            
            # Active keys
            cursor = conn.execute('''
                SELECT COUNT(*) FROM encryption_keys WHERE status = 'active'
            ''')
            active_keys = cursor.fetchone()[0]
            
            return {
                "period_days": days,
                "operation_stats": operation_stats,
                "top_keys": key_usage,
                "success_rate": round(success_rate, 2),
                "total_operations": total_operations,
                "active_keys": active_keys
            }
    
    def export_public_keys(self) -> Dict[str, str]:
        """Export all public keys for external use"""
        public_keys = {}
        
        with sqlite3.connect(self.key_db_path) as conn:
            cursor = conn.execute('''
                SELECT key_id, encrypted_key FROM encryption_keys 
                WHERE key_purpose = 'rsa_public' AND status = 'active'
            ''')
            
            for key_id, public_key_pem in cursor.fetchall():
                # Remove '_public' suffix from key_id
                clean_key_id = key_id.replace('_public', '')
                public_keys[clean_key_id] = public_key_pem.decode('utf-8') if isinstance(public_key_pem, bytes) else public_key_pem
        
        return public_keys
    
    def backup_encryption_keys(self, backup_password: str) -> str:
        """Create encrypted backup of all encryption keys"""
        
        # Get all keys
        with sqlite3.connect(self.key_db_path) as conn:
            cursor = conn.execute('''
                SELECT key_id, key_purpose, encrypted_key, key_algorithm, created_at, expires_at
                FROM encryption_keys 
                WHERE status = 'active'
            ''')
            
            keys_data = []
            for row in cursor.fetchall():
                keys_data.append({
                    "key_id": row[0],
                    "key_purpose": row[1],
                    "encrypted_key": base64.b64encode(row[2]).decode('utf-8') if isinstance(row[2], bytes) else row[2],
                    "key_algorithm": row[3],
                    "created_at": row[4],
                    "expires_at": row[5]
                })
        
        backup_data = {
            "backup_timestamp": datetime.utcnow().isoformat(),
            "key_count": len(keys_data),
            "keys": keys_data
        }
        
        # Encrypt backup with provided password
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'backup_salt_change_in_prod',
            iterations=100000,
        )
        backup_key = base64.urlsafe_b64encode(kdf.derive(backup_password.encode()))
        
        backup_fernet = Fernet(backup_key)
        encrypted_backup = backup_fernet.encrypt(json.dumps(backup_data).encode('utf-8'))
        
        # Save backup file
        backup_filename = f"key_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.enc"
        with open(backup_filename, 'wb') as f:
            f.write(encrypted_backup)
        
        return backup_filename

# Global encryption manager instance
encryption_manager = EnterpriseEncryption()