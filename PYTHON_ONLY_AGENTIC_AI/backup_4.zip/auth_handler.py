#!/usr/bin/env python3
"""
Enterprise Authentication Handler
Supports OAuth2, SAML, and Role-Based Access Control (RBAC)
"""

import os
import jwt
import time
import hashlib
import secrets
import requests
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Set
from functools import wraps
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, parse_qs
import base64
import json

class EnterpriseAuth:
    """Enterprise-grade authentication with OAuth2/SAML and RBAC"""
    
    def __init__(self):
        self.secret_key = os.environ.get('ENTERPRISE_SECRET_KEY', secrets.token_hex(32))
        self.sessions = {}  # In production, use Redis
        self.users = {}     # In production, use database
        self.roles = self._init_default_roles()
        self.audit_log = []
        
    def _init_default_roles(self) -> Dict[str, Dict]:
        """Initialize default enterprise roles"""
        return {
            "super_admin": {
                "permissions": ["*"],  # All permissions
                "description": "Full system access"
            },
            "admin": {
                "permissions": [
                    "user:manage", "workflow:manage", "tool:manage", 
                    "audit:view", "system:configure"
                ],
                "description": "Administrative access"
            },
            "analyst": {
                "permissions": [
                    "workflow:create", "workflow:execute", "tool:use", 
                    "research:access", "data:analyze"
                ],
                "description": "Data analysis and workflow execution"
            },
            "viewer": {
                "permissions": [
                    "workflow:view", "audit:view_own", "dashboard:view"
                ],
                "description": "Read-only access"
            },
            "guest": {
                "permissions": ["dashboard:view"],
                "description": "Limited guest access"
            }
        }
    
    def authenticate_oauth2(self, provider: str, auth_code: str, 
                           redirect_uri: str) -> Dict[str, Any]:
        """OAuth2 authentication flow"""
        try:
            # OAuth2 provider configurations
            providers = {
                "google": {
                    "token_url": "https://oauth2.googleapis.com/token",
                    "user_info_url": "https://www.googleapis.com/oauth2/v2/userinfo",
                    "client_id": os.environ.get('GOOGLE_CLIENT_ID'),
                    "client_secret": os.environ.get('GOOGLE_CLIENT_SECRET')
                },
                "microsoft": {
                    "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                    "user_info_url": "https://graph.microsoft.com/v1.0/me",
                    "client_id": os.environ.get('MICROSOFT_CLIENT_ID'),
                    "client_secret": os.environ.get('MICROSOFT_CLIENT_SECRET')
                },
                "okta": {
                    "token_url": f"{os.environ.get('OKTA_DOMAIN')}/oauth2/default/v1/token",
                    "user_info_url": f"{os.environ.get('OKTA_DOMAIN')}/oauth2/default/v1/userinfo",
                    "client_id": os.environ.get('OKTA_CLIENT_ID'),
                    "client_secret": os.environ.get('OKTA_CLIENT_SECRET')
                }
            }
            
            if provider not in providers:
                raise ValueError(f"Unsupported OAuth2 provider: {provider}")
            
            config = providers[provider]
            
            # Exchange authorization code for access token
            token_data = {
                "grant_type": "authorization_code",
                "code": auth_code,
                "redirect_uri": redirect_uri,
                "client_id": config["client_id"],
                "client_secret": config["client_secret"]
            }
            
            token_response = requests.post(config["token_url"], data=token_data, timeout=10)
            token_response.raise_for_status()
            tokens = token_response.json()
            
            # Get user information
            headers = {"Authorization": f"Bearer {tokens['access_token']}"}
            user_response = requests.get(config["user_info_url"], headers=headers, timeout=10)
            user_response.raise_for_status()
            user_info = user_response.json()
            
            # Create or update user
            user_email = user_info.get('email') or user_info.get('userPrincipalName')
            user_name = user_info.get('name') or user_info.get('displayName', user_email)
            
            user = self._create_or_update_user(
                email=user_email,
                name=user_name,
                provider=provider,
                provider_id=user_info.get('id', user_info.get('sub'))
            )
            
            # Create session
            session_token = self._create_session(user)
            
            self._audit_log("oauth2_login", {
                "user_email": user_email,
                "provider": provider,
                "success": True
            })
            
            return {
                "success": True,
                "user": user,
                "session_token": session_token,
                "expires_in": 3600
            }
            
        except Exception as e:
            self._audit_log("oauth2_login", {
                "provider": provider,
                "error": str(e),
                "success": False
            })
            return {
                "success": False,
                "error": f"OAuth2 authentication failed: {str(e)}"
            }
    
    def authenticate_saml(self, saml_response: str) -> Dict[str, Any]:
        """SAML authentication flow"""
        try:
            # Decode SAML response
            saml_decoded = base64.b64decode(saml_response).decode('utf-8')
            
            # Parse SAML XML
            root = ET.fromstring(saml_decoded)
            
            # Extract user attributes (simplified - production needs proper SAML parsing)
            namespaces = {
                'saml': 'urn:oasis:names:tc:SAML:2.0:assertion',
                'samlp': 'urn:oasis:names:tc:SAML:2.0:protocol'
            }
            
            # Find assertion
            assertion = root.find('.//saml:Assertion', namespaces)
            if assertion is None:
                raise ValueError("No SAML assertion found")
            
            # Extract subject (user identifier)
            subject = assertion.find('.//saml:Subject/saml:NameID', namespaces)
            if subject is None:
                raise ValueError("No SAML subject found")
            
            user_email = subject.text
            
            # Extract attributes
            attributes = {}
            for attr in assertion.findall('.//saml:AttributeStatement/saml:Attribute', namespaces):
                attr_name = attr.get('Name')
                attr_value = attr.find('saml:AttributeValue', namespaces)
                if attr_value is not None:
                    attributes[attr_name] = attr_value.text
            
            # Create or update user
            user_name = attributes.get('displayName', attributes.get('name', user_email))
            
            user = self._create_or_update_user(
                email=user_email,
                name=user_name,
                provider="saml",
                provider_id=user_email,
                attributes=attributes
            )
            
            # Create session
            session_token = self._create_session(user)
            
            self._audit_log("saml_login", {
                "user_email": user_email,
                "success": True
            })
            
            return {
                "success": True,
                "user": user,
                "session_token": session_token,
                "expires_in": 3600
            }
            
        except Exception as e:
            self._audit_log("saml_login", {
                "error": str(e),
                "success": False
            })
            return {
                "success": False,
                "error": f"SAML authentication failed: {str(e)}"
            }
    
    def _create_or_update_user(self, email: str, name: str, provider: str, 
                              provider_id: str, attributes: Dict = None) -> Dict[str, Any]:
        """Create or update user in the system"""
        user_id = hashlib.sha256(email.encode()).hexdigest()[:16]
        
        # Determine role based on email domain or attributes
        role = self._determine_user_role(email, attributes or {})
        
        user = {
            "user_id": user_id,
            "email": email,
            "name": name,
            "role": role,
            "provider": provider,
            "provider_id": provider_id,
            "created_at": datetime.utcnow().isoformat(),
            "last_login": datetime.utcnow().isoformat(),
            "attributes": attributes or {},
            "permissions": self.roles[role]["permissions"]
        }
        
        self.users[user_id] = user
        return user
    
    def _determine_user_role(self, email: str, attributes: Dict) -> str:
        """Determine user role based on email domain or SAML attributes"""
        # Check SAML attributes first
        if 'role' in attributes:
            saml_role = attributes['role'].lower()
            if saml_role in self.roles:
                return saml_role
        
        # Check email domain patterns
        domain = email.split('@')[1] if '@' in email else ''
        
        # Enterprise role mapping (customize for your organization)
        role_mappings = {
            'admin.company.com': 'super_admin',
            'company.com': 'admin',
            'contractor.company.com': 'analyst'
        }
        
        return role_mappings.get(domain, 'viewer')  # Default to viewer
    
    def _create_session(self, user: Dict[str, Any]) -> str:
        """Create JWT session token"""
        payload = {
            "user_id": user["user_id"],
            "email": user["email"],
            "role": user["role"],
            "permissions": user["permissions"],
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600  # 1 hour expiry
        }
        
        token = jwt.encode(payload, self.secret_key, algorithm='HS256')
        
        # Store session (in production, use Redis with TTL)
        self.sessions[token] = {
            "user": user,
            "created_at": datetime.utcnow(),
            "last_activity": datetime.utcnow()
        }
        
        return token
    
    def validate_session(self, token: str) -> Dict[str, Any]:
        """Validate JWT session token"""
        try:
            # Decode JWT
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            
            # Check if session exists
            if token not in self.sessions:
                return {"valid": False, "error": "Session not found"}
            
            session = self.sessions[token]
            
            # Update last activity
            session["last_activity"] = datetime.utcnow()
            
            return {
                "valid": True,
                "user": session["user"],
                "permissions": payload["permissions"]
            }
            
        except jwt.ExpiredSignatureError:
            return {"valid": False, "error": "Token expired"}
        except jwt.InvalidTokenError:
            return {"valid": False, "error": "Invalid token"}
    
    def check_permission(self, user_permissions: List[str], 
                        required_permission: str) -> bool:
        """Check if user has required permission"""
        # Super admin has all permissions
        if "*" in user_permissions:
            return True
        
        # Check exact permission match
        if required_permission in user_permissions:
            return True
        
        # Check wildcard permissions (e.g., "workflow:*" allows "workflow:create")
        for perm in user_permissions:
            if perm.endswith(":*"):
                permission_prefix = perm[:-1]  # Remove "*"
                if required_permission.startswith(permission_prefix):
                    return True
        
        return False
    
    def require_permission(self, permission: str):
        """Decorator to require specific permission"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Get token from request (this would be from request headers in real app)
                token = kwargs.get('_auth_token') or getattr(func, '_current_token', None)
                
                if not token:
                    return {"error": "Authentication required", "code": 401}
                
                session = self.validate_session(token)
                if not session["valid"]:
                    return {"error": session["error"], "code": 401}
                
                if not self.check_permission(session["permissions"], permission):
                    self._audit_log("permission_denied", {
                        "user_id": session["user"]["user_id"],
                        "permission": permission,
                        "function": func.__name__
                    })
                    return {"error": f"Permission denied: {permission}", "code": 403}
                
                # Add user context to function
                kwargs['_current_user'] = session["user"]
                kwargs['_user_permissions'] = session["permissions"]
                
                result = func(*args, **kwargs)
                
                # Log successful access
                self._audit_log("function_access", {
                    "user_id": session["user"]["user_id"],
                    "function": func.__name__,
                    "permission": permission,
                    "success": True
                })
                
                return result
            return wrapper
        return decorator
    
    def logout(self, token: str) -> Dict[str, Any]:
        """Logout user and invalidate session"""
        if token in self.sessions:
            user = self.sessions[token]["user"]
            del self.sessions[token]
            
            self._audit_log("logout", {
                "user_id": user["user_id"],
                "success": True
            })
            
            return {"success": True, "message": "Logged out successfully"}
        
        return {"success": False, "error": "Session not found"}
    
    def get_auth_urls(self) -> Dict[str, str]:
        """Get OAuth2 authorization URLs for supported providers"""
        base_url = os.environ.get('BASE_URL', 'http://localhost:8000')
        redirect_uri = f"{base_url}/auth/callback"
        
        urls = {}
        
        # Google OAuth2
        if os.environ.get('GOOGLE_CLIENT_ID'):
            google_params = {
                'client_id': os.environ.get('GOOGLE_CLIENT_ID'),
                'redirect_uri': redirect_uri,
                'scope': 'openid email profile',
                'response_type': 'code',
                'access_type': 'offline'
            }
            urls['google'] = f"https://accounts.google.com/o/oauth2/v2/auth?{urlencode(google_params)}"
        
        # Microsoft OAuth2
        if os.environ.get('MICROSOFT_CLIENT_ID'):
            microsoft_params = {
                'client_id': os.environ.get('MICROSOFT_CLIENT_ID'),
                'redirect_uri': redirect_uri,
                'scope': 'openid email profile',
                'response_type': 'code'
            }
            urls['microsoft'] = f"https://login.microsoftonline.com/common/oauth2/v2.0/authorize?{urlencode(microsoft_params)}"
        
        # SAML
        if os.environ.get('SAML_SSO_URL'):
            urls['saml'] = os.environ.get('SAML_SSO_URL')
        
        return urls
    
    def _audit_log(self, action: str, details: Dict[str, Any]):
        """Log audit events for compliance"""
        audit_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "action": action,
            "details": details,
            "ip_address": details.get("ip_address", "unknown"),
            "user_agent": details.get("user_agent", "unknown")
        }
        
        self.audit_log.append(audit_entry)
        
        # In production, write to secure audit database
        print(f"AUDIT: {audit_entry}")
    
    def get_audit_logs(self, start_date: str = None, end_date: str = None, 
                      user_id: str = None) -> List[Dict[str, Any]]:
        """Retrieve audit logs for compliance reporting"""
        logs = self.audit_log.copy()
        
        # Filter by date range
        if start_date:
            logs = [log for log in logs if log["timestamp"] >= start_date]
        if end_date:
            logs = [log for log in logs if log["timestamp"] <= end_date]
        
        # Filter by user
        if user_id:
            logs = [log for log in logs if log["details"].get("user_id") == user_id]
        
        return logs
    
    def create_api_key(self, user_id: str, name: str, permissions: List[str] = None) -> Dict[str, Any]:
        """Create API key for programmatic access"""
        api_key = f"ent_{secrets.token_urlsafe(32)}"
        
        user = self.users.get(user_id)
        if not user:
            return {"error": "User not found"}
        
        # Use user permissions if not specified
        if permissions is None:
            permissions = user["permissions"]
        
        # Validate permissions don't exceed user's permissions
        for perm in permissions:
            if not self.check_permission(user["permissions"], perm):
                return {"error": f"Cannot grant permission: {perm}"}
        
        api_key_data = {
            "api_key": api_key,
            "name": name,
            "user_id": user_id,
            "permissions": permissions,
            "created_at": datetime.utcnow().isoformat(),
            "last_used": None,
            "active": True
        }
        
        # Store API key (in production, hash the key)
        if not hasattr(self, 'api_keys'):
            self.api_keys = {}
        self.api_keys[api_key] = api_key_data
        
        self._audit_log("api_key_created", {
            "user_id": user_id,
            "api_key_name": name,
            "permissions": permissions
        })
        
        return {
            "success": True,
            "api_key": api_key,
            "expires_at": "never"  # API keys don't expire by default
        }
    
    def validate_api_key(self, api_key: str) -> Dict[str, Any]:
        """Validate API key for programmatic access"""
        if not hasattr(self, 'api_keys') or api_key not in self.api_keys:
            return {"valid": False, "error": "Invalid API key"}
        
        key_data = self.api_keys[api_key]
        
        if not key_data["active"]:
            return {"valid": False, "error": "API key disabled"}
        
        # Update last used
        key_data["last_used"] = datetime.utcnow().isoformat()
        
        return {
            "valid": True,
            "user_id": key_data["user_id"],
            "permissions": key_data["permissions"]
        }

# Global enterprise auth instance
enterprise_auth = EnterpriseAuth()