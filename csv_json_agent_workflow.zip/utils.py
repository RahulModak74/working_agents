import os
import datetime

def register_template_filters(app):
    """Register custom template filters for the Flask application"""
    
    @app.template_filter('last_modified')
    def last_modified_filter(filename):
        """Get the last modified time of a file"""
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        if os.path.exists(filepath):
            timestamp = os.path.getmtime(filepath)
            return datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
        return 'Unknown'
    
    @app.template_filter('pretty_json')
    def pretty_json_filter(value):
        """Format JSON nicely"""
        import json
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except:
                return value
        return json.dumps(value, indent=2)
