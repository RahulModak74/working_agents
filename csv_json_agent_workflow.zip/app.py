from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
import json
import os
import time
from werkzeug.utils import secure_filename
from utils import register_template_filters

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for flash messages

# Configuration
UPLOAD_FOLDER = 'static/uploads'
TEMPLATES_FOLDER = 'static/templates'
ALLOWED_EXTENSIONS = {'json'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['TEMPLATES_FOLDER'] = TEMPLATES_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Register template filters
register_template_filters(app)

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['TEMPLATES_FOLDER'], exist_ok=True)

# Sample workflow templates
SAMPLE_TEMPLATES = {
    'vulnerability_detection': 'vulnerability_detection_workflow.json',
    'security_analysis': 'security_analysis_workflow.json',
    'basic_workflow': 'basic_workflow.json'
}

# Load templates
def load_template(template_name):
    try:
        filepath = os.path.join(app.config['TEMPLATES_FOLDER'], SAMPLE_TEMPLATES.get(template_name, template_name))
        with open(filepath, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading template: {e}")
        return []

# Save workflow
def save_workflow(workflow_data, filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    with open(filepath, 'w') as f:
        json.dump(workflow_data, f, indent=2)
    return filepath

# Load user workflows
def get_user_workflows():
    workflows = []
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        if filename.endswith('.json'):
            workflows.append(filename)
    return workflows

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Routes
@app.route('/')
def index():
    user_workflows = get_user_workflows()
    return render_template('index.html', 
                          user_workflows=user_workflows,
                          sample_templates=SAMPLE_TEMPLATES)
@app.route('/simple-editor', methods=['GET'])
def simple_editor():
    """A simpler editor alternative"""
    workflow_name = request.args.get('workflow', '')
    workflow_data = '[]'  # Default empty workflow
    
    if workflow_name:
        try:
            with open(os.path.join(app.config['UPLOAD_FOLDER'], workflow_name), 'r') as f:
                workflow_data = f.read()
        except Exception as e:
            flash(f"Error loading workflow: {e}", "error")
    
    return render_template('simple_editor.html', 
                           workflow_data=workflow_data,
                           filename=workflow_name or "workflow_name.json")
@app.route('/editor', methods=['GET'])
def editor():
    workflow_name = request.args.get('workflow')
    template_name = request.args.get('template')
    
    workflow_data = []
    filename = ""
    
    if workflow_name:
        filename = workflow_name
        try:
            with open(os.path.join(app.config['UPLOAD_FOLDER'], workflow_name), 'r') as f:
                workflow_data = json.load(f)
        except Exception as e:
            flash(f"Error loading workflow: {e}", "error")
    elif template_name:
        workflow_data = load_template(template_name)
        filename = f"new_{template_name}.json"
    
    return render_template('editor.html', 
                          workflow_data=json.dumps(workflow_data, indent=2),
                          filename=filename)

@app.route('/save', methods=['POST'])
def save():
    data = request.json
    workflow_data = data.get('workflow')
    filename = data.get('filename', 'new_workflow.json')
    
    if not filename.endswith('.json'):
        filename += '.json'
    
    try:
        filepath = save_workflow(json.loads(workflow_data), filename)
        return jsonify({"status": "success", "message": f"Workflow saved to {filename}", "filename": filename})
    except Exception as e:
        return jsonify({"status": "error", "message": f"Error saving workflow: {e}"})

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part', 'error')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        flash(f'File {filename} uploaded successfully', 'success')
        return redirect(url_for('editor', workflow=filename))
    
    flash('Invalid file type. Only JSON files are allowed.', 'error')
    return redirect(url_for('index'))

@app.route('/preview', methods=['POST'])
def preview():
    data = request.json
    workflow_data = data.get('workflow')
    
    try:
        parsed_workflow = json.loads(workflow_data)
        
        # Generate workflow summary
        num_agents = len(parsed_workflow)
        agent_types = {}
        tools_used = set()
        has_dynamic_agent = False
        
        for agent in parsed_workflow:
            agent_type = agent.get('type', 'standard')
            agent_types[agent_type] = agent_types.get(agent_type, 0) + 1
            
            if agent_type == 'dynamic':
                has_dynamic_agent = True
            
            if 'tools' in agent and isinstance(agent['tools'], list):
                for tool in agent['tools']:
                    tools_used.add(tool)
        
        summary = f"Workflow contains {num_agents} agents"
        if has_dynamic_agent:
            summary += f" (including {agent_types.get('dynamic', 0)} dynamic agents)"
        
        if tools_used:
            summary += f" using {len(tools_used)} unique tools."
        
        return jsonify({
            "status": "success", 
            "workflow": parsed_workflow,
            "summary": summary
        })
    except Exception as e:
        return jsonify({"status": "error", "message": f"Invalid JSON: {e}"})

@app.route('/delete/<filename>', methods=['POST'])
def delete_workflow(filename):
    try:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
        if os.path.exists(file_path):
            os.remove(file_path)
            flash(f'Workflow {filename} deleted successfully', 'success')
        else:
            flash(f'Workflow {filename} not found', 'error')
    except Exception as e:
        flash(f'Error deleting workflow: {e}', 'error')
    
    return redirect(url_for('index'))

@app.route('/duplicate/<filename>', methods=['POST'])
def duplicate_workflow(filename):
    try:
        source_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
        if not os.path.exists(source_path):
            flash(f'Workflow {filename} not found', 'error')
            return redirect(url_for('index'))
        
        # Create a new filename
        name_parts = filename.rsplit('.', 1)
        new_filename = f"{name_parts[0]}_copy.{name_parts[1]}"
        
        # Ensure the new filename is unique
        counter = 1
        while os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], new_filename)):
            new_filename = f"{name_parts[0]}_copy_{counter}.{name_parts[1]}"
            counter += 1
        
        # Copy the workflow
        with open(source_path, 'r') as src_file:
            workflow_data = json.load(src_file)
        
        target_path = os.path.join(app.config['UPLOAD_FOLDER'], new_filename)
        with open(target_path, 'w') as dest_file:
            json.dump(workflow_data, dest_file, indent=2)
        
        flash(f'Workflow duplicated as {new_filename}', 'success')
    except Exception as e:
        flash(f'Error duplicating workflow: {e}', 'error')
    
    return redirect(url_for('index'))

@app.route('/export/<filename>')
def export_workflow(filename):
    try:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
        if not os.path.exists(file_path):
            flash(f'Workflow {filename} not found', 'error')
            return redirect(url_for('index'))
        
        with open(file_path, 'r') as file:
            workflow_data = file.read()
        
        return jsonify({
            "status": "success",
            "filename": filename,
            "data": workflow_data
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Error exporting workflow: {e}"
        })

# Initialize with sample templates if they don't exist
def init_templates():
    # Sample basic workflow template
    basic_workflow = [
        {
            "agent": "analyzer",
            "content": "Analyze the provided data and identify key patterns.",
            "tools": ["planning:chain_of_thought"],
            "output_format": {
                "type": "json",
                "schema": {
                    "patterns": ["string"],
                    "insights": ["string"]
                }
            }
        },
        {
            "agent": "reporter",
            "content": "Generate a comprehensive report based on the analysis.",
            "readFrom": ["analyzer"],
            "output_format": {
                "type": "markdown",
                "sections": [
                    "Executive Summary",
                    "Findings",
                    "Recommendations"
                ]
            }
        }
    ]
    
    # Simplified vulnerability detection workflow
    vuln_detection_workflow = [
        {
            "agent": "vulnerability_scanner",
            "content": "Scan the target systems for potential vulnerabilities. Extract CVE information, severity levels, and affected components.",
            "file": "vulnerability_scan_results.csv",
            "tools": ["sql:query"],
            "output_format": {
                "type": "json",
                "schema": {
                    "scan_summary": {
                        "total_vulnerabilities": "number",
                        "critical_count": "number",
                        "high_count": "number"
                    },
                    "top_vulnerabilities": ["string"]
                }
            },
            "memory_id": "vulnerability_analysis"
        },
        {
            "agent": "risk_assessor",
            "content": "Analyze the vulnerabilities and determine their risk to the organization.",
            "readFrom": ["vulnerability_scanner"],
            "tools": ["planning:chain_of_thought"],
            "memory_id": "vulnerability_analysis",
            "output_format": {
                "type": "json",
                "schema": {
                    "risk_assessment": [
                        {
                            "vulnerability_id": "string",
                            "risk_score": "number",
                            "impact": "string"
                        }
                    ]
                }
            }
        },
        {
            "agent": "dynamic_agent",
            "type": "dynamic",
            "initial_prompt": "Based on the risk assessment, determine what action should be taken: 'patch', 'mitigate', or 'accept'.",
            "readFrom": ["vulnerability_scanner", "risk_assessor"],
            "memory_id": "vulnerability_analysis",
            "output_format": {
                "type": "json",
                "schema": {
                    "action": "string",
                    "reasoning": "string"
                }
            },
            "actions": {
                "patch": {
                    "agent": "patch_manager",
                    "content": "Develop a patching plan for the vulnerabilities."
                },
                "mitigate": {
                    "agent": "mitigation_planner",
                    "content": "Develop mitigation strategies for the vulnerabilities."
                },
                "accept": {
                    "agent": "risk_documenter",
                    "content": "Document the acceptance of risk for these vulnerabilities."
                }
            }
        }
    ]
    
    # Security analysis workflow
    security_workflow = [
        {
            "agent": "threat_modeler",
            "content": "Create a threat model for the system based on available documentation.",
            "tools": ["planning:chain_of_thought"],
            "output_format": {
                "type": "json",
                "schema": {
                    "identified_threats": ["string"],
                    "attack_vectors": ["string"]
                }
            },
            "memory_id": "security_analysis"
        },
        {
            "agent": "security_analyst",
            "content": "Analyze the threat model and identify security controls.",
            "readFrom": ["threat_modeler"],
            "memory_id": "security_analysis",
            "output_format": {
                "type": "markdown",
                "sections": [
                    "Security Assessment",
                    "Recommendations",
                    "Implementation Plan"
                ]
            }
        }
    ]
    
    # Save default templates if they don't exist
    templates = {
        'basic_workflow.json': basic_workflow,
        'vulnerability_detection_workflow.json': vuln_detection_workflow,
        'security_analysis_workflow.json': security_workflow
    }
    
    for filename, workflow in templates.items():
        template_path = os.path.join(app.config['TEMPLATES_FOLDER'], filename)
        if not os.path.exists(template_path):
            with open(template_path, 'w') as f:
                json.dump(workflow, f, indent=2)

if __name__ == '__main__':
    init_templates()
    app.run(debug=True, host='0.0.0.0', port=5000)
