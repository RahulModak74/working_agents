# Flask Workflow Editor

A sleek, modern web-based JSON workflow editor built with Flask. This application allows you to create, edit, and visualize complex workflow JSON files similar to vulnerability detection workflows.

## Features

- **Intuitive JSON Editor**: Powered by Monaco Editor (the same editor that powers VS Code)
- **Component Templates**: Pre-defined templates for common workflow components
- **Workflow Visualization**: Visual representation of agent interactions and relationships
- **Syntax Validation**: Real-time JSON validation with error highlighting
- **Import/Export**: Upload existing JSON workflows or download your creations
- **Documentation**: Built-in reference for workflow structure and components

## Installation

1. Clone the repository:

```bash
git clone https://github.com/yourusername/flask-workflow-editor.git
cd flask-workflow-editor
```

2. Create a virtual environment and install dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

3. Run the application:

```bash
python app.py
```

4. Open your browser and navigate to `http://localhost:5000`

## Requirements

- Python 3.7+
- Flask
- Werkzeug

## Project Structure

```
flask-workflow-editor/
├── app.py               # Main Flask application
├── utils.py             # Utility functions
├── requirements.txt     # Project dependencies
├── static/
│   ├── css/
│   │   └── style.css    # Custom CSS styles
│   ├── templates/       # Workflow template files
│   └── uploads/         # User uploaded workflows
├── templates/
│   ├── index.html       # Homepage template
│   └── editor.html      # Editor page template
└── README.md            # Project documentation
```

## Usage

### Creating a New Workflow

1. From the homepage, click on one of the provided templates or "Create Empty Workflow"
2. Use the Monaco Editor to edit your JSON workflow
3. Use the component templates from the sidebar to insert common patterns
4. Click "Preview" to visualize your workflow
5. Enter a filename and click "Save" to store your workflow

### Editing an Existing Workflow

1. From the homepage, find your workflow in the "Your Workflows" section
2. Click "Edit" to open it in the editor
3. Make your changes and save

### Importing and Exporting

- To import: Click "Upload Workflow" on the homepage and select your JSON file
- To export: Your saved workflows are stored in the `static/uploads` directory

## Component Templates

The editor provides several built-in templates for common workflow components:

- **Standard Agent**: Basic agent with content and memory
- **Agent with Tools**: Agent configured with planning and SQL tools
- **Dynamic Agent**: Agent that can choose between multiple actions
- **Output Formats**: JSON and Markdown output specifications
- **Tools**: Common tool configurations for planning, SQL, and vector databases

## Customization

You can customize the application by:

1. Adding new workflow templates in `static/templates/`
2. Modifying the component templates in the editor.html file
3. Changing the styling in `static/css/style.css`
4. Extending the application with new features in `app.py`

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [Flask](https://flask.palletsprojects.com/) - The web framework used
- [Monaco Editor](https://microsoft.github.io/monaco-editor/) - The code editor that powers the application
- [D3.js](https://d3js.org/) - Used for workflow visualization
- [Bootstrap](https://getbootstrap.com/) - Frontend framework
