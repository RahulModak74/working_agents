const express = require('express');
const hana = require('@sap/hana-client');
const cors = require('cors');
const geoip = require('geoip-lite');
const http = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
require('dotenv').config();

// Initialize Express and HTTP server
const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 8300;

// ==================================
// MIDDLEWARE CONFIGURATION
// ==================================

// Session middleware (before CORS)
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        maxAge: 24 * 60 * 60 * 1000,
        sameSite: 'none'
    }
}));

// Updated CORS configuration
app.use(cors({
    origin: true, // Reflects the request origin
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
}));

// Additional headers for CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept');
    // Handle preflight
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

app.use(express.json());

// ==================================
// DATABASE CONFIGURATION
// ==================================

// HANA Connection Configuration
const hanaConfig = {
    host: process.env.HANA_HOST || '134.209.157.124',
    port: process.env.HANA_PORT || '39013',
    serverNode: `${process.env.HANA_HOST || '134.209.157.124'}:${process.env.HANA_PORT || '39013'}`,
    uid: process.env.HANA_USERNAME || 'SYSTEM',
    pwd: process.env.HANA_PASSWORD || 'YourStrongPassword123!',
    databaseName: process.env.HANA_DATABASE || 'SYSTEMDB',
    connectionTimeout: 100000,
    connectTimeout: 100000
};

const pool = hana.createPool(hanaConfig);

// Database initialization function
const initDb = async () => {
    const connection = await pool.getConnection();
    try {
        const tables = [
            {
                name: 'TRACKING_10',
                createQuery: `
                    CREATE COLUMN TABLE TRACKING_10 (
                        ID INT PRIMARY KEY,
                        TIMESTAMP TIMESTAMP,
                        URL NVARCHAR(255),
                        REFERRER NVARCHAR(255),
                        IP_ADDRESS NVARCHAR(50),
                        USER_AGENT NVARCHAR(500),
                        PLATFORM NVARCHAR(100),
                        LANGUAGE NVARCHAR(50),
                        HOSTNAME NVARCHAR(255),
                        SESSION_ID NVARCHAR(100),
                        BROWSER_ID NVARCHAR(100),
                        FINGERPRINT_ID NVARCHAR(100),
                        CLICKDATA NVARCHAR(4000),
                        ENHANCED_DATA_ID NVARCHAR(255)
                    )
                `
            },
            {
                name: 'REGION_DETAILS',
                createQuery: `
                    CREATE COLUMN TABLE REGION_DETAILS (
                        ID INT PRIMARY KEY,
                        IP_ADDRESS NVARCHAR(50),
                        COUNTRY NVARCHAR(100),
                        REGION NVARCHAR(100),
                        CITY NVARCHAR(100)
                    )
                `
            },
            {
                name: 'SECURITY_HEADERS',
                createQuery: `
                    CREATE COLUMN TABLE SECURITY_HEADERS (
                        ID INTEGER,
                        TRACKING_ID BIGINT PRIMARY KEY,
                        SESSION_ID NVARCHAR(256),
                        SECURITY_CORS_ORIGIN NVARCHAR(1024),
                        SECURITY_ALLOW_ORIGIN NVARCHAR(1024),
                        SECURITY_ALLOW_METHODS NVARCHAR(1024),
                        SECURITY_ALLOW_HEADERS NVARCHAR(1024),
                        SECURITY_ALLOW_CREDENTIALS TINYINT,
                        SECURITY_EXPOSE_HEADERS NVARCHAR(1024),
                        SECURITY_MAX_AGE INTEGER,
                        SECURITY_FRAME_ANCESTORS NVARCHAR(1024),
                        SECURITY_CSP NVARCHAR(4000),
                        SECURITY_REFERRER_POLICY NVARCHAR(1024),
                        SECURITY_PERMISSIONS_POLICY NVARCHAR(2000),
                        SECURITY_CROSS_ORIGIN NVARCHAR(1024),
                        SECURITY_IS_FRAMED TINYINT,
                        SECURITY_SANDBOX NVARCHAR(1024),
                        DOM_CHANGES_COUNT INTEGER DEFAULT 0,
                        DOM_MONITORING_ACTIVE TINYINT DEFAULT 1,
                        DOM_LAST_CHANGE TIMESTAMP,
                        DOM_ADDED_ELEMENTS NVARCHAR(4000),
                        DOM_REMOVED_ELEMENTS NVARCHAR(4000),
                        DOM_MODIFIED_ATTRIBUTES NVARCHAR(4000),
                        DOM_SENSITIVE_CHANGES NVARCHAR(4000),
                        DOM_SECURITY_VIOLATIONS NVARCHAR(4000),
                        TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        HARDWARE_CONCURRENCY INTEGER DEFAULT 0,
                        PLATFORM_VERSION NVARCHAR(256),
                        CANVAS_FINGERPRINT NVARCHAR(2048),
                        WEBGL_VENDOR NVARCHAR(1024),
                        WEBGL_RENDERER NVARCHAR(1024),
                        WEB_DRIVER TINYINT,
                        MAX_TOUCH_POINTS INTEGER
                    )
                `
            },
            {
                name: 'USERS',
                createQuery: `
                    CREATE COLUMN TABLE USERS (
                        ID INT PRIMARY KEY,
                        USERNAME NVARCHAR(100) UNIQUE,
                        PASSWORDHASH NVARCHAR(255),
                        HOSTNAME NVARCHAR(255),
                        VERSION NVARCHAR(50)
                    )
                `
            }
        ];

        for (const table of tables) {
            const tableExists = await connection.exec(`
                SELECT COUNT(*) AS TABLE_COUNT 
                FROM TABLES 
                WHERE SCHEMA_NAME = CURRENT_SCHEMA 
                AND TABLE_NAME = ?
            `, [table.name]);

            if (tableExists[0].TABLE_COUNT === 0) {
                await connection.exec(table.createQuery);
                console.log(`${table.name} table created`);
            }
        }

        console.log('Database initialization complete');
    } catch (err) {
        console.error('Error initializing tables:', err);
        throw err;
    } finally {
        connection.close();
    }
};

// ==================================
// SOCKET.IO CONFIGURATION
// ==================================

// Socket.IO setup with updated CORS
const io = new Server(server, {
    cors: {
        origin: true,
        methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        credentials: true,
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept']
    },
    transports: ['websocket', 'polling'],
    pingTimeout: 60000,
    pingInterval: 25000,
    cookie: true
});

// Socket.IO event handlers
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);

    socket.on('join', (data) => {
        const sessionId = data.sessionId;
        socket.join(sessionId);
        console.log(`User joined session room: ${sessionId}`);
    });

    socket.on('sendMessage', (data) => {
        const { sessionId, message } = data;
        io.to(sessionId).emit('receiveMessage', message);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
});

// ==================================
// SESSION MANAGEMENT
// ==================================

let sessions = [];  // Store session IDs in an array

// Periodically clean up inactive sessions
const CLEANUP_INTERVAL = 60000; // 60 seconds
const SESSION_TIMEOUT = 900000; // 15 minutes

setInterval(() => {
    const now = Date.now();
    for (const sessionId in sessions) {
        if (now - sessions[sessionId] > SESSION_TIMEOUT) {
            delete sessions[sessionId];
        }
    }
}, CLEANUP_INTERVAL);

// ==================================
// AUTHENTICATION MIDDLEWARE
// ==================================

const authMiddleware = (req, res, next) => {
    if (req.session && req.session.authenticated) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// ==================================
// AUTH ROUTES
// ==================================

// Login endpoint
app.post('/login', async (req, res) => {
    if (!req.body.username || !req.body.password) {
        return res.status(400).json({
            success: false,
            message: "Username and password are required"
        });
    }

    const { username, password } = req.body;
    let connection;

    try {
        connection = await pool.getConnection();

        const query = `
            SELECT USERNAME, PASSWORDHASH, HOSTNAME, VERSION
            FROM USERS
            WHERE USERNAME = ?
            LIMIT 1
        `;

        const result = await connection.exec(query, [username]);

        if (result.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid credentials"
            });
        }

        const user = result[0];

        if (password === user.PASSWORDHASH) {
            // Set session data
            req.session.authenticated = true;
            req.session.username = username;
            req.session.hostname = user.HOSTNAME;
            req.session.version = user.VERSION;

            res.json({
                success: true,
                username: username,
                hostname: user.HOSTNAME,
                version: user.VERSION
            });
        } else {
            res.status(401).json({
                success: false,
                message: "Invalid credentials"
            });
        }
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// Logout endpoint
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Error logging out' });
        }
        res.json({ success: true, message: 'Logged out successfully' });
    });
});

// ==================================
// TRACKING ROUTES
// ==================================

app.post('/track', async (req, res) => {
    let connection;
    try {
        connection = await pool.getConnection();
        const data = req.body;
        const ipAddress = data.ipAddress || '';
        const userAgent = data.deviceInfo ? data.deviceInfo.userAgent.replace(/'/g, "\\'") : '';
        const platform = data.deviceInfo ? data.deviceInfo.platform : '';
        const language = data.deviceInfo ? data.deviceInfo.language : '';
        const hostname = data.hostname || '';
        const sessionId = data.sessionId || '';
        const browser_id = data.browser_id || '';
        const fingerprint_id = data.fingerprint_id || '';
        const timestamp = new Date(data.timestamp).toISOString().slice(0, 19).replace('T', ' ');
        const clickDataString = JSON.stringify(data.clickData || '', null, 2);

        // Generate enhanced data ID
        function generateEnhancedDataId(sessionId) {
            let numericValue = 0;
            for (let i = 0; i < sessionId.length; i++) {
                numericValue += sessionId.charCodeAt(i);
            }
            const timestamp = Date.now();
            return parseInt(`${timestamp}${numericValue % 1000}`);
        }

        const enhanced_data_id = generateEnhancedDataId(sessionId);

        // Geo location data
        const geo = geoip.lookup(ipAddress);
        const country = geo?.country || 'Unknown';
        const region = geo?.region || 'Unknown';
        const city = geo?.city || 'Unknown';

        // Get next IDs
        const [maxTrackingId, maxRegionId, maxSecurityId] = await Promise.all([
            connection.exec('SELECT COALESCE(MAX(ID), 0) AS MAX_ID FROM TRACKING_10'),
            connection.exec('SELECT COALESCE(MAX(ID), 0) AS MAX_ID FROM REGION_DETAILS'),
            connection.exec('SELECT COALESCE(MAX(ID), 0) AS MAX_ID FROM SECURITY_HEADERS')
        ]);

        const nextTrackingId = maxTrackingId[0].MAX_ID + 1;
        const nextRegionId = maxRegionId[0].MAX_ID + 1;
        const nextSecurityId = maxSecurityId[0].MAX_ID + 1;

        // Sanitize and prepare security headers data
        const securityHeaders = data.securityHeaders || {};
        const domMonitoring = data.domMonitoringData || {
            dom_changes_count: 0,
            dom_monitoring_active: 1,
            dom_last_change: new Date().toISOString(),
            dom_added_elements: '[]',
            dom_removed_elements: '[]',
            dom_modified_attributes: '[]',
            dom_sensitive_changes: '[]',
            dom_security_violations: '[]'
        };

        // Sanitize canvas fingerprint
        let canvasFingerprint = '';
        try {
            const canvasData = typeof securityHeaders.canvas_fingerprint === 'string' ?
                securityHeaders.canvas_fingerprint :
                JSON.stringify(securityHeaders.canvas_fingerprint || '');
            canvasFingerprint = canvasData.replace(/'/g, "''");
        } catch (e) {
            console.error('Error processing canvas fingerprint:', e);
            canvasFingerprint = '';
        }

        // Insert tracking data
        await connection.exec(`
            INSERT INTO TRACKING_10 (
                ID, TIMESTAMP, URL, REFERRER, IP_ADDRESS, USER_AGENT, 
                PLATFORM, LANGUAGE, HOSTNAME, SESSION_ID, 
                BROWSER_ID, FINGERPRINT_ID, CLICKDATA, ENHANCED_DATA_ID
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            nextTrackingId, timestamp, data.url, data.referrer, ipAddress, userAgent,
            platform, language, hostname, sessionId,
            browser_id, fingerprint_id, clickDataString, enhanced_data_id.toString()
        ]);

        // Insert region data
        await connection.exec(`
            INSERT INTO REGION_DETAILS (ID, IP_ADDRESS, COUNTRY, REGION, CITY)
            SELECT ?, ?, ?, ?, ?
            FROM DUMMY 
            WHERE NOT EXISTS (
                SELECT 1 FROM REGION_DETAILS WHERE IP_ADDRESS = ?
            )
        `, [nextRegionId, ipAddress, country, region, city, ipAddress]);

        // Format the DOM last change timestamp
        const domLastChange = domMonitoring.dom_last_change ?
            new Date(domMonitoring.dom_last_change).toISOString().slice(0, 19).replace('T', ' ') :
            new Date().toISOString().slice(0, 19).replace('T', ' ');

        // Insert security headers data
        await connection.exec(`
            INSERT INTO SECURITY_HEADERS (
                ID, TRACKING_ID, SESSION_ID, 
                SECURITY_CORS_ORIGIN, SECURITY_ALLOW_ORIGIN, SECURITY_ALLOW_METHODS, SECURITY_ALLOW_HEADERS,
                SECURITY_ALLOW_CREDENTIALS, SECURITY_EXPOSE_HEADERS, SECURITY_MAX_AGE, SECURITY_FRAME_ANCESTORS,
                SECURITY_CSP, SECURITY_REFERRER_POLICY, SECURITY_PERMISSIONS_POLICY, SECURITY_CROSS_ORIGIN,
                SECURITY_IS_FRAMED, SECURITY_SANDBOX, DOM_CHANGES_COUNT, DOM_MONITORING_ACTIVE,
                DOM_LAST_CHANGE, DOM_ADDED_ELEMENTS, DOM_REMOVED_ELEMENTS, DOM_MODIFIED_ATTRIBUTES,
                DOM_SENSITIVE_CHANGES, DOM_SECURITY_VIOLATIONS, TIMESTAMP,
                HARDWARE_CONCURRENCY, PLATFORM_VERSION, CANVAS_FINGERPRINT, WEBGL_VENDOR, WEBGL_RENDERER,
                WEB_DRIVER, MAX_TOUCH_POINTS
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?
            )
        `, [
            nextSecurityId,
            enhanced_data_id,
            sessionId,
            securityHeaders.security_cors_origin || '',
            securityHeaders.security_allow_origin || '*',
            securityHeaders.security_allow_methods || '',
            securityHeaders.security_allow_headers || '',
            securityHeaders.security_allow_credentials ? 1 : 0,
            securityHeaders.security_expose_headers || '',
            securityHeaders.security_max_age || 86400,
            securityHeaders.security_frame_ancestors || '',
            securityHeaders.security_csp || '',
            securityHeaders.security_referrer_policy || '',
            securityHeaders.security_permissions_policy || '',
            securityHeaders.security_cross_origin || '',
            securityHeaders.security_is_framed ? 1 : 0,
            securityHeaders.security_sandbox || '',
            parseInt(domMonitoring.dom_changes_count) || 0,
            domMonitoring.dom_monitoring_active ? 1 : 0,
            domLastChange,
            domMonitoring.dom_added_elements || '[]',
            domMonitoring.dom_removed_elements || '[]',
            domMonitoring.dom_modified_attributes || '[]',
            domMonitoring.dom_sensitive_changes || '[]',
            domMonitoring.dom_security_violations || '[]',
            securityHeaders.hardware_concurrency || 0,
            securityHeaders.platform_version || '',
            canvasFingerprint,
            (securityHeaders.webgl_vendor || '').toString(),
            (securityHeaders.webgl_renderer || '').toString(),
            securityHeaders.web_driver ? 1 : 0,
            securityHeaders.max_touch_points || 0
        ]);

        sessions[sessionId] = Date.now();

        io.emit('newTrackingData', {
            sessionId,
            url: data.url,
            timestamp,
            ipAddress,
            country,
            region,
            city
        });

        res.json({ status: 'success' });
    } catch (error) {
        console.error("Error in tracking:", error);
        res.status(500).json({ status: 'error', message: error.message });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// ==================================
// SESSION MANAGEMENT ROUTES
// ==================================

app.post('/session', (req, res) => {
    console.log('Received /session request:', req.body); // Debug log
    const sessionId = req.body.sessionId;
    if (sessions[sessionId]) {
        res.json({ success: true });
    } else {
        res.status(400).json({ success: false, message: 'Session ID not found' });
    }
});

app.get('/sessions', (req, res) => {
    res.json(Object.keys(sessions));
});

app.post('/terminate-session', (req, res) => {
    const { sessionId } = req.body;

    if (sessions[sessionId]) {
        // Notify the session to disconnect
        io.to(sessionId).emit('session-terminated', {
            message: 'Your session has been terminated by an administrator.'
        });

        // Remove session from active sessions
        delete sessions[sessionId];

        // Notify all clients about the updated sessions list
        io.emit('sessions-updated', Object.keys(sessions));

        res.json({ success: true, message: 'Session terminated successfully.' });
    } else {
        res.status(400).json({ success: false, message: 'Session ID not found.' });
    }
});


// ==================================
// REPORTING AND ANALYTICS ROUTES
// ==================================

app.get('/rawreport', async (req, res) => {
    const customUrl = req.query.custom_url || 'Parx';
    const startDate = req.query.start_date || '2025-01-01';
    const endDate = req.query.end_date || '2025-12-31';
    const host = req.session.hostname || 'myraymond';
    let connection;

    try {
        connection = await pool.getConnection();

        const query = `
            SELECT t.SESSION_ID, t.IP_ADDRESS, t.TIMESTAMP, t.URL,
                   r.COUNTRY, r.REGION, r.CITY
            FROM TRACKING_10 t
            LEFT JOIN REGION_DETAILS r ON t.IP_ADDRESS = r.IP_ADDRESS
            WHERE t.URL LIKE ?
            AND t.TIMESTAMP BETWEEN ? AND ?
            AND t.HOSTNAME LIKE ?
            ORDER BY t.TIMESTAMP DESC
            LIMIT 100
        `;

        const result = await connection.exec(query, [
            `%${customUrl}%`,
            startDate,
            endDate,
            `%${host}%`
        ]);

        const transformedData = result.map(row => ({
            session_id: row.SESSION_ID,
            ip_address: row.IP_ADDRESS,
            timestamp: row.TIMESTAMP,
            url: row.URL,
            country: row.COUNTRY,
            region: row.REGION,
            city: row.CITY
        }));

        const uniqueSessions = new Set();
        const uniqueData = transformedData.filter(row => {
            if (!uniqueSessions.has(row.session_id)) {
                uniqueSessions.add(row.session_id);
                return true;
            }
            return false;
        });

        res.json({
            data: uniqueData,
            custom_url: customUrl,
            start_date: startDate,
            end_date: endDate
        });

    } catch (error) {
        console.error('Error in /rawreport:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

app.get('/session_journey', async (req, res) => {
    const sessionid = req.query.session_id || '5bdfqtws1';
    let connection;
    try {
        connection = await pool.getConnection();
        const query = `
            SELECT URL, TIMESTAMP, CLICKDATA
            FROM TRACKING_10
            WHERE SESSION_ID LIKE ?
            ORDER BY TIMESTAMP
            LIMIT 100
        `;
        const result = await connection.exec(query, [`%${sessionid}%`]);

        // Process each row to break down the timestamp
        const enhancedData = result.map(row => {
            const timestamp = new Date(row.TIMESTAMP);
            return {
                url: row.URL,
                timestamp: row.TIMESTAMP,
                clickdata: row.CLICKDATA,
                date: timestamp.toISOString().split('T')[0],
                time: timestamp.toTimeString().split(' ')[0].substring(0, 8)
            };
        });

        res.json(enhancedData);
    } catch (error) {
        console.error('Error in /session_journey:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

app.get('/sessionswithoutip', async (req, res) => {
    const startDate = req.query.start_date || '2024-12-01';
    const endDate = req.query.end_date || '2025-02-15';
    let connection;

    try {
        connection = await pool.getConnection();

        // Query for sessions without IP addresses
        const query = `
            SELECT 
                t.SESSION_ID as sessionId,
                COUNT(*) as requestCount 
            FROM TRACKING_10 t
            WHERE (t.IP_ADDRESS = '' OR t.IP_ADDRESS IS NULL)
            GROUP BY t.SESSION_ID
            ORDER BY requestCount DESC
        `;

        const result = await connection.exec(query);
        console.log('Query result:', result);  // Debug log

        res.json({
            data: result.map(row => ({
                sessionId: row.SESSIONID,
                requestCount: row.REQUESTCOUNT,
                viewDetails: "View Details"  // Added for consistent binding
            }))
        });

    } catch (error) {
        console.error('Error in sessionswithoutip:', error);
        res.status(500).json({
            error: 'Internal Server Error',
            message: error.message
        });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

app.get('/summary-dashboard', async (req, res) => {
    const startDate = req.query.start_date || '2024-12-01';
    const endDate = req.query.end_date || '2025-02-15';
    let connection;

    try {
        connection = await pool.getConnection();

        // Query 1: Bot Requests
        const query1 = `
            SELECT COUNT(*) AS BOT_REQUESTS
            FROM TRACKING_10 t
            WHERE USER_AGENT LIKE '%bot%'
        `;
        const botResult = await connection.exec(query1);

        // Query 2: Suspicious Sessions
        const query2 = `
            SELECT COUNT(DISTINCT SESSION_ID) AS SUSPICIOUS_SESSIONS
            FROM TRACKING_10 t
            WHERE TIMESTAMP >= ADD_SECONDS(CURRENT_TIMESTAMP, -3600)
            GROUP BY SESSION_ID
            HAVING COUNT(*) > 10
        `;
        const suspiciousResult = await connection.exec(query2);

        // Query 3: High Frequency IPs
        const query3 = `
            SELECT COUNT(DISTINCT IP_ADDRESS) AS HIGH_FREQUENCY_IPS
            FROM TRACKING_10 t
            WHERE TIMESTAMP BETWEEN ADD_DAYS(CURRENT_DATE, -7) AND CURRENT_DATE
            GROUP BY IP_ADDRESS
            HAVING COUNT(*) > 1000
        `;
        const frequencyResult = await connection.exec(query3);

        // Query 4: XSS Attempts
        const query4 = `
            SELECT COUNT(*) AS XSS_ATTEMPTS
            FROM TRACKING_10 t
            WHERE URL LIKE '%<script>%'
        `;
        const xssResult = await connection.exec(query4);

        // Query 5: CSRF Attempts
        const query5 = `
            SELECT COUNT(*) AS CSRF_ATTEMPTS
            FROM TRACKING_10 t
            WHERE REFERRER IS NOT NULL
        `;
        const csrfResult = await connection.exec(query5);

        // Query 6: Scraping Activities
        const query6 = `
            SELECT COUNT(*) AS SCRAPING_ACTIVITIES
            FROM TRACKING_10 t
            WHERE URL LIKE '%scrape%'
        `;
        const scrapingResult = await connection.exec(query6);

        // Query 7: Mimic Bot Activities
        const query7 = `
            SELECT COUNT(*) AS MIMIC_BOT_ACTIVITIES
            FROM TRACKING_10 t
            WHERE USER_AGENT NOT LIKE '%bot%'
            AND IP_ADDRESS IN (
                SELECT DISTINCT IP_ADDRESS
                FROM TRACKING_10
                WHERE USER_AGENT LIKE '%bot%'
            )
        `;
        const mimicResult = await connection.exec(query7);

        // Query 8: Unusual Bot Activities
        const query8 = `
            SELECT COUNT(*) AS UNUSUAL_BOT_ACTIVITIES
            FROM TRACKING_10 t
            WHERE USER_AGENT LIKE '%bot%'
            AND TIMESTAMP BETWEEN ADD_DAYS(CURRENT_DATE, -30) AND CURRENT_DATE
        `;
        const unusualResult = await connection.exec(query8);

        // Query 9: Suspicious Referrers
        const query9 = `
            SELECT COUNT(*) AS SUSPICIOUS_REFERRERS
            FROM TRACKING_10 t
            WHERE REFERRER IS NOT NULL
        `;
        const referrerResult = await connection.exec(query9);

        console.log('Query results:', {
            botResult,
            suspiciousResult,
            frequencyResult,
            xssResult,
            csrfResult,
            scrapingResult,
            mimicResult,
            unusualResult,
            referrerResult
        });

        // Send consistent response format
        res.json({
            data: {
                botRequests: botResult[0]?.BOT_REQUESTS || 0,
                suspiciousSessions: suspiciousResult.length || 0,
                highFrequencyIPs: frequencyResult.length || 0,
                xssAttempts: xssResult[0]?.XSS_ATTEMPTS || 0,
                csrfAttempts: csrfResult[0]?.CSRF_ATTEMPTS || 0,
                scrapingActivities: scrapingResult[0]?.SCRAPING_ACTIVITIES || 0,
                mimicBotActivities: mimicResult[0]?.MIMIC_BOT_ACTIVITIES || 0,
                unusualBotActivities: unusualResult[0]?.UNUSUAL_BOT_ACTIVITIES || 0,
                suspiciousReferrers: referrerResult[0]?.SUSPICIOUS_REFERRERS || 0
            },
            start_date: startDate,
            end_date: endDate
        });

    } catch (error) {
        console.error('Error in summary-dashboard:', error);
        res.status(500).json({
            error: 'Internal Server Error',
            message: error.message
        });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// ==================================
// ERROR HANDLING
// ==================================

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// ==================================
// SERVER INITIALIZATION
// ==================================

// Initialize database and start server
initDb()
    .then(() => {
        server.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });
    })
    .catch(err => {
        console.error('Failed to initialize database:', err);
        console.log('Retrying database initialization in 5 seconds...');
        setTimeout(initDb, 5000);
    });