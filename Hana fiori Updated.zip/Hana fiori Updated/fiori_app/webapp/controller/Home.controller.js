sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.Home", {
        onNavToSessionData: function () {
            this.getOwnerComponent().getRouter().navTo("sessionData");
        },

        onNavToSessionJourney: function () {
            this.getOwnerComponent().getRouter().navTo("sessionJourney", {
                sessionId: "5bdfqtws1"
            });
        }
    });
});