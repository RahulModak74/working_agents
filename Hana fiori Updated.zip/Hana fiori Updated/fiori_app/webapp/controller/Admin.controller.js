sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.Admin", {
        onInit: function () {
            var oModel = new JSONModel({
                custom_url: "Ethnix",
                start_date: "2024-10-01",
                end_date: "2024-10-31",
                messageData: {
                    sessionId: "",
                    message: ""
                },
                activeSessions: ""
            });
            this.getView().setModel(oModel);

            var oPaginationModel = new JSONModel({
                currentPage: 1,
                totalPages: 1,
                hasNextPage: false,
                hasPreviousPage: false
            });

            this.getView().setModel(oPaginationModel, "pagination");

            // Initial fetch with default values
            this._fetchData("Ethnix", "2024-10-01", "2024-10-31");
            
            // Fetch active sessions initially and set up polling
            this._fetchActiveSessions();
            setInterval(this._fetchActiveSessions.bind(this), 30000); // Poll every 30 seconds
        },

        _fetchActiveSessions: function() {
            var that = this;
            fetch('http://localhost:8010/sessions')
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function(sessions) {
                    that.getView().getModel().setProperty("/activeSessions", sessions.join(', '));
                })
                .catch(function(error) {
                    console.error("Error fetching active sessions:", error);
                });
        },

        onSendMessage: function() {
            var oModel = this.getView().getModel();
            var messageData = oModel.getProperty("/messageData");
            
            // Trim session ID
            messageData.sessionId = messageData.sessionId.trim();
            
            if (!messageData.sessionId || !messageData.message) {
                MessageToast.show("Please enter both Session ID and Message");
                return;
            }

            fetch('http://localhost:8010/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messageData)
            })
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(function(data) {
                MessageToast.show("Message sent successfully");
                // Clear the message input but keep the session ID
                oModel.setProperty("/messageData/message", "");
            })
            .catch(function(error) {
                console.error("Error sending message:", error);
                MessageToast.show("Error sending message: " + error.message);
            });
        },

        // ... rest of the existing controller methods ...
        _fetchData: function (customUrl, startDate, endDate) {
            var that = this;

            startDate = new Date(startDate).toISOString().split('T')[0];
            endDate = new Date(endDate).toISOString().split('T')[0];

            fetch(`http://localhost:8010/admin?custom_url=${customUrl}&start_date=${startDate}&end_date=${endDate}`)
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function (data) {
                    console.log("Fetched Admin Data:", data);
                    that.getView().getModel().setData({
                        data: data.data,
                        custom_url: data.custom_url,
                        start_date: data.start_date,
                        end_date: data.end_date,
                        messageData: that.getView().getModel().getProperty("/messageData"),
                        activeSessions: that.getView().getModel().getProperty("/activeSessions")
                    });
                    that._updatePaginationModel(data.data.length);
                    that._paginate();
                })
                .catch(function (error) {
                    console.error("Error fetching admin session data:", error);
                    MessageToast.show("Error fetching data. Please try again.");
                });
        },

        onStartDateChange: function (oEvent) {
            var startDate = oEvent.getParameter("value");
            this.getView().getModel().setProperty("/start_date", startDate);
        },

        onEndDateChange: function (oEvent) {
            var endDate = oEvent.getParameter("value");
            this.getView().getModel().setProperty("/end_date", endDate);
        },

        _updatePaginationModel: function (totalRecords) {
            var oPaginationModel = this.getView().getModel("pagination");
            var totalPages = Math.ceil(totalRecords / 10);
            oPaginationModel.setProperty("/totalPages", totalPages);
            oPaginationModel.setProperty("/hasNextPage", totalPages > 1);
            oPaginationModel.setProperty("/hasPreviousPage", false);
        },

        _paginate: function () {
            var oModel = this.getView().getModel();
            var data = oModel.getProperty("/data");
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");

            var startIdx = (currentPage - 1) * 10;
            var paginatedData = data.slice(startIdx, startIdx + 10);

            oModel.setProperty("/paginatedData", paginatedData);
        },

        onNextPage: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");
            var totalPages = oPaginationModel.getProperty("/totalPages");

            if (currentPage < totalPages) {
                oPaginationModel.setProperty("/currentPage", currentPage + 1);
                this._paginate();
                this._updatePaginationState();
            }
        },

        onPreviousPage: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");

            if (currentPage > 1) {
                oPaginationModel.setProperty("/currentPage", currentPage - 1);
                this._paginate();
                this._updatePaginationState();
            }
        },

        _updatePaginationState: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");
            var totalPages = oPaginationModel.getProperty("/totalPages");

            oPaginationModel.setProperty("/hasNextPage", currentPage < totalPages);
            oPaginationModel.setProperty("/hasPreviousPage", currentPage > 1);
        },

        onSearch: function () {
            var customUrl = this.getView().getModel().getProperty("/custom_url");
            var startDate = this.getView().getModel().getProperty("/start_date");
            var endDate = this.getView().getModel().getProperty("/end_date");

            this._fetchData(customUrl, startDate, endDate);
        },

        onItemPress: function(oEvent) {
            var oItem = oEvent.getSource();
            var sessionId = oItem.getBindingContext().getProperty("session_id");
            
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("sessionJourney", {
                sessionId: sessionId
            });
        }
    });
});