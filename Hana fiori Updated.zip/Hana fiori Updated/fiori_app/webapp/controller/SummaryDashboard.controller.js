sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.SummaryDashboard", {
        onInit: function () {
            var oModel = new JSONModel({
                data: {
                    botRequests: 0,
                    suspiciousSessions: 0,
                    highFrequencyIPs: 0,
                    xssAttempts: 0,
                    csrfAttempts: 0,
                    scrapingActivities: 0,
                    mimicBotActivities: 0,
                    unusualBotActivities: 0,
                    suspiciousReferrers: 0
                }
            });
            this.getView().setModel(oModel, "summaryModel");
            this._fetchData();
        },

        _fetchData: function () {
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            // Updated the URL to include the server address
            fetch('http://134.209.157.124:8200/summary-dashboard', {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(function (response) {
                console.log("Fetched summary data:", response);
                that.getView().getModel("summaryModel").setData(response);
            })
            .catch(function (error) {
                console.error("Error fetching summary data:", error);
                MessageBox.error("Error loading summary data: " + error.message);
            })
            .finally(function () {
                sap.ui.core.BusyIndicator.hide();
            });
        },

        onRefresh: function () {
            this._fetchData();
            MessageToast.show("Refreshing data...");
        }
    });
});