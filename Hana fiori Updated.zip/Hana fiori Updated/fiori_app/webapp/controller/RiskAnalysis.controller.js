sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.RiskAnalysis", {
        onInit: function () {
            var oModel = new JSONModel({
                sessions: [],
                totalSessions: 0,
                selectedSession: null
            });
            this.getView().setModel(oModel);

            // Initial data fetch
            this._fetchRiskAnalysisData();
        },

        _fetchRiskAnalysisData: function () {
            var that = this;
            
            // Show loading indicator
            sap.ui.core.BusyIndicator.show(0);

            fetch('http://134.209.157.124:8300/risk-analysis')
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function (data) {
                    console.log("Fetched risk analysis data:", data);
                    
                    // Transform data for the model
                    that.getView().getModel().setProperty("/sessions", data.sessions);
                    that.getView().getModel().setProperty("/totalSessions", data.total_sessions);
                })
                .catch(function (error) {
                    console.error("Error fetching risk analysis data:", error);
                    MessageBox.error("Error loading risk analysis data: " + error.message);
                })
                .finally(function () {
                    // Hide loading indicator
                    sap.ui.core.BusyIndicator.hide();
                });
        },

        onRefresh: function () {
            this._fetchRiskAnalysisData();
            MessageToast.show("Refreshing risk analysis data...");
        },

        onViewSessionJourney: function (oEvent) {
            var oItem = oEvent.getSource();
            var sessionId = oItem.getBindingContext().getProperty("session_id");
            
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("sessionJourney", {
                sessionId: sessionId
            });
        },

        onToggleDetails: function (oEvent) {
            var oButton = oEvent.getSource();
            var oContext = oButton.getBindingContext();
            var oSession = oContext.getObject();
            
            // Set the selected session for details panel
            this.getView().getModel().setProperty("/selectedSession", oSession);
            
            // Show the details container
            this.byId("detailsContainer").setVisible(true);
        },
        
        onCloseDetails: function () {
            this.byId("detailsContainer").setVisible(false);
        },

        onTerminateSession: function (oEvent) {
            var that = this;
            var oButton = oEvent.getSource();
            var oContext = oButton.getBindingContext();
            var sessionId = oContext.getProperty("session_id");
            
            // Confirm dialog
            MessageBox.confirm(
                "Are you sure you want to terminate session " + sessionId + "?", 
                {
                    title: "Confirm Session Termination",
                    onClose: function (oAction) {
                        if (oAction === MessageBox.Action.OK) {
                            that._terminateSession(sessionId);
                        }
                    }
                }
            );
        },
        
        _terminateSession: function (sessionId) {
            var that = this;
            
            // Show loading indicator
            sap.ui.core.BusyIndicator.show(0);
            
            fetch('http://134.209.157.124:8300/risk-analysis', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId: sessionId })
            })
            .then(function (response) {
                if (!response.ok) {
                    return response.json().then(function(errorData) {
                        throw new Error(errorData.error || 'Failed to terminate session');
                    });
                }
                return response.json();
            })
            .then(function (data) {
                MessageToast.show("Session terminated successfully");
                
                // Refresh data after termination
                that._fetchRiskAnalysisData();
                
                // If details panel is showing the terminated session, close it
                var selectedSession = that.getView().getModel().getProperty("/selectedSession");
                if (selectedSession && selectedSession.session_id === sessionId) {
                    that.byId("detailsContainer").setVisible(false);
                }
            })
            .catch(function (error) {
                console.error("Error terminating session:", error);
                MessageBox.error("Error terminating session: " + error.message);
            })
            .finally(function () {
                // Hide loading indicator
                sap.ui.core.BusyIndicator.hide();
            });
        },

        formatRiskScore: function (iScore) {
            if (iScore >= 8) {
                return "Error";
            } else if (iScore >= 5) {
                return "Warning";
            } else {
                return "Success";
            }
        },

        formatRiskScoreText: function (iScore) {
            return iScore + "/10";
        },

        formatBooleanRisk: function (iValue) {
            return iValue > 0 ? "Yes" : "No";
        },

        formatRiskFactorState: function (iValue) {
            return iValue > 0 ? "Error" : "None";
        },

        formatDuration: function (iSeconds) {
            return iSeconds + "s";
        },

        formatTimestamp: function (sTimestamp) {
            if (!sTimestamp) {
                return "";
            }
            var oDate = new Date(sTimestamp);
            return oDate.toLocaleString();
        }
    });
});