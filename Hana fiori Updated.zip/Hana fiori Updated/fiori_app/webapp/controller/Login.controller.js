sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.Login", {
        onInit: function () {
            var oLoginModel = new JSONModel({
                username: "",
                password: "",
                errorMessage: ""
            });
            this.getView().setModel(oLoginModel, "login");
        },

        onLogin: function () {
            var oLoginModel = this.getView().getModel("login");
            var sUsername = oLoginModel.getProperty("/username");
            var sPassword = oLoginModel.getProperty("/password");
        
            // Clear any previous error message
            oLoginModel.setProperty("/errorMessage", "");
        
            fetch('http://134.209.157.124:8300/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: sUsername,
                    password: sPassword
                }),
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Store session info
                    sessionStorage.setItem('userSession', JSON.stringify({
                        username: sUsername,
                        authenticated: true
                    }));
                    
                    // Update authentication state
                    var oAuthModel = this.getView().getModel("auth");
                    oAuthModel.setProperty("/isAuthenticated", true);
        
                    // Navigate to home page
                    this.getOwnerComponent().getRouter().navTo("home");
                } else {
                    oLoginModel.setProperty("/errorMessage", "Invalid username or password");
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                oLoginModel.setProperty("/errorMessage", "An error occurred during login");
            });
        }
    });
});