sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.App", {
        onInit: function () {
            // Create authentication model
            var oAuthModel = new JSONModel({
                isAuthenticated: false
            });
            this.getView().setModel(oAuthModel, "auth");

            // Check authentication status
            this.checkAuthStatus();

            // Add route handlers
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.attachRouteMatched(this.onRouteMatched, this);
        },

        checkAuthStatus: function () {
            var userSession = sessionStorage.getItem('userSession');
            var oAuthModel = this.getView().getModel("auth");

            if (userSession) {
                var sessionData = JSON.parse(userSession);
                oAuthModel.setProperty("/isAuthenticated", sessionData.authenticated);
                if (!sessionData.authenticated) {
                    this.getOwnerComponent().getRouter().navTo("login");
                }
            } else {
                oAuthModel.setProperty("/isAuthenticated", false);
                this.getOwnerComponent().getRouter().navTo("login");
            }
        },

        onRouteMatched: function (oEvent) {
            var sRouteName = oEvent.getParameter("name");

            // Allow access to login route always
            if (sRouteName === "login") {
                return;
            }

            // Check authentication for other routes
            var userSession = sessionStorage.getItem('userSession');
            if (!userSession || !JSON.parse(userSession).authenticated) {
                this.getOwnerComponent().getRouter().navTo("login");
            }
        },

        onSideNavButtonPress: function () {
            var oToolPage = this.byId("toolPage");
            oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
        },

        onNavToSessionData: function () {
            this.getOwnerComponent().getRouter().navTo("sessionData");
        },

        onNavToSessionJourney: function () {
            this.getOwnerComponent().getRouter().navTo("sessionJourney", {
                sessionId: "5bdfqtws1"
            });
        },
        onNavToSessionsWithoutIP: function () {
            this.getOwnerComponent().getRouter().navTo("sessionsWithoutIP");
        },

        // Navigation function for Summary Dashboard
        onNavToSummaryDashboard: function () {
            this.getOwnerComponent().getRouter().navTo("summaryDashboard");
        },

        onNavToAdmin: function () {
            this.getOwnerComponent().getRouter().navTo("admin");
        },

        onNavToTerminateSession: function () {
            this.getOwnerComponent().getRouter().navTo("TerminateSession");
        },

        onNavToRiskAnalysis: function () {
            this.getOwnerComponent().getRouter().navTo("riskAnalysis");
        }
    });
});