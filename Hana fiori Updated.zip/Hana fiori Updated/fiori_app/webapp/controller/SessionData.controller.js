sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.App", {
        onInit: function () {
            var oModel = new JSONModel({
                custom_url: "Parx",
                start_date: "2025-01-01",
                end_date: "2025-12-31"
            });
            this.getView().setModel(oModel);

            var oPaginationModel = new JSONModel({
                currentPage: 1,
                totalPages: 1,
                hasNextPage: false,
                hasPreviousPage: false
            });

            this.getView().setModel(oPaginationModel, "pagination");

            this._fetchData("Parx", "2025-01-01", "2025-12-31"); // Initial fetch with default values
        },

        _fetchData: function (customUrl, startDate, endDate) {
            var that = this;

            // Ensure startDate and endDate are in the correct format (YYYY-MM-DD)
            startDate = new Date(startDate).toISOString().split('T')[0];
            endDate = new Date(endDate).toISOString().split('T')[0];

            fetch(`http://134.209.157.124:8300/rawreport?custom_url=${customUrl}&start_date=${startDate}&end_date=${endDate}`)
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    console.log("Fetched Data:", data);
                    that.getView().getModel().setData({
                        data: data.data,
                        custom_url: data.custom_url,
                        start_date: data.start_date,
                        end_date: data.end_date
                    });
                    that._updatePaginationModel(data.data.length);
                    that._paginate();
                })
                .catch(function (error) {
                    console.error("Error fetching session data:", error);
                });
        },

        onStartDateChange: function (oEvent) {
            var startDate = oEvent.getParameter("value");
            this.getView().getModel().setProperty("/start_date", startDate);
        },

        onEndDateChange: function (oEvent) {
            var endDate = oEvent.getParameter("value");
            this.getView().getModel().setProperty("/end_date", endDate);
        },

        _updatePaginationModel: function (totalRecords) {
            var oPaginationModel = this.getView().getModel("pagination");
            var totalPages = Math.ceil(totalRecords / 10);
            oPaginationModel.setProperty("/totalPages", totalPages);
            oPaginationModel.setProperty("/hasNextPage", totalPages > 1);
            oPaginationModel.setProperty("/hasPreviousPage", false);
        },

        _paginate: function () {
            var oModel = this.getView().getModel();
            var data = oModel.getProperty("/data");
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");

            var startIdx = (currentPage - 1) * 10;
            var paginatedData = data.slice(startIdx, startIdx + 10);

            oModel.setProperty("/paginatedData", paginatedData);
        },

        onNextPage: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");
            var totalPages = oPaginationModel.getProperty("/totalPages");

            if (currentPage < totalPages) {
                oPaginationModel.setProperty("/currentPage", currentPage + 1);
                this._paginate();
                this._updatePaginationState();
            }
        },

        onPreviousPage: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");

            if (currentPage > 1) {
                oPaginationModel.setProperty("/currentPage", currentPage - 1);
                this._paginate();
                this._updatePaginationState();
            }
        },

        _updatePaginationState: function () {
            var oPaginationModel = this.getView().getModel("pagination");
            var currentPage = oPaginationModel.getProperty("/currentPage");
            var totalPages = oPaginationModel.getProperty("/totalPages");

            oPaginationModel.setProperty("/hasNextPage", currentPage < totalPages);
            oPaginationModel.setProperty("/hasPreviousPage", currentPage > 1);
        },

        onSearch: function () {
            var customUrl = this.getView().getModel().getProperty("/custom_url");
            var startDate = this.getView().getModel().getProperty("/start_date");
            var endDate = this.getView().getModel().getProperty("/end_date");

            this._fetchData(customUrl, startDate, endDate);
        },

        onItemPress: function(oEvent) {
            var oItem = oEvent.getSource();
            var sessionId = oItem.getBindingContext().getProperty("session_id");
            
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("sessionJourney", {
                sessionId: sessionId
            });
        }
    });
});

