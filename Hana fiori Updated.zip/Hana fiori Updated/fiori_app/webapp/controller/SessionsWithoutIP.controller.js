sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.SessionsWithoutIP", {
        onInit: function () {
            var oModel = new JSONModel({
                start_date: "2024-12-01",
                end_date: "2025-02-15",
                data: []
            });
            this.getView().setModel(oModel);

            // Initial data fetch
            this._fetchData();
        },

        _fetchData: function () {
            var that = this;
            var startDate = this.getView().getModel().getProperty("/start_date");
            var endDate = this.getView().getModel().getProperty("/end_date");

            sap.ui.core.BusyIndicator.show(0);

            fetch(`http://134.209.157.124:8300/sessionswithoutip?start_date=${startDate}&end_date=${endDate}`)
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function (data) {
                    console.log("Fetched data:", data);
                    that.getView().getModel().setProperty("/data", data.data);
                })
                .catch(function (error) {
                    console.error("Error fetching data:", error);
                    MessageBox.error("Error loading sessions data: " + error.message);
                })
                .finally(function () {
                    sap.ui.core.BusyIndicator.hide();
                });
        },

        onSearch: function () {
            this._fetchData();
        },

        onItemPress: function(oEvent) {
            var oItem = oEvent.getSource();
            var sessionId = oItem.getBindingContext().getProperty("sessionId");
            
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("sessionJourney", {
                sessionId: sessionId
            });
        }
    });
});