sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.TerminateSession", {
        onInit: function () {
            var oModel = new JSONModel({
                sessionId: "",
                activeSessions: []
            });
            this.getView().setModel(oModel);

            // Initial fetch of active sessions
            this._fetchActiveSessions();
            
            // Set up polling for active sessions
            setInterval(this._fetchActiveSessions.bind(this), 30000); // Poll every 30 seconds
        },

        _fetchActiveSessions: function() {
            var that = this;
            fetch('http://134.209.157.124:8300/sessions')
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function(sessions) {
                    that.getView().getModel().setProperty("/activeSessions", sessions);
                })
                .catch(function(error) {
                    console.error("Error fetching active sessions:", error);
                    MessageToast.show("Error fetching active sessions");
                });
        },

        onTerminateSession: function() {
            var that = this;
            var oModel = this.getView().getModel();
            var sessionId = oModel.getProperty("/sessionId").trim();

            if (!sessionId) {
                MessageToast.show("Please enter a Session ID");
                return;
            }

            MessageBox.confirm("Are you sure you want to terminate session " + sessionId + "?", {
                title: "Confirm Session Termination",
                onClose: function(oAction) {
                    if (oAction === MessageBox.Action.OK) {
                        that._terminateSession(sessionId);
                    }
                }
            });
        },

        onQuickTerminate: function(oEvent) {
            var that = this;
            var oItem = oEvent.getSource().getParent();
            var sessionId = oItem.getBindingContext().getProperty();

            MessageBox.confirm("Are you sure you want to terminate session " + sessionId + "?", {
                title: "Confirm Session Termination",
                onClose: function(oAction) {
                    if (oAction === MessageBox.Action.OK) {
                        that._terminateSession(sessionId);
                    }
                }
            });
        },

        _terminateSession: function(sessionId) {
            var that = this;
            fetch('http://134.209.157.124:8300/terminate-session', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ sessionId: sessionId })
            })
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(function(data) {
                if (data.success) {
                    MessageToast.show("Session terminated successfully");
                    that.getView().getModel().setProperty("/sessionId", ""); // Clear input
                    that._fetchActiveSessions(); // Refresh the list
                } else {
                    MessageBox.error(data.message || "Failed to terminate session");
                }
            })
            .catch(function(error) {
                console.error("Error terminating session:", error);
                MessageBox.error("Error terminating session: " + error.message);
            });
        }
    });
});