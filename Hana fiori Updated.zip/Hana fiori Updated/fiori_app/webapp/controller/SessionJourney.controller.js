sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, History, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("sap.ui.demo.walkthrough.controller.SessionJourney", {
        onInit: function () {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("sessionJourney").attachPatternMatched(this._onObjectMatched, this);
            
            var oModel = new JSONModel({
                session_id: "5bdfqtws1",
                searchSessionId: "", // New property for search input
                journeyData: []
            });
            this.getView().setModel(oModel);

            // Load default journey data if no specific session is provided
            if (!this.getView().getModel().getProperty("/journeyData").length) {
                this._loadJourneyData("5bdfqtws1");
            }
        },

        _onObjectMatched: function (oEvent) {
            var sessionId = oEvent.getParameter("arguments").sessionId || "5bdfqtws1";
            // Update both the active session ID and the search field
            this.getView().getModel().setProperty("/session_id", sessionId);
            this.getView().getModel().setProperty("/searchSessionId", sessionId);
            this._loadJourneyData(sessionId);
        },

        onSessionSearch: function () {
            var oModel = this.getView().getModel();
            var sSessionId = oModel.getProperty("/searchSessionId");

            if (!sSessionId || sSessionId.trim() === "") {
                MessageBox.error("Please enter a Session ID");
                return;
            }

            // Update the router to reflect the new session ID
            this.getOwnerComponent().getRouter().navTo("sessionJourney", {
                sessionId: sSessionId.trim()
            }, true);

            // Update the model and load data
            oModel.setProperty("/session_id", sSessionId.trim());
            this._loadJourneyData(sSessionId.trim());
        },

        _loadJourneyData: function (sessionId) {
            var that = this;
            
            // Show loading state
            sap.ui.core.BusyIndicator.show(0);
            
            fetch(`http://134.209.157.124:8300/session_journey?session_id=${sessionId}`)
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function (data) {
                    that.getView().getModel().setProperty("/journeyData", data);
                    if (data.length === 0) {
                        MessageToast.show("No journey data found for this session ID");
                    }
                })
                .catch(function (error) {
                    console.error("Error fetching journey data:", error);
                    MessageBox.error("Error loading journey data. Please try again.");
                })
                .finally(function () {
                    // Hide loading state
                    sap.ui.core.BusyIndicator.hide();
                });
        },

        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("home", {}, true);
            }
        }
    });
});