sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "sap/ui/model/json/JSONModel"
], function (UIComponent, Device, JSONModel) {
    "use strict";
 
    return UIComponent.extend("sap.ui.demo.walkthrough.Component", {
        metadata: {
            manifest: "json"
        },
 
        init: function () {
            // call the init function of the parent
            UIComponent.prototype.init.apply(this, arguments);
 
            // set device model
            var oDeviceModel = new JSONModel(Device);
            oDeviceModel.setDefaultBindingMode("OneWay");
            this.setModel(oDeviceModel, "device");
 
            // set auth model
            var oAuthModel = new JSONModel({
                isAuthenticated: false
            });
            this.setModel(oAuthModel, "auth");
 
            
            // create the views based on the url/hash
            this.getRouter().initialize();
            
            // Check authentication status
            this.checkAuthStatus();
        },
 
        checkAuthStatus: function() {
            var userSession = sessionStorage.getItem('userSession');
            var oAuthModel = this.getModel("auth");
            var oRouter = this.getRouter();
            
            if (userSession && JSON.parse(userSession).authenticated) {
                oAuthModel.setProperty("/isAuthenticated", true);
                // Only navigate to home if we're on the login page
                if (window.location.hash === "#/login" || window.location.hash === "") {
                    oRouter.navTo("home", {}, true);
                }
            } else {
                oAuthModel.setProperty("/isAuthenticated", false);
                oRouter.navTo("login", {}, true);
            }
        }
    });
});